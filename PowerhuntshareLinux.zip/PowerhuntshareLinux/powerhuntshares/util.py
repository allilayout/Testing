"""Shared helpers: console status output, threading, and small formatters."""

from __future__ import annotations

import hashlib
import fnmatch
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Any, Callable, Iterable, List, Optional, Sequence, TypeVar

T = TypeVar("T")
R = TypeVar("R")

_print_lock = threading.Lock()

# ANSI colours, disabled when stdout is not a tty.
_TTY = sys.stdout.isatty()


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _TTY else text


def stamp() -> str:
    return datetime.now().strftime("%m/%d/%Y %H:%M")


def status(msg: str) -> None:
    """Print an informational line in the same shape as the original module."""
    with _print_lock:
        print(f" [*][{stamp()}] {msg}", flush=True)


def substatus(msg: str) -> None:
    with _print_lock:
        print(f" [*][{stamp()}] - {msg}", flush=True)


def warn(msg: str) -> None:
    with _print_lock:
        print(_c("33", f" [!][{stamp()}] {msg}"), flush=True)


def error(msg: str) -> None:
    with _print_lock:
        print(_c("31", f" [x][{stamp()}] {msg}"), file=sys.stderr, flush=True)


_verbose = False


def set_verbose(value: bool) -> None:
    global _verbose
    _verbose = value


def verbose(msg: str) -> None:
    if _verbose:
        with _print_lock:
            print(_c("90", f" [v][{stamp()}] {msg}"), flush=True)


class Progress:
    """Minimal in-place progress counter for long threaded phases."""

    def __init__(self, total: int, label: str) -> None:
        self.total = max(total, 0)
        self.label = label
        self.done = 0
        self._lock = threading.Lock()
        self._enabled = _TTY and self.total > 0

    def tick(self, n: int = 1) -> None:
        with self._lock:
            self.done += n
            if self._enabled:
                pct = (self.done / self.total) * 100 if self.total else 100.0
                sys.stdout.write(
                    f"\r [*][{stamp()}]   {self.label}: {self.done}/{self.total} ({pct:5.1f}%)"
                )
                sys.stdout.flush()

    def close(self) -> None:
        if self._enabled:
            sys.stdout.write("\r" + " " * 78 + "\r")
            sys.stdout.flush()


def run_parallel(
    items: Sequence[T],
    fn: Callable[[T], Optional[R]],
    threads: int = 20,
    timeout: int = 15,
    label: str = "",
) -> List[R]:
    """Run ``fn`` over ``items`` in a thread pool, dropping failures.

    This is the Python equivalent of the original module's Invoke-Parallel
    runspace usage: per-item exceptions and timeouts are swallowed so a single
    unreachable host can never abort a scan. ``timeout`` is applied per item.
    """
    results: List[R] = []
    if not items:
        return results

    progress = Progress(len(items), label) if label else None
    with ThreadPoolExecutor(max_workers=max(1, threads)) as pool:
        futures = {pool.submit(fn, item): item for item in items}
        for fut in as_completed(futures):
            try:
                out = fut.result(timeout=timeout)
            except Exception as exc:  # noqa: BLE001 - deliberately broad
                verbose(f"task failed for {futures[fut]!r}: {exc}")
                out = None
            if out is not None:
                if isinstance(out, list):
                    results.extend(out)
                else:
                    results.append(out)
            if progress:
                progress.tick()
    if progress:
        progress.close()
    return results


def percent(part: int, whole: int) -> float:
    """Percentage guarded against division by zero."""
    if not whole:
        return 0.0
    return round((part / whole) * 100, 2)


def percent_str(part: int, whole: int) -> str:
    return f"{percent(part, whole):.2f}%"


def md5_of_filelist(file_list: str) -> str:
    """Hash a share's root listing so identical shares can be grouped.

    Matches Get-FolderGroupMd5 from the original module: the newline separated
    listing is lowercased and hashed, giving shares deployed from the same
    image or template an identical group id.
    """
    normalized = "\n".join(
        sorted(line.strip().lower() for line in file_list.splitlines() if line.strip())
    )
    return hashlib.md5(normalized.encode("utf-8", "replace")).hexdigest()


def like(value: Optional[str], pattern: str) -> bool:
    """Case-insensitive glob match, standing in for PowerShell's -like."""
    if value is None:
        return False
    return fnmatch.fnmatch(str(value).lower(), pattern.lower())


def any_like(value: Optional[str], patterns: Iterable[str]) -> bool:
    return any(like(value, p) for p in patterns)


def parse_smb_time(timestamp: Any) -> Optional[datetime]:
    """Convert an impacket SMB timestamp (100ns since 1601) into a datetime."""
    try:
        value = int(timestamp)
    except (TypeError, ValueError):
        return None
    if value <= 0:
        return None
    # 116444736000000000 = 100ns intervals between 1601-01-01 and 1970-01-01.
    unix_seconds = (value - 116444736000000000) / 10000000
    if unix_seconds <= 0:
        return None
    try:
        return datetime.fromtimestamp(unix_seconds)
    except (OverflowError, OSError, ValueError):
        return None


def fmt_time(dt: Optional[datetime]) -> str:
    return dt.strftime("%m/%d/%Y %H:%M:%S") if dt else ""


def fmt_year(dt: Optional[datetime]) -> str:
    return str(dt.year) if dt else ""
