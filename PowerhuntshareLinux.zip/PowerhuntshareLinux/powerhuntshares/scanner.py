"""Scan orchestration: the Linux equivalent of Invoke-HuntSMBShares."""

from __future__ import annotations

from collections import Counter
from datetime import datetime
from typing import Dict, List, Optional, Sequence, Tuple

from .analysis import interesting as interesting_mod
from .analysis import risk as risk_mod
from .analysis.keywords import Keyword, load_keywords
from .analysis.sharenames import guess as guess_share
from .discovery import ldap_enum, portscan
from .models import (
    Computer,
    ExtractedSecret,
    FileEntry,
    InterestingFile,
    ScanResults,
    Share,
    ShareACL,
)
from .parsers import run as run_parser
from .smbx import files as files_mod
from .smbx import shares as shares_mod
from .smbx.auth import Credentials, close, connect
from .util import (
    percent_str,
    run_parallel,
    status,
    substatus,
    verbose,
    warn,
)


class ScanConfig:
    """All tunables for one scan, assembled by the CLI."""

    def __init__(
        self,
        output_dir: str,
        creds: Credentials,
        domain_controller: str = "",
        host_list: Optional[List[str]] = None,
        threads: int = 20,
        timeout: int = 15,
        dir_level: int = 3,
        max_files_per_share: int = 50000,
        sample_sum: int = 200,
        stale_days: int = 365,
        no_ping: bool = False,
        use_icmp: bool = False,
        keyword_path: str = "",
        collect_files: bool = True,
        extract_secrets: bool = True,
        verify_write: bool = False,
        share_level_acls: bool = False,
        ldap_filter: str = "(objectCategory=computer)",
        ldap_ssl: bool = False,
        max_secret_file_size: int = 1024 * 1024,
    ) -> None:
        self.output_dir = output_dir
        self.creds = creds
        self.domain_controller = domain_controller
        self.host_list = host_list or []
        self.threads = threads
        self.timeout = timeout
        self.dir_level = dir_level
        self.max_files_per_share = max_files_per_share
        self.sample_sum = sample_sum
        self.stale_days = stale_days
        self.no_ping = no_ping
        self.use_icmp = use_icmp
        self.keyword_path = keyword_path
        self.collect_files = collect_files
        self.extract_secrets = extract_secrets
        self.verify_write = verify_write
        self.share_level_acls = share_level_acls
        self.ldap_filter = ldap_filter
        self.ldap_ssl = ldap_ssl
        self.max_secret_file_size = max_secret_file_size


def run_scan(config: ScanConfig) -> ScanResults:
    """Execute the full discovery, analysis, and enrichment pipeline."""
    results = ScanResults()
    start = datetime.now()
    results.start_time = start.strftime("%m/%d/%Y %H:%M:%S")

    print(" ===============================================================")
    print(" POWERHUNTSHARES-LINUX                                          ")
    print(" ===============================================================")
    print("  o Enumerate domain computers via LDAP                         ")
    print("  o Check host liveness and TCP 445 reachability                ")
    print("  o Enumerate SMB shares and their ACLs                         ")
    print("  o Identify shares with potentially excessive privileges       ")
    print("  o Walk readable shares for interesting files                  ")
    print("  o Parse config files for credentials                          ")
    print("  o Generate CSV exports and an HTML summary report             ")
    print("")
    print("  Note: this can take hours to run in large environments.       ")
    print(" ---------------------------------------------------------------")
    print(" SHARE DISCOVERY")
    print(" ---------------------------------------------------------------")

    status("Scan start")
    substatus(f"Output directory: {config.output_dir}")
    substatus(f"Authenticating as: {config.creds.describe()}")

    domain_netbios = config.creds.domain.split(".")[0].upper() if config.creds.domain else ""

    # --- Stage 1: target discovery -----------------------------------------
    if config.host_list:
        hosts = portscan.expand_targets(config.host_list)
        results.computers = [Computer(ComputerName=h) for h in hosts]
        results.target_domain = "SmbHunt"
        substatus(f"{len(results.computers)} systems will be targeted")

        # An explicit host list skips LDAP discovery, but when a domain
        # controller is also available the directory still supplies operating
        # system data and the real domain name, both of which the report uses.
        if config.domain_controller or config.creds.domain:
            netbios = _enrich_from_ldap(results, config)
            domain_netbios = netbios or domain_netbios
    else:
        dc = config.domain_controller or ldap_enum.discover_dc(config.creds.domain)
        if not dc:
            warn("no domain controller supplied or discoverable; aborting")
            return _finish(results, start)
        try:
            domain, netbios, computers, subnets = ldap_enum.enumerate_domain(
                dc, config.creds, use_ssl=config.ldap_ssl,
                ldap_filter=config.ldap_filter, timeout=config.timeout,
            )
        except Exception as exc:  # noqa: BLE001
            warn(f"LDAP enumeration failed: {exc}")
            return _finish(results, start)

        results.target_domain = domain or "SmbHunt"
        domain_netbios = netbios or domain_netbios
        results.computers = computers
        results.subnets = subnets

    if not results.computers:
        warn("no target computers; aborting")
        return _finish(results, start)

    # --- Stage 2: liveness --------------------------------------------------
    if config.no_ping:
        substatus("Skipping liveness scan")
    else:
        status(f"Checking liveness of {len(results.computers)} computers")
        results.computers_pingable = portscan.check_alive(
            results.computers, threads=config.threads, use_icmp=config.use_icmp
        )
        substatus(f"{len(results.computers_pingable)} computers responded")

    status(f"Checking if TCP port 445 is open on {len(results.computers)} computers")
    results.computers_445 = portscan.check_445(results.computers, threads=config.threads)
    substatus(f"{len(results.computers_445)} computers have TCP port 445 open")

    if not results.computers_445:
        warn("no reachable SMB services; aborting")
        _diagnose_no_targets(results, config)
        return _finish(results, start)

    # --- Stage 3: share enumeration ----------------------------------------
    status(f"Getting a list of SMB shares from {len(results.computers_445)} computers")
    results.shares = _enumerate_shares(results.computers_445, config)
    substatus(f"{len(results.shares)} SMB shares were found")

    if not results.shares:
        warn("no shares enumerated; aborting")
        return _finish(results, start)

    # --- Stage 4: ACL collection -------------------------------------------
    shares_by_host: Dict[str, List[Share]] = {}
    for share in results.shares:
        shares_by_host.setdefault(share.ComputerName, []).append(share)

    status(f"Getting share permissions from {len(results.shares)} SMB shares")
    results.acls = _collect_acls(shares_by_host, config, domain_netbios)
    substatus(f"{len(results.acls)} share permissions were enumerated")

    if not results.acls:
        warn("no share ACLs could be read; aborting")
        return _finish(results, start)

    # --- Stage 5: excessive privileges -------------------------------------
    status("Identifying potentially excessive share permissions")
    excessive_acls = risk_mod.find_excessive(results.acls)
    excessive_shares = {(a.ComputerName, a.ShareName) for a in excessive_acls}
    excessive_hosts = {a.ComputerName for a in excessive_acls}
    substatus(
        f"{len(excessive_acls)} potentially excessive privileges were found on "
        f"{len(excessive_shares)} shares across {len(excessive_hosts)} systems"
    )

    if not excessive_acls:
        warn("0 excessive privileges found")

    # --- Stage 6: file walking ---------------------------------------------
    keywords = load_keywords(config.keyword_path or None)
    substatus(f"Loaded {len(keywords)} interesting-file keywords")

    if config.collect_files and excessive_acls:
        targets = _walk_targets(excessive_acls)
        status(f"Getting directory listings from {len(excessive_shares)} SMB shares")
        substatus(f"Targeting up to {config.dir_level} nested directory levels")
        results.files = _walk_shares(targets, config)
        substatus(f"{len(results.files)} files and folders were enumerated")

        status("Finding interesting files")
        results.interesting_files = interesting_mod.find_interesting(results.files, keywords)
        substatus(f"{len(results.interesting_files)} interesting files identified")

        if config.extract_secrets:
            status("Parsing config files for credentials")
            results.secrets = _extract_secrets(results.interesting_files, keywords, config)
            substatus(f"{len(results.secrets)} secrets extracted")

    # --- Stage 7: scoring and summaries ------------------------------------
    print(" ---------------------------------------------------------------")
    print(" SHARE ANALYSIS")
    print(" ---------------------------------------------------------------")
    status("Analysis start")

    guess_map = {
        name.lower(): guess_share(name)
        for name in {a.ShareName for a in excessive_acls}
    }
    results.excessive = risk_mod.enrich(
        excessive_acls,
        results.interesting_files,
        results.computers,
        share_guesses=guess_map,
        stale_days=config.stale_days,
    )

    results.stats = _build_stats(results, config)
    _print_summary(results)
    status("Analysis complete")

    return _finish(results, start)


# ---------------------------------------------------------------------------
# Stage helpers
# ---------------------------------------------------------------------------

def _diagnose_no_targets(results: ScanResults, config: ScanConfig) -> None:
    """Explain why nothing was reachable, rather than just aborting.

    Reaching this point after a long run is expensive, so the most common
    causes are called out explicitly with the evidence that points at each.
    """
    import socket

    names = [c.ComputerName for c in results.computers]
    unresolvable = []
    for name in names[:25]:
        try:
            socket.gethostbyname(name)
        except OSError:
            unresolvable.append(name)

    warn("Nothing to scan. Common causes:")
    if unresolvable:
        warn(f"  - {len(unresolvable)} of the first {min(len(names), 25)} targets do not resolve")
        for name in unresolvable[:5]:
            warn(f"      {name!r}")
        warn("    Check DNS, or that the target list holds hosts/IPs and not something else.")
    if len(names) == 1:
        warn(f"  - Only one target was parsed: {names[0]!r}")
        warn("    If you meant to load a host list, pass it with --target-file.")
    warn("  - TCP 445 may be filtered between this host and the targets.")
    warn(f"    Verify manually, e.g.  nc -vz {names[0]} 445" if names else "")
    if not config.no_ping:
        warn("  - Liveness probing can hide hosts that only expose 445; try --no-ping.")


def _enrich_from_ldap(results: ScanResults, config: ScanConfig) -> str:
    """Attach LDAP metadata to an explicitly supplied host list.

    Targets are frequently bare IPs (a host list exported from another tool),
    so each one is matched against the directory by reverse DNS as well as by
    name. Returns the domain NetBIOS name, or an empty string if the directory
    could not be reached -- enrichment is best effort and never aborts a scan.
    """
    import socket

    dc = config.domain_controller or ldap_enum.discover_dc(config.creds.domain)
    if not dc:
        verbose("no domain controller available for metadata enrichment")
        return ""

    try:
        domain, netbios, computers, subnets = ldap_enum.enumerate_domain(
            dc,
            config.creds,
            use_ssl=config.ldap_ssl,
            ldap_filter=config.ldap_filter,
            timeout=config.timeout,
        )
    except Exception as exc:  # noqa: BLE001
        warn(f"LDAP metadata enrichment failed, continuing with the host list: {exc}")
        return ""

    if domain:
        results.target_domain = domain
    results.subnets = subnets

    # Index the directory by FQDN and by short name.
    by_name = {}
    for computer in computers:
        name = computer.ComputerName.lower()
        by_name[name] = computer
        by_name.setdefault(name.split(".")[0], computer)

    def lookup(target: Computer) -> Optional[Computer]:
        key = target.ComputerName.lower()
        match = by_name.get(key) or by_name.get(key.split(".")[0])
        if match:
            return match
        # Bare IP: ask DNS what the directory would call it.
        try:
            hostname = socket.gethostbyaddr(target.ComputerName)[0].lower()
        except OSError:
            return None
        return by_name.get(hostname) or by_name.get(hostname.split(".")[0])

    matched = 0
    for target in results.computers:
        match = lookup(target)
        if match is None:
            continue
        matched += 1
        target.OperatingSystem = match.OperatingSystem
        target.ServicePack = match.ServicePack

    substatus(
        f"Matched {matched} of {len(results.computers)} targets against "
        f"{len(computers)} directory computers"
    )
    return netbios


def _enumerate_shares(computers: Sequence[Computer], config: ScanConfig) -> List[Share]:
    def work(computer: Computer) -> List[Share]:
        conn = None
        try:
            conn = connect(computer.ComputerName, config.creds, timeout=config.timeout)
            return shares_mod.enumerate_shares(
                conn, computer.ComputerName, computer.IpAddress
            )
        except Exception as exc:  # noqa: BLE001
            verbose(f"{computer.ComputerName}: {exc}")
            return []
        finally:
            close(conn)

    return run_parallel(
        list(computers), work, threads=config.threads,
        timeout=config.timeout * 4, label="shares",
    )


def _collect_acls(
    shares_by_host: Dict[str, List[Share]],
    config: ScanConfig,
    domain_netbios: str,
) -> List[ShareACL]:
    hosts = list(shares_by_host.items())

    def work(item: Tuple[str, List[Share]]) -> List[ShareACL]:
        computer, host_shares = item
        return shares_mod.collect_share_acls(
            computer,
            host_shares,
            config.creds,
            domain_netbios=domain_netbios,
            include_share_level=config.share_level_acls,
            timeout=config.timeout,
        )

    # ACL collection touches every share on a host, so allow a generous
    # per-host budget rather than the per-item default.
    return run_parallel(
        hosts, work, threads=config.threads,
        timeout=config.timeout * 20, label="acls",
    )


def _walk_targets(excessive: Sequence[ShareACL]) -> Dict[str, List[Tuple[str, str]]]:
    """Group the shares worth walking by host, de-duplicated."""
    targets: Dict[str, List[Tuple[str, str]]] = {}
    seen = set()
    for acl in excessive:
        # Only readable shares can be walked; a write-only ACE yields nothing.
        if not risk_mod.has_read(acl.FileSystemRights):
            continue
        key = (acl.ComputerName, acl.ShareName)
        if key in seen:
            continue
        if acl.ShareName.lower() in shares_mod.NON_WALKABLE:
            continue
        seen.add(key)
        targets.setdefault(acl.ComputerName, []).append((acl.ShareName, acl.SharePath))
    return targets


def _walk_shares(
    targets: Dict[str, List[Tuple[str, str]]], config: ScanConfig
) -> List[FileEntry]:
    items = list(targets.items())

    def work(item: Tuple[str, List[Tuple[str, str]]]) -> List[FileEntry]:
        computer, share_list = item
        return files_mod.walk_host_shares(
            computer,
            share_list,
            config.creds,
            max_depth=config.dir_level,
            max_files=config.max_files_per_share,
            timeout=config.timeout,
        )

    return run_parallel(
        items, work, threads=config.threads,
        timeout=config.timeout * 40, label="files",
    )


def _extract_secrets(
    interesting: Sequence[InterestingFile],
    keywords: Sequence[Keyword],
    config: ScanConfig,
) -> List[ExtractedSecret]:
    """Download parseable config files and run the credential parsers."""
    candidates = interesting_mod.parseable(
        interesting, keywords, max_size=config.max_secret_file_size
    )
    if not candidates:
        return []

    substatus(f"{len(candidates)} candidate config files to parse")

    # Group by host so one SMB session serves every download on that host.
    by_host: Dict[str, List[Tuple[InterestingFile, str]]] = {}
    for item, parser_name in candidates:
        by_host.setdefault(item.ComputerName, []).append((item, parser_name))

    def work(entry: Tuple[str, List[Tuple[InterestingFile, str]]]) -> List[ExtractedSecret]:
        computer, jobs = entry
        out: List[ExtractedSecret] = []
        conn = None
        try:
            conn = connect(computer, config.creds, timeout=config.timeout)
            for item, parser_name in jobs:
                rel = files_mod.rel_path_from_unc(item.UncPath, item.ShareName)
                data = files_mod.read_file(
                    conn, item.ShareName, rel, max_bytes=config.max_secret_file_size
                )
                if not data:
                    continue
                for finding in run_parser(parser_name, data):
                    out.append(
                        ExtractedSecret(
                            ComputerName=computer,
                            ShareName=item.ShareName,
                            UncPath=item.UncPath,
                            FileName=item.FileName,
                            Parser=parser_name,
                            Name=finding.name,
                            Section=finding.section,
                            Url=finding.url,
                            Server=finding.server,
                            Port=finding.port,
                            UserName=finding.username,
                            Password=finding.password,
                            Notes=finding.notes,
                        )
                    )
        except Exception as exc:  # noqa: BLE001
            verbose(f"{computer}: secret extraction failed: {exc}")
        finally:
            close(conn)
        return out

    return run_parallel(
        list(by_host.items()), work, threads=config.threads,
        timeout=config.timeout * 30, label="secrets",
    )


# ---------------------------------------------------------------------------
# Summary statistics
# ---------------------------------------------------------------------------

def _build_stats(results: ScanResults, config: ScanConfig) -> Dict[str, object]:
    excessive = results.excessive
    total_computers = len(results.computers)
    total_shares = len(results.shares)
    total_acls = len(results.acls)
    sample = config.sample_sum

    def unique_shares(rows) -> int:
        return len({(r.ComputerName, r.ShareName) for r in rows})

    def unique_hosts(rows) -> int:
        return len({r.ComputerName for r in rows})

    readable = [r for r in excessive if r.HasRead]
    writable = [r for r in excessive if r.HasWrite]
    high_risk = [r for r in excessive if r.HasHR]
    non_default = [r for r in excessive if not r.IsDefault]

    excessive_share_count = unique_shares(excessive)
    read_share_count = unique_shares(readable)
    write_share_count = unique_shares(writable)
    hr_share_count = unique_shares(high_risk)

    risk_counts = Counter(r.RiskLevel for r in excessive)
    category_counts = Counter(f.Category for f in results.interesting_files)

    common_names = Counter(
        r.ShareName for r in {(x.ComputerName, x.ShareName): x for x in excessive}.values()
        if r.ShareName.upper() not in ("SYSVOL", "NETLOGON")
    ).most_common(sample)

    common_owners = Counter(
        r.ShareOwner for r in {(x.SharePath): x for x in excessive}.values() if r.ShareOwner
    ).most_common(sample)

    common_groups = Counter(
        r.FileListGroup for r in excessive if r.FileListGroup
    ).most_common(sample)

    common_identities = Counter(
        r.IdentityReference for r in excessive if r.IdentityReference
    ).most_common(sample)

    timeline_modified = sorted(
        Counter(
            r.LastModifiedDateYear for r in excessive if r.LastModifiedDateYear
        ).items()
    )

    return {
        "risk_counts": dict(risk_counts),
        "category_counts": dict(category_counts.most_common()),
        "common_names": common_names,
        "common_owners": common_owners,
        "common_groups": common_groups,
        "common_identities": common_identities,
        "timeline_modified": timeline_modified,
        "excessive_acl_count": len(excessive),
        "excessive_share_count": excessive_share_count,
        "excessive_host_count": unique_hosts(excessive),
        "read_share_count": read_share_count,
        "read_host_count": unique_hosts(readable),
        "write_share_count": write_share_count,
        "write_host_count": unique_hosts(writable),
        "high_risk_share_count": hr_share_count,
        "high_risk_host_count": unique_hosts(high_risk),
        "non_default_share_count": unique_shares(non_default),
        "pct_445": percent_str(len(results.computers_445), total_computers),
        "pct_excessive_shares": percent_str(excessive_share_count, total_shares),
        "pct_read_shares": percent_str(read_share_count, total_shares),
        "pct_write_shares": percent_str(write_share_count, total_shares),
        "pct_high_risk_shares": percent_str(hr_share_count, total_shares),
        "pct_excessive_acls": percent_str(len(excessive), total_acls),
    }


def _print_summary(results: ScanResults) -> None:
    stats = results.stats
    computers = len(results.computers)
    shares = len(results.shares)
    acls = len(results.acls)

    print(" ---------------------------------------------------------------")
    print(" SHARE REPORT SUMMARY")
    print(" ---------------------------------------------------------------")
    status(f"Domain: {results.target_domain}")
    status("")
    status("COMPUTER SUMMARY")
    substatus(f"{computers} domain computers found.")
    substatus(
        f"{len(results.computers_pingable)} "
        f"({percent_str(len(results.computers_pingable), computers)}) responded to liveness checks."
    )
    substatus(
        f"{len(results.computers_445)} ({stats['pct_445']}) had TCP port 445 accessible."
    )
    substatus(
        f"{stats['excessive_host_count']} "
        f"({percent_str(stats['excessive_host_count'], computers)}) "
        "had shares with potentially excessive privileges."
    )
    substatus(
        f"{stats['read_host_count']} "
        f"({percent_str(stats['read_host_count'], computers)}) had shares allowing READ access."
    )
    substatus(
        f"{stats['write_host_count']} "
        f"({percent_str(stats['write_host_count'], computers)}) had shares allowing WRITE access."
    )
    substatus(
        f"{stats['high_risk_host_count']} "
        f"({percent_str(stats['high_risk_host_count'], computers)}) had HIGH RISK shares."
    )
    status("")
    status("SHARE SUMMARY")
    substatus(f"{shares} shares were found.")
    substatus(
        f"{stats['excessive_share_count']} ({stats['pct_excessive_shares']}) "
        f"across {stats['excessive_host_count']} systems are configured with "
        f"{stats['excessive_acl_count']} potentially excessive ACLs."
    )
    substatus(
        f"{stats['read_share_count']} ({stats['pct_read_shares']}) allowed READ access."
    )
    substatus(
        f"{stats['write_share_count']} ({stats['pct_write_shares']}) allowed WRITE access."
    )
    substatus(
        f"{stats['high_risk_share_count']} ({stats['pct_high_risk_shares']}) are HIGH RISK."
    )
    status("")
    status("SHARE ACL SUMMARY")
    substatus(f"{acls} ACLs were found.")
    substatus(
        f"{stats['excessive_acl_count']} ({stats['pct_excessive_acls']}) were potentially excessive."
    )
    status("")
    status("RISK LEVELS")
    for level in ("Critical", "High", "Medium", "Low"):
        substatus(f"{stats['risk_counts'].get(level, 0)} {level}")

    if results.interesting_files:
        status("")
        status("INTERESTING FILES")
        for category, count in stats["category_counts"].items():
            substatus(f"{count} {category}")

    if results.secrets:
        status("")
        status(f"{len(results.secrets)} secrets were extracted from config files.")

    if stats["common_names"]:
        status("")
        status("The most common share names are:")
        for name, count in stats["common_names"][:5]:
            substatus(f"{count} {name}")


def _finish(results: ScanResults, start: datetime) -> ScanResults:
    end = datetime.now()
    results.end_time = end.strftime("%m/%d/%Y %H:%M:%S")
    results.run_time = str(end - start).split(".")[0]
    if not results.stats:
        results.stats = {
            "risk_counts": {},
            "category_counts": {},
            "common_names": [],
            "common_owners": [],
            "common_identities": [],
            "common_groups": [],
            "timeline_modified": [],
        }
    return results
