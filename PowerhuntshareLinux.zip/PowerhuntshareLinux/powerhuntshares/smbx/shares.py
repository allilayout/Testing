"""Share enumeration and per-share ACL collection."""

from __future__ import annotations

from typing import List, Optional, Tuple

from impacket.smbconnection import SMBConnection

from ..models import Share, ShareACL
from ..util import (
    fmt_time,
    fmt_year,
    md5_of_filelist,
    parse_smb_time,
    verbose,
)
from . import acl as acl_mod
from .auth import Credentials, close, connect, resolve_ip
from .sids import SidResolver

# Share type bits from MS-SRVS 2.2.2.4.
STYPE_DISKTREE = 0x00000000
STYPE_PRINTQ = 0x00000001
STYPE_DEVICE = 0x00000002
STYPE_IPC = 0x00000003
STYPE_MASK = 0x0000000F
STYPE_SPECIAL = 0x80000000
STYPE_TEMPORARY = 0x40000000

_TYPE_NAMES = {
    STYPE_DISKTREE: "Disk",
    STYPE_PRINTQ: "Printer",
    STYPE_DEVICE: "Device",
    STYPE_IPC: "IPC",
}

# Shares that are never worth walking for files.
NON_WALKABLE = {"ipc$", "print$", "prnproc$", "printer$", "fax$"}


def share_type_name(raw: int) -> str:
    base = _TYPE_NAMES.get(raw & STYPE_MASK, "Unknown")
    if raw & STYPE_SPECIAL:
        base += " (Special)"
    if raw & STYPE_TEMPORARY:
        base += " (Temporary)"
    return base


def enumerate_shares(conn: SMBConnection, computer: str, ip: str = "") -> List[Share]:
    """List shares on ``computer`` and probe which ones are actually reachable."""
    out: List[Share] = []
    try:
        raw_shares = conn.listShares()
    except Exception as exc:  # noqa: BLE001
        verbose(f"{computer}: share enumeration failed: {exc}")
        return out

    for entry in raw_shares:
        try:
            name = str(entry["shi1_netname"])
        except Exception:  # noqa: BLE001
            continue
        name = name.rstrip("\x00")
        if not name:
            continue

        remark = ""
        try:
            remark = str(entry["shi1_remark"]).rstrip("\x00")
        except Exception:  # noqa: BLE001
            pass
        try:
            raw_type = int(entry["shi1_type"])
        except Exception:  # noqa: BLE001
            raw_type = 0

        share = Share(
            ComputerName=computer,
            IpAddress=ip,
            ShareName=name,
            ShareDesc=remark,
            SharePath=f"\\\\{computer}\\{name}",
            ShareType=share_type_name(raw_type),
            ShareAccess="Yes" if probe_access(conn, name) else "No",
        )
        out.append(share)
    return out


def probe_access(conn: SMBConnection, share: str) -> bool:
    """Test whether the share root can actually be listed.

    This is the ground truth behind the ``ShareAccess`` column: ACLs can say one
    thing while share permissions, DFS state, or an offline volume say another.
    """
    if share.lower() in ("ipc$",):
        return False
    try:
        conn.listPath(share, "\\*")
        return True
    except Exception:  # noqa: BLE001
        return False


def _root_listing(conn: SMBConnection, share: str) -> Tuple[int, str, Optional[object]]:
    """Return (file count, newline separated names, share root SMB entry)."""
    names: List[str] = []
    root_entry = None
    try:
        entries = conn.listPath(share, "\\*")
    except Exception as exc:  # noqa: BLE001
        verbose(f"root listing failed for {share}: {exc}")
        return 0, "", None

    for entry in entries:
        try:
            name = entry.get_longname()
        except Exception:  # noqa: BLE001
            continue
        if name in (".", ".."):
            if name == ".":
                root_entry = entry
            continue
        names.append(name)
    return len(names), "\n".join(names), root_entry


def collect_share_acls(
    computer: str,
    shares: List[Share],
    creds: Credentials,
    domain_netbios: str = "",
    include_share_level: bool = False,
    timeout: int = 10,
) -> List[ShareACL]:
    """Build one ShareACL record per ACE across every share on one host.

    A single SMB session is reused for the whole host: reconnecting per share
    is the dominant cost in large environments.
    """
    results: List[ShareACL] = []
    conn = None
    resolver = None
    try:
        conn = connect(computer, creds, timeout=timeout)
        ip = resolve_ip(computer)
        resolver = SidResolver(conn, domain_netbios=domain_netbios)

        for share in shares:
            if share.ShareAccess != "Yes":
                continue
            results.extend(
                _acls_for_share(
                    conn, resolver, computer, ip, share, include_share_level
                )
            )
    except Exception as exc:  # noqa: BLE001
        verbose(f"{computer}: ACL collection failed: {exc}")
    finally:
        if resolver is not None:
            resolver.close()
        close(conn)
    return results


def _acls_for_share(
    conn: SMBConnection,
    resolver: SidResolver,
    computer: str,
    ip: str,
    share: Share,
    include_share_level: bool,
) -> List[ShareACL]:
    name = share.ShareName

    file_count, file_list, root_entry = _root_listing(conn, name)
    file_group = md5_of_filelist(file_list)

    created = parse_smb_time(root_entry.get_ctime()) if root_entry else None
    modified = parse_smb_time(root_entry.get_mtime()) if root_entry else None
    accessed = parse_smb_time(root_entry.get_atime()) if root_entry else None

    security = acl_mod.get_ntfs_security(conn, name, include_sacl=False)
    source = "ntfs"
    if security is None and include_share_level:
        security = acl_mod.get_share_security(conn, name)
        source = "share"

    if security is None:
        # ACLs are unreadable, but the share is reachable. Emit a synthetic
        # record so the share still appears in the inventory with whatever
        # effective access we were able to observe.
        return [
            ShareACL(
                ComputerName=computer,
                IpAddress=ip,
                ShareName=name,
                SharePath=share.SharePath,
                ShareDescription=share.ShareDesc,
                ShareOwner="Unknown",
                ShareType=share.ShareType,
                ShareAccess=share.ShareAccess,
                FileSystemRights="Read (observed)",
                IdentityReference="(effective access)",
                IdentitySID="",
                AccessControlType="Allow",
                CreationDate=fmt_time(created),
                CreationDateYear=fmt_year(created),
                LastModifiedDate=fmt_time(modified),
                LastModifiedDateYear=fmt_year(modified),
                LastAccessDate=fmt_time(accessed),
                LastAccessDateYear=fmt_year(accessed),
                FileCount=file_count,
                FileList=file_list,
                FileListGroup=file_group,
                AuditSettings="",
                AclSource="probe",
            )
        ]

    sids = [ace.sid for ace in security.aces]
    if security.owner_sid:
        sids.append(security.owner_sid)
    resolved = resolver.resolve_many(sids)
    owner = resolved.get(security.owner_sid, security.owner_sid or "Unknown")

    audit_text = "; ".join(
        f"{resolved.get(a.sid, a.sid)}: {a.rights}" for a in security.audit
    )

    out: List[ShareACL] = []
    for ace in security.aces:
        out.append(
            ShareACL(
                ComputerName=computer,
                IpAddress=ip,
                ShareName=name,
                SharePath=share.SharePath,
                ShareDescription=share.ShareDesc,
                ShareOwner=owner,
                ShareType=share.ShareType,
                ShareAccess=share.ShareAccess,
                FileSystemRights=ace.rights,
                IdentityReference=resolved.get(ace.sid, ace.sid),
                IdentitySID=ace.sid,
                AccessControlType=ace.ace_type,
                CreationDate=fmt_time(created),
                CreationDateYear=fmt_year(created),
                LastModifiedDate=fmt_time(modified),
                LastModifiedDateYear=fmt_year(modified),
                LastAccessDate=fmt_time(accessed),
                LastAccessDateYear=fmt_year(accessed),
                FileCount=file_count,
                FileList=file_list,
                FileListGroup=file_group,
                AuditSettings=audit_text,
                AclSource=source,
            )
        )
    return out
