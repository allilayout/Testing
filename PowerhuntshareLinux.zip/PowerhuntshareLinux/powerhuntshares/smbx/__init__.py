"""SMB access layer built on impacket."""
