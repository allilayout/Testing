"""Security descriptor retrieval and access-mask decoding.

Two descriptors matter for share hunting:

* The **NTFS descriptor on the share root directory**, fetched with an SMB2
  QUERY_INFO of class ``SMB2_0_INFO_SECURITY``. This is the direct equivalent of
  ``Get-Acl \\\\host\\share`` in the original module and is what the excessive
  privilege logic is built around. Any user holding READ_CONTROL can read it.
* The **share-level descriptor**, fetched with ``NetrShareGetInfo`` level 502
  over srvsvc. Effective access is the intersection of the two, so it is
  collected as a supplement when the caller has the rights to read it
  (typically local admin).

Access masks are rendered into the same strings that
``System.Security.AccessControl.FileSystemRights`` produces on Windows, so that
the downstream ``*Read*`` / ``*Write*`` / ``*GenericAll*`` matching behaves
exactly as it does upstream.
"""

from __future__ import annotations

from typing import List, NamedTuple, Optional, Tuple

from impacket.ldap.ldaptypes import SR_SECURITY_DESCRIPTOR
from impacket.smb3structs import (
    DACL_SECURITY_INFORMATION,
    FILE_DIRECTORY_FILE,
    FILE_OPEN,
    FILE_SHARE_DELETE,
    FILE_SHARE_READ,
    FILE_SHARE_WRITE,
    GROUP_SECURITY_INFORMATION,
    OWNER_SECURITY_INFORMATION,
    READ_CONTROL,
    SACL_SECURITY_INFORMATION,
    SMB2_0_INFO_SECURITY,
)
from impacket.smbconnection import SMBConnection

from ..util import verbose

ACCESS_ALLOWED_TYPES = {0x00, 0x05, 0x09, 0x0B}  # allowed, incl. object/callback
ACCESS_DENIED_TYPES = {0x01, 0x06, 0x0A, 0x0C}
SYSTEM_AUDIT_TYPES = {0x02, 0x07, 0x08, 0x0D}

# Individual FileSystemRights bits, in the order Windows lists them.
_RIGHT_BITS: Tuple[Tuple[int, str], ...] = (
    (0x00000001, "ListDirectory"),
    (0x00000002, "CreateFiles"),
    (0x00000004, "AppendData"),
    (0x00000008, "ReadExtendedAttributes"),
    (0x00000010, "WriteExtendedAttributes"),
    (0x00000020, "ExecuteFile"),
    (0x00000040, "DeleteSubdirectoriesAndFiles"),
    (0x00000080, "ReadAttributes"),
    (0x00000100, "WriteAttributes"),
    (0x00010000, "Delete"),
    (0x00020000, "ReadPermissions"),
    (0x00040000, "ChangePermissions"),
    (0x00080000, "TakeOwnership"),
    (0x00100000, "Synchronize"),
    (0x01000000, "AccessSystemSecurity"),
    (0x02000000, "MaximumAllowed"),
    (0x10000000, "GenericAll"),
    (0x20000000, "GenericExecute"),
    (0x40000000, "GenericWrite"),
    (0x80000000, "GenericRead"),
)

# Composite rights, checked before the individual bits so that a full-control
# ACE renders as "FullControl" rather than a list of twenty flags.
FULL_CONTROL = 0x001F01FF
MODIFY = 0x000301BF
READ_AND_EXECUTE = 0x000200A9
READ = 0x00020089
WRITE = 0x00000116

_COMPOSITES: Tuple[Tuple[int, str], ...] = (
    (FULL_CONTROL, "FullControl"),
    (MODIFY, "Modify"),
    (READ_AND_EXECUTE, "ReadAndExecute"),
    (READ, "Read"),
    (WRITE, "Write"),
)


def mask_to_rights(mask: int) -> str:
    """Render an access mask the way PowerShell's FileSystemRights does.

    Composite names are emitted for the standard combinations and any remaining
    bits are appended individually, comma separated.
    """
    if not mask:
        return ""

    if mask & 0x10000000:  # GENERIC_ALL implies everything
        remainder = mask & ~0x10000000
        extra = _individual(remainder)
        return "GenericAll" + (", " + extra if extra else "")

    names: List[str] = []
    remaining = mask
    for value, name in _COMPOSITES:
        if remaining & value == value:
            names.append(name)
            remaining &= ~value
    extra = _individual(remaining)
    if extra:
        names.append(extra)
    return ", ".join(n for n in names if n) or f"0x{mask:08X}"


def _individual(mask: int) -> str:
    return ", ".join(name for bit, name in _RIGHT_BITS if mask & bit)


class Ace(NamedTuple):
    """One decoded access control entry."""

    sid: str
    rights: str
    mask: int
    ace_type: str  # "Allow", "Deny" or "Audit"
    inherited: bool


class SecurityInfo(NamedTuple):
    """A decoded security descriptor."""

    owner_sid: str
    group_sid: str
    aces: List[Ace]
    audit: List[Ace]


def parse_descriptor(blob: bytes) -> Optional[SecurityInfo]:
    """Decode a self-relative security descriptor into owner + ACEs."""
    if not blob:
        return None
    try:
        sd = SR_SECURITY_DESCRIPTOR(data=blob)
    except Exception as exc:  # noqa: BLE001
        verbose(f"failed to parse security descriptor: {exc}")
        return None

    owner = _sid_str(sd, "OwnerSid")
    group = _sid_str(sd, "GroupSid")

    return SecurityInfo(
        owner_sid=owner,
        group_sid=group,
        aces=_decode_acl(sd, "Dacl"),
        audit=_decode_acl(sd, "Sacl", audit=True),
    )


def _sid_str(sd: SR_SECURITY_DESCRIPTOR, key: str) -> str:
    try:
        value = sd[key]
    except Exception:  # noqa: BLE001
        return ""
    if not value:
        return ""
    try:
        return value.formatCanonical()
    except Exception:  # noqa: BLE001
        return ""


def _decode_acl(sd: SR_SECURITY_DESCRIPTOR, key: str, audit: bool = False) -> List[Ace]:
    out: List[Ace] = []
    try:
        acl = sd[key]
    except Exception:  # noqa: BLE001
        return out
    if not acl:
        return out

    for ace in getattr(acl, "aces", []):
        try:
            ace_type_id = ace["AceType"]
            body = ace["Ace"]
            sid = body["Sid"].formatCanonical()
            mask = int(body["Mask"]["Mask"])
        except Exception:  # noqa: BLE001
            continue

        if ace_type_id in ACCESS_ALLOWED_TYPES:
            kind = "Allow"
        elif ace_type_id in ACCESS_DENIED_TYPES:
            kind = "Deny"
        elif ace_type_id in SYSTEM_AUDIT_TYPES:
            kind = "Audit"
        else:
            continue

        if audit != (kind == "Audit"):
            continue

        out.append(
            Ace(
                sid=sid,
                rights=mask_to_rights(mask),
                mask=mask,
                ace_type=kind,
                inherited=bool(ace["AceFlags"] & 0x10),
            )
        )
    return out


def get_ntfs_security(
    conn: SMBConnection,
    share: str,
    path: str = "",
    include_sacl: bool = False,
) -> Optional[SecurityInfo]:
    """Read the NTFS security descriptor of a directory inside ``share``.

    ``path`` defaults to the share root. Returns ``None`` when the caller lacks
    READ_CONTROL, the dialect is SMB1, or the server refuses the query.
    """
    smb = getattr(conn, "_SMBConnection", None)
    if smb is None or not hasattr(smb, "queryInfo"):
        verbose("NTFS ACL query needs SMB2+; skipping")
        return None

    info = OWNER_SECURITY_INFORMATION | GROUP_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION
    if include_sacl:
        info |= SACL_SECURITY_INFORMATION

    tree_id = None
    file_id = None
    try:
        tree_id = conn.connectTree(share)
        file_id = smb.create(
            tree_id,
            path,
            desiredAccess=READ_CONTROL,
            shareMode=FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            creationOptions=FILE_DIRECTORY_FILE,
            creationDisposition=FILE_OPEN,
            fileAttributes=0,
        )
        blob = smb.queryInfo(
            tree_id,
            file_id,
            infoType=SMB2_0_INFO_SECURITY,
            fileInfoClass=0,
            additionalInformation=info,
        )
        return parse_descriptor(bytes(blob))
    except Exception as exc:  # noqa: BLE001
        verbose(f"NTFS ACL query failed for {share}\\{path}: {exc}")
        return None
    finally:
        if file_id is not None and tree_id is not None:
            try:
                smb.close(tree_id, file_id)
            except Exception:  # noqa: BLE001
                pass
        if tree_id is not None:
            try:
                conn.disconnectTree(tree_id)
            except Exception:  # noqa: BLE001
                pass


def get_share_security(conn: SMBConnection, share: str) -> Optional[SecurityInfo]:
    """Read the share-level descriptor via ``NetrShareGetInfo`` level 502.

    Usually requires membership in the local Administrators group; returns
    ``None`` when access is denied, which is the normal case for a low
    privileged scan.
    """
    from impacket.dcerpc.v5 import srvs, transport

    dce = None
    try:
        rpc = transport.SMBTransport(
            conn.getRemoteHost(), filename=r"\srvsvc", smb_connection=conn
        )
        dce = rpc.get_dce_rpc()
        dce.connect()
        dce.bind(srvs.MSRPC_UUID_SRVS)
        resp = srvs.hNetrShareGetInfo(dce, share, 502)
        blob = resp["InfoStruct"]["ShareInfo502"]["shi502_security_descriptor"]
        if not blob:
            return None
        return parse_descriptor(b"".join(blob) if isinstance(blob, list) else bytes(blob))
    except Exception as exc:  # noqa: BLE001
        verbose(f"share-level ACL query failed for {share}: {exc}")
        return None
    finally:
        if dce is not None:
            try:
                dce.disconnect()
            except Exception:  # noqa: BLE001
                pass


def has_read(rights: str) -> bool:
    """Match the original module's read test: any right containing 'read'."""
    return "read" in rights.lower()


def has_write(rights: str) -> bool:
    """Match the original module's write test."""
    lowered = rights.lower()
    return any(
        token in lowered
        for token in ("genericall", "fullcontrol", "modify", "write", "create", "addfile", "appenddata", "delete")
    )
