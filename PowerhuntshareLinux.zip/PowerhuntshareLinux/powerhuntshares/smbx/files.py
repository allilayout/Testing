"""Recursive directory walking and small-file retrieval over SMB."""

from __future__ import annotations

import io
import ntpath
from typing import List, Optional, Set

from impacket.smbconnection import SMBConnection

from ..models import FileEntry
from ..util import fmt_time, parse_smb_time, verbose
from .auth import Credentials, close, connect, resolve_ip

# Directories skipped while walking: system trees produce enormous listings and
# no useful findings. Mirrors the Windows\WINNT exclusion in the original.
SKIP_DIRS = {
    "windows",
    "winnt",
    "$recycle.bin",
    "system volume information",
    "recycler",
    "msocache",
    "perflogs",
    "programdata\\package cache",
}


def walk_share(
    conn: SMBConnection,
    computer: str,
    ip: str,
    share_name: str,
    share_path: str,
    max_depth: int = 3,
    max_files: int = 50000,
) -> List[FileEntry]:
    """Breadth-first walk of a share down to ``max_depth`` nested levels.

    Breadth-first keeps the shallow, high-signal entries even when a scan hits
    the ``max_files`` ceiling on a very large share.
    """
    results: List[FileEntry] = []
    queue: List[tuple] = [("", 0)]
    seen: Set[str] = set()

    while queue and len(results) < max_files:
        rel_path, depth = queue.pop(0)
        pattern = ntpath.join(rel_path, "*") if rel_path else "*"

        try:
            entries = conn.listPath(share_name, pattern)
        except Exception as exc:  # noqa: BLE001
            verbose(f"listing failed for {share_name}\\{rel_path}: {exc}")
            continue

        for entry in entries:
            try:
                name = entry.get_longname()
            except Exception:  # noqa: BLE001
                continue
            if name in (".", ".."):
                continue

            child_rel = ntpath.join(rel_path, name) if rel_path else name
            key = child_rel.lower()
            if key in seen:
                continue
            seen.add(key)

            is_dir = bool(entry.is_directory())
            mtime = parse_smb_time(entry.get_mtime())

            results.append(
                FileEntry(
                    ComputerName=computer,
                    IpAddress=ip,
                    ShareName=share_name,
                    SharePath=share_path,
                    FilePath=f"{share_path}\\{child_rel}",
                    FileName=name,
                    IsDirectory=is_dir,
                    FileSize=0 if is_dir else int(entry.get_filesize()),
                    LastModified=fmt_time(mtime),
                    Depth=depth,
                )
            )

            if (
                is_dir
                and depth < max_depth
                and name.lower() not in SKIP_DIRS
                and key not in SKIP_DIRS
            ):
                queue.append((child_rel, depth + 1))

            if len(results) >= max_files:
                verbose(f"{share_path}: hit max-files ceiling of {max_files}")
                break

    return results


def walk_host_shares(
    computer: str,
    shares: List[tuple],
    creds: Credentials,
    max_depth: int = 3,
    max_files: int = 50000,
    timeout: int = 10,
) -> List[FileEntry]:
    """Walk several shares on one host over a single reused SMB session.

    ``shares`` is a list of ``(share_name, share_path)`` tuples.
    """
    out: List[FileEntry] = []
    conn = None
    try:
        conn = connect(computer, creds, timeout=timeout)
        ip = resolve_ip(computer)
        for share_name, share_path in shares:
            out.extend(
                walk_share(
                    conn,
                    computer,
                    ip,
                    share_name,
                    share_path,
                    max_depth=max_depth,
                    max_files=max_files,
                )
            )
    except Exception as exc:  # noqa: BLE001
        verbose(f"{computer}: file walk failed: {exc}")
    finally:
        close(conn)
    return out


def read_file(
    conn: SMBConnection,
    share_name: str,
    rel_path: str,
    max_bytes: int = 1024 * 1024,
) -> Optional[bytes]:
    """Download a file into memory, capped at ``max_bytes``.

    Used only for config files the parsers understand. Nothing is written to
    the local filesystem.
    """
    buf = io.BytesIO()
    overflow = {"hit": False}

    def sink(data: bytes) -> None:
        if overflow["hit"]:
            return
        if buf.tell() + len(data) > max_bytes:
            buf.write(data[: max_bytes - buf.tell()])
            overflow["hit"] = True
            return
        buf.write(data)

    try:
        conn.getFile(share_name, rel_path, sink)
    except Exception as exc:  # noqa: BLE001
        verbose(f"download failed for {share_name}\\{rel_path}: {exc}")
        return None
    return buf.getvalue()


def rel_path_from_unc(unc_path: str, share_name: str) -> str:
    """Turn ``\\\\host\\share\\a\\b.txt`` into ``a\\b.txt``."""
    marker = f"\\{share_name}\\"
    idx = unc_path.lower().find(marker.lower())
    if idx == -1:
        return unc_path.lstrip("\\")
    return unc_path[idx + len(marker) :]
