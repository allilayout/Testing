"""Credential handling and SMB connection setup."""

from __future__ import annotations

import socket
from dataclasses import dataclass
from typing import Optional

from impacket.smbconnection import SMBConnection

from ..util import verbose


@dataclass
class Credentials:
    """Everything needed to authenticate: password, NT hash, or Kerberos."""

    username: str = ""
    password: str = ""
    domain: str = ""
    lmhash: str = ""
    nthash: str = ""
    aes_key: str = ""
    use_kerberos: bool = False
    kdc_host: Optional[str] = None

    @classmethod
    def from_args(
        cls,
        username: str = "",
        password: str = "",
        domain: str = "",
        nt_hash: str = "",
        aes_key: str = "",
        kerberos: bool = False,
        kdc_host: Optional[str] = None,
    ) -> "Credentials":
        """Build credentials, accepting either ``NT`` or ``LM:NT`` hash form."""
        lmhash = ""
        nthash = ""
        if nt_hash:
            if ":" in nt_hash:
                lmhash, nthash = nt_hash.split(":", 1)
            else:
                nthash = nt_hash
            # An empty LM half must still be a valid hex blob for impacket.
            lmhash = lmhash or "aad3b435b51404eeaad3b435b51404ee"
        return cls(
            username=username,
            password=password,
            domain=domain,
            lmhash=lmhash,
            nthash=nthash,
            aes_key=aes_key,
            use_kerberos=kerberos or bool(aes_key),
            kdc_host=kdc_host,
        )

    @property
    def is_anonymous(self) -> bool:
        return not self.username and not self.nthash and not self.use_kerberos

    def describe(self) -> str:
        if self.use_kerberos:
            return f"Kerberos as {self.domain}\\{self.username}"
        if self.is_anonymous:
            return "anonymous / null session"
        method = "NTLM hash" if self.nthash else "password"
        return f"{self.domain}\\{self.username} ({method})"


def connect(
    host: str,
    creds: Credentials,
    port: int = 445,
    timeout: int = 10,
) -> SMBConnection:
    """Open an authenticated SMB session to ``host``.

    Raises on failure; callers run inside the thread pool which swallows the
    exception and simply drops the host from the results.
    """
    conn = SMBConnection(remoteName=host, remoteHost=host, sess_port=port, timeout=timeout)
    if creds.use_kerberos:
        conn.kerberosLogin(
            user=creds.username,
            password=creds.password,
            domain=creds.domain,
            lmhash=creds.lmhash,
            nthash=creds.nthash,
            aesKey=creds.aes_key,
            kdcHost=creds.kdc_host,
        )
    else:
        conn.login(
            user=creds.username,
            password=creds.password,
            domain=creds.domain,
            lmhash=creds.lmhash,
            nthash=creds.nthash,
        )
    verbose(f"{host}: SMB session established ({creds.describe()})")
    return conn


def close(conn: Optional[SMBConnection]) -> None:
    """Best-effort teardown; a failed logoff must never break a scan."""
    if conn is None:
        return
    try:
        conn.logoff()
    except Exception:  # noqa: BLE001
        pass
    try:
        conn.close()
    except Exception:  # noqa: BLE001
        pass


def resolve_ip(host: str) -> str:
    try:
        return socket.gethostbyname(host)
    except OSError:
        return ""
