"""SID to name resolution.

Two sources are used, cheapest first:

1. A static table of well-known SIDs (S-1-1-0 Everyone, S-1-5-11 Authenticated
   Users, the BUILTIN aliases, and the domain-relative RIDs). These cover every
   principal the excessive-privilege check actually cares about.
2. LSAT (``LsarLookupSids`` over ``\\PIPE\\lsarpc``) against the target host for
   anything else -- local accounts, domain groups, service accounts.

Resolution results are cached process-wide because the same handful of SIDs
recur across every share in a domain.
"""

from __future__ import annotations

import threading
from typing import Dict, List, Optional

from impacket.dcerpc.v5 import lsad, lsat, transport
from impacket.dcerpc.v5.dtypes import MAXIMUM_ALLOWED
from impacket.dcerpc.v5.lsat import LSAP_LOOKUP_LEVEL
from impacket.smbconnection import SMBConnection

from ..util import verbose

# SIDs that never need a network round trip.
WELL_KNOWN_SIDS: Dict[str, str] = {
    "S-1-0-0": "NULL SID",
    "S-1-1-0": "Everyone",
    "S-1-2-0": "LOCAL",
    "S-1-2-1": "CONSOLE LOGON",
    "S-1-3-0": "CREATOR OWNER",
    "S-1-3-1": "CREATOR GROUP",
    "S-1-3-4": "OWNER RIGHTS",
    "S-1-5-1": "NT AUTHORITY\\DIALUP",
    "S-1-5-2": "NT AUTHORITY\\NETWORK",
    "S-1-5-3": "NT AUTHORITY\\BATCH",
    "S-1-5-4": "NT AUTHORITY\\INTERACTIVE",
    "S-1-5-6": "NT AUTHORITY\\SERVICE",
    "S-1-5-7": "NT AUTHORITY\\ANONYMOUS LOGON",
    "S-1-5-9": "NT AUTHORITY\\ENTERPRISE DOMAIN CONTROLLERS",
    "S-1-5-11": "Authenticated Users",
    "S-1-5-12": "NT AUTHORITY\\RESTRICTED",
    "S-1-5-13": "NT AUTHORITY\\TERMINAL SERVER USER",
    "S-1-5-14": "NT AUTHORITY\\REMOTE INTERACTIVE LOGON",
    "S-1-5-15": "NT AUTHORITY\\THIS ORGANIZATION",
    "S-1-5-17": "NT AUTHORITY\\IUSR",
    "S-1-5-18": "NT AUTHORITY\\SYSTEM",
    "S-1-5-19": "NT AUTHORITY\\LOCAL SERVICE",
    "S-1-5-20": "NT AUTHORITY\\NETWORK SERVICE",
    "S-1-5-32-544": "BUILTIN\\Administrators",
    "S-1-5-32-545": "BUILTIN\\Users",
    "S-1-5-32-546": "BUILTIN\\Guests",
    "S-1-5-32-547": "BUILTIN\\Power Users",
    "S-1-5-32-548": "BUILTIN\\Account Operators",
    "S-1-5-32-549": "BUILTIN\\Server Operators",
    "S-1-5-32-550": "BUILTIN\\Print Operators",
    "S-1-5-32-551": "BUILTIN\\Backup Operators",
    "S-1-5-32-552": "BUILTIN\\Replicators",
    "S-1-5-32-554": "BUILTIN\\Pre-Windows 2000 Compatible Access",
    "S-1-5-32-555": "BUILTIN\\Remote Desktop Users",
    "S-1-5-32-556": "BUILTIN\\Network Configuration Operators",
    "S-1-5-32-558": "BUILTIN\\Performance Monitor Users",
    "S-1-5-32-559": "BUILTIN\\Performance Log Users",
    "S-1-5-32-562": "BUILTIN\\Distributed COM Users",
    "S-1-5-32-568": "BUILTIN\\IIS_IUSRS",
    "S-1-5-32-573": "BUILTIN\\Event Log Readers",
    "S-1-5-32-578": "BUILTIN\\Hyper-V Administrators",
    "S-1-5-32-580": "BUILTIN\\Remote Management Users",
    "S-1-5-33": "NT AUTHORITY\\WRITE RESTRICTED",
    "S-1-5-80-0": "NT SERVICE\\ALL SERVICES",
    "S-1-15-2-1": "APPLICATION PACKAGE AUTHORITY\\ALL APPLICATION PACKAGES",
    "S-1-16-0": "Mandatory Label\\Untrusted Mandatory Level",
    "S-1-16-4096": "Mandatory Label\\Low Mandatory Level",
    "S-1-16-8192": "Mandatory Label\\Medium Mandatory Level",
    "S-1-16-12288": "Mandatory Label\\High Mandatory Level",
    "S-1-16-16384": "Mandatory Label\\System Mandatory Level",
}

# Domain-relative RIDs, resolved without contacting the DC.
DOMAIN_RIDS: Dict[int, str] = {
    500: "Administrator",
    501: "Guest",
    502: "krbtgt",
    512: "Domain Admins",
    513: "Domain Users",
    514: "Domain Guests",
    515: "Domain Computers",
    516: "Domain Controllers",
    517: "Cert Publishers",
    518: "Schema Admins",
    519: "Enterprise Admins",
    520: "Group Policy Creator Owners",
    521: "Read-only Domain Controllers",
    525: "Protected Users",
    526: "Key Admins",
    527: "Enterprise Key Admins",
    553: "RAS and IAS Servers",
    571: "Allowed RODC Password Replication Group",
    572: "Denied RODC Password Replication Group",
}

_cache: Dict[str, str] = {}
_cache_lock = threading.Lock()


def _cache_get(sid: str) -> Optional[str]:
    with _cache_lock:
        return _cache.get(sid)


def _cache_put(sid: str, name: str) -> None:
    with _cache_lock:
        _cache[sid] = name


def resolve_static(sid: str, domain_netbios: str = "") -> Optional[str]:
    """Resolve a SID using only the built-in tables; ``None`` if unknown."""
    if sid in WELL_KNOWN_SIDS:
        return WELL_KNOWN_SIDS[sid]

    parts = sid.split("-")
    # S-1-5-21-<d1>-<d2>-<d3>-<rid> is a domain or local machine principal.
    if len(parts) == 8 and parts[:4] == ["S", "1", "5", "21"]:
        try:
            rid = int(parts[7])
        except ValueError:
            return None
        name = DOMAIN_RIDS.get(rid)
        if name:
            prefix = f"{domain_netbios}\\" if domain_netbios else ""
            return f"{prefix}{name}"
    return None


class SidResolver:
    """Resolves SIDs against one target host, falling back to the static table.

    An instance is bound to a single already-authenticated SMBConnection. If the
    LSA pipe is unavailable (common for hardened or non-domain hosts) the
    resolver silently degrades to static-only resolution.
    """

    def __init__(self, conn: Optional[SMBConnection] = None, domain_netbios: str = "") -> None:
        self.domain_netbios = domain_netbios
        self._dce = None
        self._policy = None
        self._unavailable = False
        if conn is not None:
            self._open(conn)

    def _open(self, conn: SMBConnection) -> None:
        try:
            rpc = transport.SMBTransport(
                conn.getRemoteHost(),
                filename=r"\lsarpc",
                smb_connection=conn,
            )
            dce = rpc.get_dce_rpc()
            dce.connect()
            dce.bind(lsat.MSRPC_UUID_LSAT)
            resp = lsad.hLsarOpenPolicy2(
                dce, MAXIMUM_ALLOWED | lsat.POLICY_LOOKUP_NAMES
            )
            self._dce = dce
            self._policy = resp["PolicyHandle"]
        except Exception as exc:  # noqa: BLE001
            verbose(f"LSA lookup unavailable on {conn.getRemoteHost()}: {exc}")
            self._unavailable = True

    def resolve(self, sid: str) -> str:
        """Return a display name for ``sid``, or the SID itself if unresolvable."""
        if not sid:
            return ""

        static = resolve_static(sid, self.domain_netbios)
        if static:
            return static

        cached = _cache_get(sid)
        if cached is not None:
            return cached

        name = self._lookup_lsa([sid]).get(sid, sid)
        _cache_put(sid, name)
        return name

    def resolve_many(self, sids: List[str]) -> Dict[str, str]:
        """Resolve a batch of SIDs in a single LSA call where possible."""
        out: Dict[str, str] = {}
        pending: List[str] = []

        for sid in sids:
            if not sid:
                continue
            static = resolve_static(sid, self.domain_netbios)
            if static:
                out[sid] = static
                continue
            cached = _cache_get(sid)
            if cached is not None:
                out[sid] = cached
                continue
            if sid not in pending:
                pending.append(sid)

        if pending:
            looked_up = self._lookup_lsa(pending)
            for sid in pending:
                name = looked_up.get(sid, sid)
                _cache_put(sid, name)
                out[sid] = name
        return out

    def _lookup_lsa(self, sids: List[str]) -> Dict[str, str]:
        if self._unavailable or self._dce is None or self._policy is None:
            return {}
        try:
            resp = lsat.hLsarLookupSids(
                self._dce, self._policy, sids, LSAP_LOOKUP_LEVEL.LsapLookupWksta
            )
        except Exception as exc:  # noqa: BLE001
            # A partial mapping still comes back as an exception carrying the
            # response when some SIDs could not be translated.
            resp = getattr(exc, "get_packet", lambda: None)()
            if resp is None:
                verbose(f"LsarLookupSids failed: {exc}")
                return {}

        try:
            domains = [
                d["Name"] for d in resp["ReferencedDomains"]["Domains"]
            ]
        except Exception:  # noqa: BLE001
            domains = []

        out: Dict[str, str] = {}
        try:
            entries = resp["TranslatedNames"]["Names"]
        except Exception:  # noqa: BLE001
            return out

        for sid, entry in zip(sids, entries):
            name = str(entry["Name"])
            if not name:
                continue
            idx = int(entry["DomainIndex"])
            if 0 <= idx < len(domains) and domains[idx]:
                out[sid] = f"{domains[idx]}\\{name}"
            else:
                out[sid] = name
        return out

    def close(self) -> None:
        if self._dce is not None:
            try:
                self._dce.disconnect()
            except Exception:  # noqa: BLE001
                pass
            self._dce = None
