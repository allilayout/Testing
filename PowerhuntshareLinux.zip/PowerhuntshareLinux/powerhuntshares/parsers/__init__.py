"""Config file parsers for credential extraction."""

from .base import Finding, available, get, register, run

# Importing the implementations populates the registry as a side effect.
from . import configs  # noqa: F401,E402

__all__ = ["Finding", "available", "get", "register", "run"]
