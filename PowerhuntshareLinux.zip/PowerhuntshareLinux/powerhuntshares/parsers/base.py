"""Parser registry and shared helpers.

Each parser takes the raw bytes of a config file and returns a list of
``Finding`` records. Parsers must never raise: an unparseable file is a normal
occurrence during a scan and simply yields no findings.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

Parser = Callable[[bytes], List["Finding"]]

_REGISTRY: Dict[str, Parser] = {}


@dataclass
class Finding:
    """One credential or credential-adjacent value recovered from a file."""

    name: str = ""
    section: str = ""
    url: str = ""
    server: str = ""
    port: str = ""
    username: str = ""
    password: str = ""
    notes: str = ""


def register(name: str) -> Callable[[Parser], Parser]:
    """Decorator that adds a parser to the registry under ``name``."""

    def wrap(fn: Parser) -> Parser:
        _REGISTRY[name] = fn
        return fn

    return wrap


def get(name: str) -> Optional[Parser]:
    return _REGISTRY.get(name)


def available() -> List[str]:
    return sorted(_REGISTRY)


def run(name: str, data: bytes) -> List[Finding]:
    """Run a registered parser, swallowing any failure and de-duplicating."""
    parser = _REGISTRY.get(name)
    if parser is None or not data:
        return []
    try:
        found = parser(data)
    except Exception:  # noqa: BLE001
        return []

    # Several parsers deliberately overlap (a structured pass plus a generic
    # key/value sweep), so identical findings are expected and collapsed here.
    out: List[Finding] = []
    seen = set()
    for finding in found:
        if not _is_useful(finding):
            continue
        key = (finding.username.lower(), finding.password, finding.section.lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(finding)
    return out


def _is_useful(finding: Finding) -> bool:
    """Drop findings that carry no actual secret or identity."""
    return bool(finding.password or finding.username or finding.notes)


# --- decoding helpers -------------------------------------------------------

def text(data: bytes) -> str:
    """Decode file bytes, tolerating UTF-16 and mixed encodings."""
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16", errors="replace")
    if data.startswith(b"\xef\xbb\xbf"):
        return data[3:].decode("utf-8", errors="replace")
    # Heuristic for BOM-less UTF-16LE, common in Windows-generated XML.
    if len(data) > 8 and data[1::2].count(0) > len(data) // 4:
        try:
            return data.decode("utf-16-le", errors="replace")
        except UnicodeDecodeError:
            pass
    return data.decode("utf-8", errors="replace")


def lines(data: bytes) -> List[str]:
    return [ln.rstrip("\r\n") for ln in text(data).splitlines()]


def strip_quotes(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        return value[1:-1]
    return value


# --- generic extractors -----------------------------------------------------

# Matches key=value / key: value pairs where the key looks credential-bearing.
_SECRET_KEY = re.compile(
    r"^\s*(?:set\s+|export\s+)?"
    r"(?P<key>[A-Za-z0-9_.\-]*"
    r"(?:pass(?:word|wd|phrase)?|pwd|secret|token|apikey|api_key|credential|"
    r"accesskey|access_key|privatekey|private_key|clientsecret|client_secret)"
    r"[A-Za-z0-9_.\-]*)"
    r"\s*[:=]\s*(?P<value>.+?)\s*$",
    re.IGNORECASE,
)

_USER_KEY = re.compile(
    r"^\s*(?:set\s+|export\s+)?"
    r"(?P<key>[A-Za-z0-9_.\-]*(?:user(?:name|id)?|login|account|uid)[A-Za-z0-9_.\-]*)"
    r"\s*[:=]\s*(?P<value>.+?)\s*$",
    re.IGNORECASE,
)

# Template markers that are never real credentials. Deliberately narrow:
# weak-but-real values such as "password" or "changeme" are exactly what these
# scans are meant to surface, so they are NOT filtered here.
_PLACEHOLDERS = {
    "", "*", "**", "***", "x", "xx", "xxx", "null", "none", "nil",
    "<password>", "%password%", "$password", "{password}", "${password}",
    "removed", "redacted", "n/a", "na", "todo",
}

# Boolean-ish values, filtered only for the generic key/value sweep where a
# setting like "encrypt passwords = yes" would otherwise look like a finding.
_BOOLEANS = {"yes", "no", "true", "false", "on", "off", "0", "1", "enabled", "disabled"}

# Keys whose names contain "password"/"passwd" but whose values are hostnames,
# paths or toggles rather than secrets.
NON_SECRET_KEYS = {
    "krb5_kpasswd", "krb5_passwd", "kpasswd_server", "password server",
    "passwd program", "passwd chat", "encrypt passwords", "null passwords",
    "unix password sync", "pam password change", "passwd backend",
    "obey pam restrictions", "ldap_pwd_policy", "password_hash",
    "passwordformat", "passwordstrengthregularexpression", "password_min_length",
}


def is_placeholder(value: str) -> bool:
    return strip_quotes(value).strip().lower() in _PLACEHOLDERS


def is_boolean(value: str) -> bool:
    """True for toggles and short bare numbers.

    Settings such as ``offline_credentials_expiration = 2`` match the
    credential key patterns but never hold a secret. Numbers of six digits or
    more are kept, since those can legitimately be a numeric password or PIN.
    """
    cleaned = strip_quotes(value).strip().lower()
    if cleaned in _BOOLEANS:
        return True
    return cleaned.isdigit() and len(cleaned) < 6


def is_non_secret_key(key: str) -> bool:
    return key.strip().lower() in NON_SECRET_KEYS


def strip_inline_comment(value: str) -> str:
    """Remove trailing ``;`` / ``#`` / ``<!-- -->`` comments from a value.

    Sample and real-world config files frequently annotate the very lines that
    hold credentials, and the comment must not end up inside the password.
    """
    value = re.sub(r"<!--.*?-->", "", value)
    # Only treat ; and # as comment starts when preceded by whitespace, so
    # they remain usable inside a password.
    value = re.split(r"\s+[;#]\s", value, maxsplit=1)[0]
    return value.strip()


def generic_key_value(data: bytes, section_label: str = "") -> List[Finding]:
    """Fallback scanner for any line-oriented config format.

    Pairs each secret-looking key with the nearest preceding user-looking key,
    which is how these formats are almost always laid out.
    """
    out: List[Finding] = []
    current_section = section_label
    last_user = ""

    for line in lines(data):
        stripped = line.strip()
        if not stripped or stripped[0] in "#;":
            continue

        if stripped.startswith("[") and stripped.endswith("]"):
            current_section = stripped[1:-1]
            last_user = ""
            continue

        user_match = _USER_KEY.match(line)
        if user_match:
            value = strip_quotes(strip_inline_comment(user_match.group("value")))
            if value and not is_placeholder(value):
                last_user = value

        secret_match = _SECRET_KEY.match(line)
        if secret_match:
            key = secret_match.group("key").strip()
            value = strip_quotes(strip_inline_comment(secret_match.group("value")))
            if (
                value
                and not is_placeholder(value)
                and not is_boolean(value)
                and not is_non_secret_key(key)
            ):
                out.append(
                    Finding(
                        name=key,
                        section=current_section,
                        username=last_user,
                        password=value,
                    )
                )
                last_user = ""
    return out


def xml_root(data: bytes):
    """Parse XML defensively, returning ``None`` on malformed input.

    External entities are disabled by ElementTree's default parser, so a
    hostile config file on a share cannot trigger an XXE read of the scanning
    host.
    """
    import xml.etree.ElementTree as ET

    try:
        return ET.fromstring(text(data))
    except Exception:  # noqa: BLE001
        return None


def local_name(tag: str) -> str:
    """Strip an XML namespace from a tag name."""
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def iter_elements(root):
    if root is None:
        return
    yield root
    for child in root.iter():
        if child is not root:
            yield child


def attr_ci(element, name: str) -> str:
    """Case-insensitive attribute lookup."""
    lowered = name.lower()
    for key, value in element.attrib.items():
        if local_name(key).lower() == lowered:
            return value
    return ""
