"""Config file parsers.

A port of the ``Scripts/ConfigParsers`` collection from the original project,
plus a few additions. Every parser is registered by the short name referenced
in the keyword table.
"""

from __future__ import annotations

import base64
import configparser
import io
import re
from typing import List

from .base import (
    Finding,
    attr_ci,
    generic_key_value,
    is_boolean,
    is_non_secret_key,
    is_placeholder,
    iter_elements,
    lines,
    local_name,
    register,
    strip_inline_comment,
    strip_quotes,
    text,
    xml_root,
)


# ---------------------------------------------------------------------------
# .NET configuration files (web.config, app.config, machine.config)
# ---------------------------------------------------------------------------

_CONN_SERVER = re.compile(r"(?:server|data source|host)\s*=\s*([^;,]+)(?:,(\d+))?", re.I)
_CONN_USER = re.compile(r"(?:user\s*id|uid|username|user)\s*=\s*([^;]+)", re.I)
_CONN_PASS = re.compile(r"(?:password|pwd)\s*=\s*([^;]+)", re.I)
_CONN_PORT = re.compile(r"port\s*=\s*(\d+)", re.I)


def _parse_connection_string(name: str, conn: str, provider: str = "") -> List[Finding]:
    user = _CONN_USER.search(conn)
    password = _CONN_PASS.search(conn)
    if not password:
        return []

    server_match = _CONN_SERVER.search(conn)
    server = server_match.group(1).strip() if server_match else ""
    port = ""
    if server_match and server_match.group(2):
        port = server_match.group(2)
    else:
        port_match = _CONN_PORT.search(conn)
        if port_match:
            port = port_match.group(1)

    return [
        Finding(
            name=name or "ConnectionString",
            section=f"ConnectionStrings ({provider})" if provider else "ConnectionStrings",
            url=f"Server={server}" if server else "",
            server=server,
            port=port,
            username=user.group(1).strip() if user else "",
            password=password.group(1).strip(),
        )
    ]


# App setting keys that pair into a single credential.
_APPSETTING_PAIRS = {
    "oauthserviceurl": ("OAuth", "url"),
    "clientid": ("OAuth", "username"),
    "clientsecret": ("OAuth", "password"),
    "serviceurl": ("WebClient", "url"),
    "serviceusername": ("WebClient", "username"),
    "servicepassword": ("WebClient", "password"),
    "apiendpoint": ("API", "url"),
    "apiusername": ("API", "username"),
    "apipassword": ("API", "password"),
    "applicationusername": ("Application", "username"),
    "applicationpassword": ("Application", "password"),
    "username": ("CustomService", "username"),
    "password": ("CustomService", "password"),
}


@register("web_config")
@register("app_config")
@register("machine_config")
def parse_dotnet_config(data: bytes) -> List[Finding]:
    """Extract credentials from a .NET XML configuration file."""
    root = xml_root(data)
    if root is None:
        return generic_key_value(data, "config")

    out: List[Finding] = []
    pairs: dict = {}

    for element in iter_elements(root):
        tag = local_name(element.tag).lower()

        if tag == "add":
            key = attr_ci(element, "key")
            value = attr_ci(element, "value")
            conn = attr_ci(element, "connectionString")

            if conn:
                out.extend(
                    _parse_connection_string(
                        attr_ci(element, "name"), conn, attr_ci(element, "providerName")
                    )
                )
            elif key and value and not is_placeholder(value):
                mapping = _APPSETTING_PAIRS.get(key.lower())
                if mapping:
                    group, field = mapping
                    pairs.setdefault(group, {})[field] = value
                elif "password" in key.lower() or "secret" in key.lower():
                    out.append(Finding(name=key, section="AppSettings", password=value))

        elif tag == "user":
            # <credentials><user name= password= /></credentials>
            name = attr_ci(element, "name")
            password = attr_ci(element, "password")
            if password and not is_placeholder(password):
                out.append(
                    Finding(
                        name="Forms Authentication",
                        section="system.web/authentication",
                        username=name,
                        password=password,
                    )
                )

        elif tag == "network":
            # SMTP settings under system.net/mailSettings.
            host = attr_ci(element, "host")
            port = attr_ci(element, "port")
            user = attr_ci(element, "userName")
            password = attr_ci(element, "password")
            if password and not is_placeholder(password):
                out.append(
                    Finding(
                        name="SMTP Configuration",
                        section="system.net/mailSettings",
                        url=f"smtp://{host}:{port}" if host else "",
                        server=host,
                        port=port,
                        username=user,
                        password=password,
                    )
                )

        elif tag in ("username", "clientcredentials", "windowsauthentication"):
            # WCF <userName userName= password= />
            user = attr_ci(element, "userName")
            password = attr_ci(element, "password")
            if password and not is_placeholder(password):
                out.append(
                    Finding(
                        name="WCF Client Credentials",
                        section="system.serviceModel",
                        username=user,
                        password=password,
                    )
                )

        elif tag == "processmodel":
            user = attr_ci(element, "userName")
            password = attr_ci(element, "password")
            if password and not is_placeholder(password):
                out.append(
                    Finding(
                        name="ProcessModel Identity",
                        section="system.web/processModel",
                        username=user,
                        password=password,
                    )
                )

        elif tag == "identity":
            user = attr_ci(element, "userName")
            password = attr_ci(element, "password")
            if password and not is_placeholder(password):
                out.append(
                    Finding(
                        name="Application Identity",
                        section="system.web/identity",
                        username=user,
                        password=password,
                    )
                )

    for group, values in pairs.items():
        if values.get("password"):
            out.append(
                Finding(
                    name=group,
                    section="AppSettings",
                    url=values.get("url", ""),
                    username=values.get("username", ""),
                    password=values["password"],
                )
            )
    return out


# ---------------------------------------------------------------------------
# Tomcat / JBoss / Jenkins
# ---------------------------------------------------------------------------

@register("tomcat_users")
def parse_tomcat_users(data: bytes) -> List[Finding]:
    root = xml_root(data)
    if root is None:
        return []
    out: List[Finding] = []
    for element in iter_elements(root):
        if local_name(element.tag).lower() != "user":
            continue
        password = attr_ci(element, "password")
        if not password or is_placeholder(password):
            continue
        out.append(
            Finding(
                name="Tomcat User",
                section=attr_ci(element, "roles"),
                username=attr_ci(element, "username") or attr_ci(element, "name"),
                password=password,
                notes=f"roles={attr_ci(element, 'roles')}" if attr_ci(element, "roles") else "",
            )
        )
    return out


# Attributes across Tomcat, JBoss and IBM Liberty that hold a secret.
_JAVA_PASSWORD_ATTRS = (
    "password", "connectionPassword", "keystorePass", "truststorePass",
    "keyStorePassword", "trustStorePassword", "certificateKeystorePassword",
    "SSLPassword", "bindPassword",
)

_JAVA_USER_ATTRS = (
    "username", "user", "connectionName", "userName", "bindDN", "id", "name",
)


@register("server_xml")
@register("context_xml")
def parse_java_server_xml(data: bytes) -> List[Finding]:
    """Extract credentials from Java application server XML.

    Covers Tomcat ``server.xml``/``context.xml`` JNDI resources and realms, and
    IBM Liberty's ``<keyStore>``, ``<basicRegistry>`` and ``<authData>``
    elements, which use the same file name but a different schema.
    """
    root = xml_root(data)
    if root is None:
        return []

    interesting_tags = {
        "resource", "connector", "realm", "parameter", "user", "keystore",
        "authdata", "datasource", "properties", "ldapregistry", "basicregistry",
    }

    out: List[Finding] = []
    for element in iter_elements(root):
        tag = local_name(element.tag).lower()
        if tag not in interesting_tags and not tag.startswith("properties"):
            continue

        password = ""
        for attr in _JAVA_PASSWORD_ATTRS:
            password = attr_ci(element, attr)
            if password:
                break
        if not password or is_placeholder(password):
            continue

        username = ""
        for attr in _JAVA_USER_ATTRS:
            username = attr_ci(element, attr)
            if username:
                break

        url = attr_ci(element, "url") or attr_ci(element, "connectionURL")
        note = attr_ci(element, "driverClassName") or attr_ci(element, "location")
        if tag == "keystore":
            note = note or "Keystore password - unlocks the server's private keys"

        out.append(
            Finding(
                name=attr_ci(element, "name") or attr_ci(element, "id") or tag.capitalize(),
                section=tag,
                url=url,
                username=username,
                password=password,
                notes=note,
            )
        )
    return out


@register("standalone_xml")
@register("jboss_cli")
def parse_jboss(data: bytes) -> List[Finding]:
    root = xml_root(data)
    if root is None:
        return generic_key_value(data, "jboss")

    out: List[Finding] = []
    for element in iter_elements(root):
        tag = local_name(element.tag).lower()

        if tag == "password":
            value = (element.text or "").strip()
            if value and not is_placeholder(value):
                out.append(Finding(name="JBoss Password", section=tag, password=value))
        elif tag == "user":
            value = (element.text or "").strip()
            if value:
                out.append(Finding(name="JBoss User", section=tag, username=value))
        elif tag in ("datasource", "xa-datasource", "security"):
            password = attr_ci(element, "password")
            if password and not is_placeholder(password):
                out.append(
                    Finding(
                        name=attr_ci(element, "pool-name") or "JBoss DataSource",
                        section=tag,
                        username=attr_ci(element, "user-name") or attr_ci(element, "username"),
                        password=password,
                    )
                )

    # <security><user-name>x</user-name><password>y</password></security>
    merged = _merge_sibling_credentials(root)
    out.extend(merged)
    return out


def _merge_sibling_credentials(root) -> List[Finding]:
    """Pair <user-name>/<password> child elements under a common parent."""
    out: List[Finding] = []
    for parent in iter_elements(root):
        user = ""
        password = ""
        for child in list(parent):
            name = local_name(child.tag).lower()
            value = (child.text or "").strip()
            if name in ("user-name", "username", "user"):
                user = value
            elif name in ("password", "pass"):
                password = value
        if password and not is_placeholder(password):
            out.append(
                Finding(
                    name=local_name(parent.tag),
                    section="xml",
                    username=user,
                    password=password,
                )
            )
    return out


@register("jenkins_config")
def parse_jenkins_config(data: bytes) -> List[Finding]:
    root = xml_root(data)
    if root is None:
        return generic_key_value(data, "jenkins")

    out: List[Finding] = []
    for element in iter_elements(root):
        tag = local_name(element.tag).lower()
        value = (element.text or "").strip()
        if not value:
            continue
        if tag in ("passwordhash", "password", "apitoken", "secret", "privatekey"):
            out.append(
                Finding(
                    name="Jenkins Credential",
                    section=tag,
                    password=value,
                    notes="Jenkins secrets are AES encrypted with master.key + hudson.util.Secret; "
                    "recover those files to decrypt.",
                )
            )
        elif tag in ("fullname", "id", "username"):
            out.append(Finding(name="Jenkins User", section=tag, username=value))
    return out


# ---------------------------------------------------------------------------
# Unix-style credential files
# ---------------------------------------------------------------------------

@register("shadow")
def parse_shadow(data: bytes) -> List[Finding]:
    """Parse /etc/shadow, keeping only entries with a real hash."""
    out: List[Finding] = []
    for line in lines(data):
        if not line.strip() or line.startswith("#"):
            continue
        parts = line.split(":")
        if len(parts) < 2:
            continue
        user, digest = parts[0], parts[1]
        # "*", "!" and "!!" mean the account has no usable password.
        if not digest or digest in ("*", "!", "!!", "x") or digest.startswith("!"):
            continue
        algo = {
            "$1$": "MD5crypt", "$2a$": "bcrypt", "$2b$": "bcrypt", "$2y$": "bcrypt",
            "$5$": "SHA-256crypt", "$6$": "SHA-512crypt", "$y$": "yescrypt",
            "$7$": "scrypt", "$gy$": "gost-yescrypt",
        }
        detected = next((v for k, v in algo.items() if digest.startswith(k)), "DES/unknown")
        out.append(
            Finding(
                name="Local Account",
                section="shadow",
                username=user,
                password=digest,
                notes=f"{detected} hash - crackable offline",
            )
        )
    return out


@register("htpasswd")
def parse_htpasswd(data: bytes) -> List[Finding]:
    out: List[Finding] = []
    for line in lines(data):
        if not line.strip() or line.startswith("#") or ":" not in line:
            continue
        user, _, digest = line.partition(":")
        if not digest:
            continue
        if digest.startswith("$apr1$"):
            note = "Apache MD5 (APR1) hash"
        elif digest.startswith("{SHA}"):
            note = "SHA1 hash"
        elif digest.startswith("$2"):
            note = "bcrypt hash"
        else:
            note = "crypt or plaintext"
        out.append(
            Finding(
                name="HTTP Basic Auth",
                section="htpasswd",
                username=user.strip(),
                password=digest.strip(),
                notes=note,
            )
        )
    return out


@register("pgpass")
def parse_pgpass(data: bytes) -> List[Finding]:
    """Parse .pgpass: host:port:database:username:password, cleartext."""
    out: List[Finding] = []
    for line in lines(data):
        if not line.strip() or line.startswith("#"):
            continue
        parts = line.split(":")
        if len(parts) < 5:
            continue
        host, port, database, user = parts[0], parts[1], parts[2], parts[3]
        password = ":".join(parts[4:])
        if not password:
            continue
        out.append(
            Finding(
                name="PostgreSQL",
                section=database,
                url=f"postgresql://{host}:{port}/{database}",
                server=host,
                port=port,
                username=user,
                password=password,
                notes="Cleartext credential",
            )
        )
    return out


@register("netrc")
def parse_netrc(data: bytes) -> List[Finding]:
    """Parse .netrc token streams into machine/login/password triples."""
    tokens = text(data).split()
    out: List[Finding] = []
    machine = login = password = ""

    index = 0
    while index < len(tokens):
        token = tokens[index].lower()
        if token in ("machine", "default"):
            if password:
                out.append(
                    Finding(
                        name="netrc", section="netrc", server=machine,
                        username=login, password=password, notes="Cleartext credential",
                    )
                )
            machine = tokens[index + 1] if token == "machine" and index + 1 < len(tokens) else "default"
            login = password = ""
            index += 2 if token == "machine" else 1
            continue
        if token in ("login", "user") and index + 1 < len(tokens):
            login = tokens[index + 1]
            index += 2
            continue
        if token == "password" and index + 1 < len(tokens):
            password = tokens[index + 1]
            index += 2
            continue
        index += 1

    if password:
        out.append(
            Finding(
                name="netrc", section="netrc", server=machine,
                username=login, password=password, notes="Cleartext credential",
            )
        )
    return out


@register("fetchmailrc")
def parse_fetchmailrc(data: bytes) -> List[Finding]:
    out: List[Finding] = []
    pattern = re.compile(
        r"poll\s+(?P<server>\S+).*?user(?:name)?\s+'?\"?(?P<user>[^'\"\s]+).*?"
        r"pass(?:word)?\s+'?\"?(?P<pass>[^'\"\s]+)",
        re.I | re.S,
    )
    for match in pattern.finditer(text(data)):
        out.append(
            Finding(
                name="Fetchmail", section="poll",
                server=match.group("server"),
                username=match.group("user"),
                password=match.group("pass"),
                notes="Cleartext credential",
            )
        )
    return out


@register("git_credentials")
def parse_git_credentials(data: bytes) -> List[Finding]:
    """Parse .git-credentials URLs of the form https://user:token@host."""
    out: List[Finding] = []
    pattern = re.compile(r"^(?P<scheme>\w+)://(?P<user>[^:@/]+):(?P<pass>[^@/]+)@(?P<host>\S+)$")
    for line in lines(data):
        match = pattern.match(line.strip())
        if not match:
            continue
        from urllib.parse import unquote

        out.append(
            Finding(
                name="Git Credential",
                section="git",
                url=f"{match.group('scheme')}://{match.group('host')}",
                server=match.group("host"),
                username=unquote(match.group("user")),
                password=unquote(match.group("pass")),
                notes="Cleartext credential or personal access token",
            )
        )
    return out


@register("smb_conf")
@register("sssd_conf")
@register("krb5_conf")
@register("my_cnf")
@register("php_ini")
@register("ini_file")
@register("bootstrap_ini")
@register("dbx_driver_ini")
def parse_ini(data: bytes) -> List[Finding]:
    """Generic INI parser covering smb.conf, my.cnf, php.ini and friends."""
    parser = configparser.RawConfigParser(strict=False, allow_no_value=True, delimiters=("=", ":"))
    parser.optionxform = str  # preserve key case

    content = text(data)
    findings: List[Finding] = []
    try:
        parser.read_file(io.StringIO(content))
    except Exception:  # noqa: BLE001
        return generic_key_value(data, "ini")

    secret_keys = (
        "password", "passwd", "pwd", "secret", "token", "apikey", "api_key",
        "adminpassword", "userpassword", "ldap_default_authtok", "bindpw",
    )
    user_keys = ("user", "username", "login", "adminid", "ldap_default_bind_dn", "binddn")

    for section in parser.sections():
        username = ""
        for key, value in parser.items(section):
            if not value:
                continue
            if any(u == key.lower() for u in user_keys):
                username = strip_quotes(strip_inline_comment(value))

        for key, value in parser.items(section):
            if not value:
                continue
            cleaned = strip_quotes(strip_inline_comment(value))
            if not cleaned or is_placeholder(cleaned) or is_boolean(cleaned):
                continue
            if is_non_secret_key(key):
                continue
            if any(s in key.lower() for s in secret_keys):
                findings.append(
                    Finding(
                        name=key,
                        section=section,
                        username=username,
                        password=cleaned,
                        server=strip_quotes(parser.get(section, "host", fallback="") or ""),
                    )
                )

    # Values outside any named section, which configparser will not surface.
    findings.extend(generic_key_value(data, "global"))
    return findings


@register("grub_config")
def parse_grub(data: bytes) -> List[Finding]:
    """Extract GRUB bootloader passwords from grub.cfg / grub.conf."""
    out: List[Finding] = []
    # Anchored to the start of a line so prose inside comments is not matched.
    pattern = re.compile(r"^\s*password(?:_pbkdf2)?\s+(?P<user>\S+)\s+(?P<pass>\S+)", re.I)
    for line in lines(data):
        if line.lstrip().startswith("#"):
            continue
        match = pattern.match(line)
        if not match:
            continue
        password = match.group("pass")
        out.append(
            Finding(
                name="GRUB Bootloader",
                section="grub",
                username=match.group("user"),
                password=password,
                notes="PBKDF2 hash"
                if password.startswith("grub.pbkdf2")
                else "Cleartext password - grants boot-time root shell",
            )
        )
    return out


@register("pureftpd_passwd")
def parse_pureftpd(data: bytes) -> List[Finding]:
    out: List[Finding] = []
    for line in lines(data):
        parts = line.split(":")
        if len(parts) < 2 or not parts[1] or parts[1] in ("*", "!"):
            continue
        out.append(
            Finding(
                name="Pure-FTPd Account",
                section="pureftpd",
                username=parts[0],
                password=parts[1],
                notes="Password hash",
            )
        )
    return out


# ---------------------------------------------------------------------------
# Windows client configuration
# ---------------------------------------------------------------------------

@register("winscp_ini")
def parse_winscp(data: bytes) -> List[Finding]:
    """Extract WinSCP sessions; passwords are obfuscated, not encrypted."""
    out: List[Finding] = []
    session = {}
    for line in lines(data):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            out.extend(_emit_winscp(session))
            session = {"name": stripped[1:-1]}
            continue
        if "=" in stripped:
            key, _, value = stripped.partition("=")
            session[key.strip().lower()] = strip_inline_comment(value)
    out.extend(_emit_winscp(session))
    return out


def _emit_winscp(session: dict) -> List[Finding]:
    password = session.get("password", "")
    if not password:
        return []
    hostname = session.get("hostname", "")
    username = session.get("username", "")
    plain = _winscp_decrypt(password, username, hostname)
    return [
        Finding(
            name="WinSCP Session",
            section=session.get("name", ""),
            url=f"{session.get('fsprotocol', '')}://{hostname}",
            server=hostname,
            port=session.get("portnumber", ""),
            username=username,
            password=plain or password,
            notes="Decoded from WinSCP obfuscation" if plain else "WinSCP obfuscated value",
        )
    ]


_WINSCP_MAGIC = 0xA3
_WINSCP_FLAG = 0xFF


def _winscp_decrypt(encoded: str, username: str, hostname: str) -> str:
    """Reverse WinSCP's session password obfuscation.

    WinSCP stores session passwords with a reversible nibble transform keyed on
    ``username+hostname``. It is obfuscation rather than encryption, so the
    cleartext is recoverable whenever the .ini file is readable.
    """
    try:
        values = [int(encoded[i : i + 2], 16) for i in range(0, len(encoded) - 1, 2)]
    except ValueError:
        return ""
    if not values:
        return ""

    index = 0

    def next_byte() -> int:
        nonlocal index
        if index >= len(values):
            raise IndexError
        value = ((~((values[index] << 4) | (values[index] >> 4) & 0xFF)) ^ _WINSCP_MAGIC) & 0xFF
        index += 1
        return value

    try:
        flag = next_byte()
        if flag == _WINSCP_FLAG:
            next_byte()  # discard
            length = next_byte()
        else:
            length = flag
        index += next_byte()  # skip the random prefix
        result = "".join(chr(next_byte()) for _ in range(length))
    except (IndexError, ValueError):
        return ""

    key = f"{username}{hostname}"
    if key and result.startswith(key):
        return result[len(key) :]
    return result if not key else ""


@register("putty_reg")
def parse_putty_reg(data: bytes) -> List[Finding]:
    """Extract PuTTY session details from an exported .reg file."""
    out: List[Finding] = []
    session = ""
    values: dict = {}
    for line in lines(data):
        stripped = line.strip()
        if stripped.startswith("[") and "Sessions" in stripped:
            out.extend(_emit_putty(session, values))
            session = stripped.rstrip("]").split("\\")[-1]
            values = {}
            continue
        if "=" in stripped:
            key, _, value = stripped.partition("=")
            values[strip_quotes(key).lower()] = strip_quotes(strip_inline_comment(value))
    out.extend(_emit_putty(session, values))
    return out


def _emit_putty(session: str, values: dict) -> List[Finding]:
    if not session:
        return []
    from urllib.parse import unquote

    hostname = values.get("hostname", "")
    username = values.get("username", "")
    keyfile = values.get("publickeyfile", "")
    proxy_pass = values.get("proxypassword", "")
    if not (username or keyfile or proxy_pass):
        return []
    return [
        Finding(
            name="PuTTY Session",
            section=unquote(session),
            server=hostname,
            port=values.get("portnumber", ""),
            username=username,
            password=proxy_pass,
            notes=f"private key: {keyfile}" if keyfile else "",
        )
    ]


@register("vnc_ini")
def parse_vnc(data: bytes) -> List[Finding]:
    """Extract VNC passwords, which use a fixed, published DES key."""
    out: List[Finding] = []
    for line in lines(data):
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip().lower()
        value = value.strip()
        if key in ("password", "passwd", "passwdviewonly", "controlpassword") and value:
            plain = _vnc_decrypt(value)
            out.append(
                Finding(
                    name="VNC Password",
                    section=key,
                    password=plain or value,
                    notes="Decrypted with the fixed VNC DES key"
                    if plain
                    else "VNC obfuscated value (fixed DES key: 0x e84ad660c4721ae0)",
                )
            )
    return out


def _vnc_decrypt(hex_value: str) -> str:
    """Decrypt a VNC stored password using the well-known fixed DES key."""
    try:
        from Cryptodome.Cipher import DES  # type: ignore
    except ImportError:
        try:
            from Crypto.Cipher import DES  # type: ignore
        except ImportError:
            return ""

    try:
        blob = bytes.fromhex(hex_value.strip())
    except ValueError:
        return ""
    if len(blob) < 8:
        return ""

    key = bytes([0xE8, 0x4A, 0xD6, 0x60, 0xC4, 0x72, 0x1A, 0xE0])
    try:
        cipher = DES.new(key, DES.MODE_ECB)
        plain = cipher.decrypt(blob[:8])
        return plain.rstrip(b"\x00").decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        return ""


@register("rdp_file")
def parse_rdp(data: bytes) -> List[Finding]:
    out: List[Finding] = []
    server = username = ""
    password_blob = ""
    for line in lines(data):
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip().lower()
        value = value.split(":", 1)[-1].strip() if value.count(":") >= 1 else value.strip()
        if key == "full address":
            server = value
        elif key == "username":
            username = value
        elif key == "password 51":
            password_blob = value

    if username or password_blob:
        out.append(
            Finding(
                name="RDP Connection",
                section="rdp",
                server=server,
                username=username,
                password=password_blob,
                notes="DPAPI blob - decryptable only in the original user context"
                if password_blob
                else "",
            )
        )
    return out


@register("sitemanager_xml")
def parse_filezilla(data: bytes) -> List[Finding]:
    """Extract FileZilla sites; passwords are stored base64 encoded."""
    root = xml_root(data)
    if root is None:
        return []
    out: List[Finding] = []
    for element in iter_elements(root):
        if local_name(element.tag).lower() != "server":
            continue
        values = {local_name(c.tag).lower(): (c.text or "").strip() for c in element}
        password = values.get("pass", "")
        if password:
            try:
                password = base64.b64decode(password).decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                pass
        if not (password or values.get("user")):
            continue
        out.append(
            Finding(
                name="FileZilla Site",
                section=values.get("name", ""),
                server=values.get("host", ""),
                port=values.get("port", ""),
                username=values.get("user", ""),
                password=password,
                notes="Base64 encoded, not encrypted",
            )
        )
    return out


@register("dbvis_xml")
def parse_dbvis(data: bytes) -> List[Finding]:
    """Extract DbVisualizer connections.

    Newer versions encrypt the password with DES under a fixed key (or a user
    master password); older ones store base64. The stored value is reported
    either way so it can be cracked or decrypted offline.
    """
    root = xml_root(data)
    if root is None:
        return []

    out: List[Finding] = []
    for element in iter_elements(root):
        if local_name(element.tag).lower() not in ("database", "connection"):
            continue

        values = {local_name(c.tag).lower(): (c.text or "").strip() for c in element}
        password = values.get("password", "")
        if not password:
            continue

        note = "DES encrypted with the fixed DbVisualizer key or a master password"
        # Older releases stored a plain base64 blob; decode when it round-trips
        # cleanly to printable text.
        try:
            decoded = base64.b64decode(password, validate=True).decode("utf-8")
            if decoded.isprintable():
                password, note = decoded, "Base64 encoded, not encrypted"
        except Exception:  # noqa: BLE001
            pass

        out.append(
            Finding(
                name="DbVisualizer Connection",
                section=values.get("alias", "") or values.get("name", ""),
                url=values.get("urlvarvalue", "") or values.get("url", ""),
                server=values.get("server", ""),
                port=values.get("port", ""),
                username=values.get("userid", "") or values.get("user", ""),
                password=password,
                notes=note,
            )
        )
    return out


@register("remmina")
@register("remmina_pref")
def parse_remmina(data: bytes) -> List[Finding]:
    out: List[Finding] = []
    values: dict = {}
    for line in lines(data):
        if "=" in line and not line.strip().startswith("#"):
            key, _, value = line.partition("=")
            values[key.strip().lower()] = strip_inline_comment(value)

    password = values.get("password", "")
    secret = values.get("secret", "")
    if password:
        out.append(
            Finding(
                name="Remmina Connection",
                section=values.get("name", ""),
                server=values.get("server", ""),
                username=values.get("username", ""),
                password=password,
                notes="3DES encrypted with the 'secret' key from remmina.pref",
            )
        )
    if secret:
        out.append(
            Finding(
                name="Remmina Master Secret",
                section="remmina.pref",
                password=secret,
                notes="Decrypts every stored Remmina password",
            )
        )
    return out


# ---------------------------------------------------------------------------
# Deployment and Group Policy
# ---------------------------------------------------------------------------

# The AES-256 key Microsoft published in MS-GPPREF, making every cpassword
# value in SYSVOL trivially decryptable (MS14-025).
_GPP_KEY = bytes([
    0x4E, 0x99, 0x06, 0xE8, 0xFC, 0xB6, 0x6C, 0xC9, 0xFA, 0xF4, 0x93, 0x10,
    0x62, 0x0F, 0xFE, 0xE8, 0xF4, 0x96, 0xE8, 0x06, 0xCC, 0x05, 0x79, 0x90,
    0x20, 0x9B, 0x09, 0xA4, 0x33, 0xB6, 0x6C, 0x1B,
])


def decrypt_cpassword(cpassword: str) -> str:
    """Decrypt a Group Policy Preferences cpassword value."""
    if not cpassword:
        return ""
    try:
        from Cryptodome.Cipher import AES  # type: ignore
    except ImportError:
        try:
            from Crypto.Cipher import AES  # type: ignore
        except ImportError:
            return ""

    padded = cpassword + "=" * ((4 - len(cpassword) % 4) % 4)
    try:
        blob = base64.b64decode(padded)
        cipher = AES.new(_GPP_KEY, AES.MODE_CBC, b"\x00" * 16)
        plain = cipher.decrypt(blob)
        plain = plain[: -plain[-1]] if plain and plain[-1] <= 16 else plain
        return plain.decode("utf-16-le", errors="replace").rstrip("\x00")
    except Exception:  # noqa: BLE001
        return ""


@register("gpp")
def parse_gpp(data: bytes) -> List[Finding]:
    """Extract and decrypt cpassword values from Group Policy Preferences XML."""
    root = xml_root(data)
    if root is None:
        return []

    out: List[Finding] = []
    for element in iter_elements(root):
        cpassword = attr_ci(element, "cpassword")
        if not cpassword:
            continue
        username = (
            attr_ci(element, "userName")
            or attr_ci(element, "runAs")
            or attr_ci(element, "accountName")
            or attr_ci(element, "newName")
        )
        plain = decrypt_cpassword(cpassword)
        out.append(
            Finding(
                name="Group Policy Preferences",
                section=local_name(element.tag),
                username=username,
                password=plain or cpassword,
                notes="Decrypted with the published MS14-025 AES key"
                if plain
                else "cpassword (install pycryptodome to decrypt)",
            )
        )
    return out


@register("unattend")
@register("sysprep")
def parse_unattend(data: bytes) -> List[Finding]:
    """Extract credentials from unattend.xml / sysprep answer files."""
    root = xml_root(data)
    if root is None:
        return generic_key_value(data, "unattend")

    out: List[Finding] = []
    for element in iter_elements(root):
        tag = local_name(element.tag).lower()
        if tag not in ("administratorpassword", "password", "userpassword"):
            continue

        value = ""
        plaintext_flag = True
        for child in element:
            child_tag = local_name(child.tag).lower()
            if child_tag == "value":
                value = (child.text or "").strip()
            elif child_tag == "plaintext":
                plaintext_flag = (child.text or "").strip().lower() == "true"
        if not value:
            value = (element.text or "").strip()
        if not value or is_placeholder(value):
            continue

        note = "Cleartext"
        if not plaintext_flag:
            decoded = _decode_unattend_password(value)
            if decoded:
                value, note = decoded, "Base64 decoded"
            else:
                note = "Base64 encoded - could not decode"

        username = _nearby_username(root, element)
        out.append(
            Finding(
                name="Unattend Answer File",
                section=local_name(element.tag),
                username=username,
                password=value,
                notes=note,
            )
        )
    return out


def _decode_unattend_password(value: str) -> str:
    """Decode an answer-file password blob.

    Windows encodes these as UTF-16LE with the field name appended before
    base64, but hand-written and tool-generated files are often plain ASCII, so
    both encodings are tried and the more plausible result wins.
    """
    try:
        raw = base64.b64decode(value, validate=True)
    except Exception:  # noqa: BLE001
        return ""

    def ascii_ratio(value: str) -> float:
        if not value:
            return 0.0
        return sum(1 for ch in value if 32 <= ord(ch) < 127) / len(value)

    best = ""
    best_score = 0.0
    for encoding in ("utf-16-le", "utf-8", "latin-1"):
        try:
            candidate = raw.decode(encoding)
        except UnicodeDecodeError:
            continue
        if not candidate or not candidate.isprintable():
            continue
        # A wrong encoding still "decodes" but yields CJK-looking output, so
        # rank candidates by how much of the result is plain ASCII.
        score = ascii_ratio(candidate)
        if score > best_score:
            best, best_score = candidate, score

    for suffix in ("AdministratorPassword", "UserPassword", "Password"):
        if best.endswith(suffix):
            best = best[: -len(suffix)]
            break
    return best


def _nearby_username(root, target) -> str:
    """Find a Username/Name sibling for an answer-file password element."""
    for parent in iter_elements(root):
        children = list(parent)
        if target not in children:
            continue
        for child in children:
            if local_name(child.tag).lower() in ("username", "name", "domain"):
                return (child.text or "").strip()
    return ""


@register("cisco_config")
def parse_cisco(data: bytes) -> List[Finding]:
    """Extract secrets from a Cisco IOS running/startup configuration."""
    out: List[Finding] = []
    hostname = ""

    for line in lines(data):
        stripped = line.strip()
        if stripped.lower().startswith("hostname "):
            hostname = stripped.split(None, 1)[1]
            continue

        enable = re.match(r"enable (secret|password)\s+(?:(\d+)\s+)?(\S+)", stripped, re.I)
        if enable:
            out.append(
                Finding(
                    name="Cisco Enable",
                    section=enable.group(1).lower(),
                    server=hostname,
                    password=enable.group(3),
                    notes=_cisco_note(enable.group(2)),
                )
            )
            continue

        user = re.search(
            r"username\s+(\S+).*?(?:secret|password)\s+(?:(\d+)\s+)?(\S+)", stripped, re.I
        )
        if user:
            out.append(
                Finding(
                    name="Cisco Local User",
                    section="username",
                    server=hostname,
                    username=user.group(1),
                    password=user.group(3),
                    notes=_cisco_note(user.group(2)),
                )
            )
            continue

        community = re.match(r"snmp-server community\s+(\S+)\s*(\S*)", stripped, re.I)
        if community:
            out.append(
                Finding(
                    name="SNMP Community",
                    section="snmp-server",
                    server=hostname,
                    password=community.group(1),
                    notes=f"access: {community.group(2) or 'RO'}",
                )
            )
    return out


def _cisco_note(type_code: str) -> str:
    return {
        "0": "Cleartext",
        "4": "SHA-256 (type 4, weak)",
        "5": "MD5crypt (type 5)",
        "7": "Vigenere (type 7, trivially reversible)",
        "8": "PBKDF2-SHA256 (type 8)",
        "9": "scrypt (type 9)",
    }.get(type_code or "", "Cleartext or unknown encoding")


@register("tnsnames_ora")
def parse_tnsnames(data: bytes) -> List[Finding]:
    """Extract Oracle service descriptors, including any embedded passwords."""
    content = text(data)
    out: List[Finding] = []
    pattern = re.compile(
        r"HOST\s*=\s*(?P<host>[^)\s]+).*?PORT\s*=\s*(?P<port>\d+).*?"
        r"(?:SERVICE_NAME|SID)\s*=\s*(?P<service>[^)\s]+)",
        re.I | re.S,
    )
    for match in pattern.finditer(content):
        out.append(
            Finding(
                name="Oracle TNS Entry",
                section=match.group("service"),
                url=f"//{match.group('host')}:{match.group('port')}/{match.group('service')}",
                server=match.group("host"),
                port=match.group("port"),
                notes="Oracle service descriptor - target for credential attacks",
            )
        )
    out.extend(generic_key_value(data, "tnsnames"))
    return out


@register("ssis_dtsx")
def parse_dtsx(data: bytes) -> List[Finding]:
    """Extract connection strings and passwords from an SSIS package.

    SSIS stores connection strings both as XML attributes and as the text of a
    ``<DTS:Property DTS:Name="ConnectionString">`` element, so the whole
    document is scanned for connection-string shaped text.
    """
    content = text(data)
    out: List[Finding] = []
    seen = set()

    # Any run of text containing both a data source and a password.
    pattern = re.compile(
        r"((?:data\s+source|server|host)\s*=[^<>\"']{0,400}?password\s*=[^;<>\"']+)",
        re.I,
    )
    for match in pattern.finditer(content):
        conn = match.group(1)
        if conn in seen:
            continue
        seen.add(conn)
        out.extend(_parse_connection_string("SSIS Connection", conn))

    for match in re.finditer(r"<DTS:Password[^>]*>([^<]+)</DTS:Password>", content, re.I):
        out.append(Finding(name="SSIS Password", section="dtsx", password=match.group(1)))
    return out


@register("wp_config")
def parse_wp_config(data: bytes) -> List[Finding]:
    """Extract database credentials and salts from a WordPress wp-config.php."""
    content = text(data)
    values: dict = {}
    for match in re.finditer(
        r"define\s*\(\s*['\"](?P<key>[A-Z_]+)['\"]\s*,\s*['\"](?P<value>[^'\"]*)['\"]", content
    ):
        values[match.group("key")] = match.group("value")

    out: List[Finding] = []
    if values.get("DB_PASSWORD"):
        out.append(
            Finding(
                name="WordPress Database",
                section="wp-config.php",
                server=values.get("DB_HOST", ""),
                username=values.get("DB_USER", ""),
                password=values["DB_PASSWORD"],
                notes=f"database: {values.get('DB_NAME', '')}",
            )
        )
    for salt in ("AUTH_KEY", "SECURE_AUTH_KEY", "LOGGED_IN_KEY", "NONCE_KEY"):
        if values.get(salt):
            out.append(
                Finding(
                    name="WordPress Salt",
                    section=salt,
                    password=values[salt],
                    notes="Allows forging authentication cookies",
                )
            )
    return out


@register("private_key")
def parse_private_key(data: bytes) -> List[Finding]:
    """Identify private key material and whether it is passphrase protected."""
    head = data[:4096]
    content = text(head)

    markers = {
        "RSA PRIVATE KEY": "PEM RSA private key",
        "DSA PRIVATE KEY": "PEM DSA private key",
        "EC PRIVATE KEY": "PEM EC private key",
        "OPENSSH PRIVATE KEY": "OpenSSH private key",
        "PRIVATE KEY": "PKCS#8 private key",
        "PGP PRIVATE KEY BLOCK": "PGP private key",
        "PuTTY-User-Key-File": "PuTTY private key",
    }
    for marker, label in markers.items():
        if marker in content:
            encrypted = (
                "ENCRYPTED" in content
                or "Proc-Type: 4,ENCRYPTED" in content
                or "DEK-Info:" in content
            )
            return [
                Finding(
                    name=label,
                    section="private key",
                    notes="Passphrase protected" if encrypted else "Unencrypted - usable as-is",
                )
            ]

    if head[:4] == b"\x30\x82":
        return [Finding(name="DER encoded key or certificate", section="private key",
                        notes="Binary ASN.1 structure")]
    if head[:4] == b"regf":
        return [Finding(name="Windows registry hive", section="hive",
                        notes="SAM/SYSTEM hive - offline hash extraction possible")]
    return []
