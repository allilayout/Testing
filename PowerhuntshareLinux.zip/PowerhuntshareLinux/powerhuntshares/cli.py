"""Command line interface."""

from __future__ import annotations

import argparse
import getpass
import ipaddress
import os
import sys
from datetime import datetime
from typing import List, Optional

from . import __version__
from .report import csvout, html
from .scanner import ScanConfig, run_scan
from .smbx.auth import Credentials
from .util import error, set_verbose, status, substatus, warn

BANNER = r"""
  ___                 _  _         _   ___ _
 | _ \_____ __ _____ _| || |_  _ _ _| |_/ __| |_  __ _ _ _ ___ ___
 |  _/ _ \ V  V / -_) __ | || | ' \  _\__ \ ' \/ _` | '_/ -_|_-<
 |_| \___/\_/\_/\___|_||_|\_,_|_||_\__|___/_||_\__,_|_| \___/__/
                                                    Linux Edition
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="powerhuntshares",
        description=(
            "Inventory SMB shares across an Active Directory domain, identify "
            "high-risk exposures, and generate CSV and HTML reports. "
            "A Python port of NetSPI/PowerHuntShares."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""examples:
  # Domain scan with a password
  powerhuntshares -d corp.local -u analyst -p 'Passw0rd!' -o ./results

  # Pass the hash, explicit domain controller
  powerhuntshares -d corp.local -u analyst -H aad3b...:31d6c... --dc 10.0.0.10 -o ./results

  # Kerberos from a host with a valid ccache
  KRB5CCNAME=/tmp/analyst.ccache powerhuntshares -d corp.local -u analyst -k -o ./results

  # Target a subnet instead of LDAP discovery
  powerhuntshares -u analyst -p 'Passw0rd!' --target 10.0.0.0/24 -o ./results

  # Fast inventory: no file walking, no credential parsing
  powerhuntshares -d corp.local -u analyst -p 'Passw0rd!' -o ./results --no-files
""",
    )

    auth = parser.add_argument_group("authentication")
    auth.add_argument("-u", "--username", default="", help="Username")
    auth.add_argument("-p", "--password", default=None,
                      help="Password (omit the value to be prompted securely)")
    auth.add_argument("-d", "--domain", default="", help="Domain, e.g. corp.local")
    auth.add_argument("-H", "--hash", dest="nt_hash", default="",
                      help="NTLM hash as NTHASH or LMHASH:NTHASH")
    auth.add_argument("-k", "--kerberos", action="store_true",
                      help="Use Kerberos; honours KRB5CCNAME")
    auth.add_argument("--aes-key", default="", help="AES key for Kerberos (128 or 256 bit)")
    auth.add_argument("--kdc", default=None, help="KDC host, defaults to the domain controller")

    targets = parser.add_argument_group("targets")
    targets.add_argument("--dc", dest="domain_controller", default="",
                         help="Domain controller for LDAP; auto-discovered when omitted")
    targets.add_argument("--target", action="append", default=[],
                         help="Host, IP or CIDR to scan; repeatable. A path to a host "
                              "list file is also accepted. Skips LDAP discovery, but "
                              "--dc is still used to enrich results with OS data")
    targets.add_argument("--target-file", default="",
                         help="File with one host, IP or CIDR per line")
    targets.add_argument("--ldap-filter", default="(objectCategory=computer)",
                         help="LDAP filter for computer discovery")
    targets.add_argument("--ldap-ssl", action="store_true", help="Use LDAPS on port 636")

    scan = parser.add_argument_group("scan behaviour")
    scan.add_argument("-t", "--threads", type=int, default=20,
                      help="Concurrent workers (default: 20)")
    scan.add_argument("--timeout", type=int, default=15,
                      help="Per-operation timeout in seconds (default: 15)")
    scan.add_argument("-L", "--dir-level", type=int, default=3,
                      help="Nested directory levels to walk (default: 3)")
    scan.add_argument("--max-files", type=int, default=50000,
                      help="Maximum files recorded per share (default: 50000)")
    scan.add_argument("--no-ping", action="store_true", help="Skip the liveness check")
    scan.add_argument("--icmp", action="store_true",
                      help="Use ICMP for liveness instead of TCP probes (may need root)")
    scan.add_argument("--no-files", action="store_true",
                      help="Skip directory walking and everything downstream of it")
    scan.add_argument("--no-secrets", action="store_true",
                      help="Walk files but do not download or parse config files")
    scan.add_argument("--share-acls", action="store_true",
                      help="Also request share-level ACLs via srvsvc (usually needs admin)")
    scan.add_argument("--max-config-size", type=int, default=1024 * 1024,
                      help="Largest config file to download for parsing (default: 1 MiB)")
    scan.add_argument("--stale-days", type=int, default=365,
                      help="Days without modification before a share counts as stale")

    output = parser.add_argument_group("output")
    output.add_argument("-o", "--output", required=True,
                        help="Output directory; a timestamped subdirectory is created inside it")
    output.add_argument("--keywords", default="",
                        help="CSV of interesting-file keywords, overriding the built-in list")
    output.add_argument("--sample-sum", type=int, default=200,
                        help="Rows kept in each 'most common' summary (default: 200)")
    output.add_argument("--no-html", action="store_true", help="Skip the HTML report")
    output.add_argument("--max-html-rows", type=int, default=25000,
                        help="Row cap per HTML table (default: 25000)")

    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose diagnostics")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def _read_target_file(path: str) -> List[str]:
    expanded = os.path.expanduser(path)
    try:
        with open(expanded, "r", encoding="utf-8") as handle:
            return [line.strip() for line in handle if line.strip()]
    except OSError as exc:
        error(f"could not read {expanded}: {exc}")
        raise SystemExit(2)


def _looks_like_path(value: str) -> bool:
    """True when a --target value is clearly a filesystem path, not a host.

    Catches the common slip of passing a host list to --target instead of
    --target-file when the file does not exist, so the run fails with a clear
    message rather than scanning a nonsense hostname.
    """
    if value.startswith(("~", "./", "../", "/")) or "\\" in value:
        return True
    # A CIDR is the only legitimate use of "/" in a target.
    if "/" in value:
        try:
            ipaddress.ip_network(value, strict=False)
            return False
        except ValueError:
            return True
    return False


def _load_targets(args) -> List[str]:
    targets: List[str] = []

    for value in args.target:
        expanded = os.path.expanduser(value)
        # Accept a file path passed to --target: it is what users reach for
        # first, and silently treating it as a hostname wastes a whole run.
        if os.path.isfile(expanded):
            entries = _read_target_file(expanded)
            substatus(f"--target {value} is a file; loaded {len(entries)} targets from it")
            targets.extend(entries)
            continue

        if _looks_like_path(value):
            error(f"--target {value!r} looks like a file path, but no such file exists")
            error("check the path, or use --target-file for a host list")
            raise SystemExit(2)

        targets.append(value)

    if args.target_file:
        targets.extend(_read_target_file(args.target_file))

    return targets


def _check_dependencies(need_ldap: bool) -> None:
    missing = []
    try:
        import impacket  # noqa: F401
    except ImportError:
        missing.append("impacket")
    if need_ldap:
        try:
            import ldap3  # noqa: F401
        except ImportError:
            missing.append("ldap3")
    if missing:
        error(f"missing required package(s): {', '.join(missing)}")
        error("install them with: pip install " + " ".join(missing))
        raise SystemExit(2)


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    set_verbose(args.verbose)
    print(BANNER)

    targets = _load_targets(args)
    _check_dependencies(need_ldap=not targets)

    # An explicitly empty -p prompts rather than authenticating with a blank
    # password, which is almost never what the user meant.
    password = args.password
    if password is None and args.username and not args.nt_hash and not args.kerberos:
        password = getpass.getpass(f"Password for {args.domain}\\{args.username}: ")
    password = password or ""

    creds = Credentials.from_args(
        username=args.username,
        password=password,
        domain=args.domain,
        nt_hash=args.nt_hash,
        aes_key=args.aes_key,
        kerberos=args.kerberos,
        kdc_host=args.kdc,
    )

    if not targets and not args.domain and not args.domain_controller:
        error("LDAP discovery needs --domain or --dc; alternatively pass --target")
        return 2

    # Create the timestamped run directory up front so a scan never discovers
    # at the end that it had nowhere to write.
    try:
        os.makedirs(args.output, exist_ok=True)
    except OSError as exc:
        error(f"output directory {args.output} is not usable: {exc}")
        return 2

    run_dir = os.path.join(
        args.output, f"SmbShareHunt-{datetime.now().strftime('%m%d%Y%H%M%S')}"
    )
    results_dir = os.path.join(run_dir, "Results")
    try:
        os.makedirs(results_dir, exist_ok=True)
    except OSError as exc:
        error(f"could not create {results_dir}: {exc}")
        return 2

    config = ScanConfig(
        output_dir=results_dir,
        creds=creds,
        domain_controller=args.domain_controller,
        host_list=targets,
        threads=args.threads,
        timeout=args.timeout,
        dir_level=args.dir_level,
        max_files_per_share=args.max_files,
        sample_sum=args.sample_sum,
        stale_days=args.stale_days,
        no_ping=args.no_ping,
        use_icmp=args.icmp,
        keyword_path=args.keywords,
        collect_files=not args.no_files,
        extract_secrets=not (args.no_files or args.no_secrets),
        share_level_acls=args.share_acls,
        ldap_filter=args.ldap_filter,
        ldap_ssl=args.ldap_ssl,
        max_secret_file_size=args.max_config_size,
    )

    try:
        results = run_scan(config)
    except KeyboardInterrupt:
        warn("interrupted by user; no report written")
        return 130
    except Exception as exc:  # noqa: BLE001
        error(f"scan failed: {exc}")
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1

    status("Writing output files")
    csvout.export_all(results, results_dir)

    if not args.no_html:
        html.build(
            results,
            os.path.join(run_dir, f"{results.target_domain}-Summary-Report.html"),
            max_rows=args.max_html_rows,
        )

    status("Scan complete")
    substatus(f"Results: {run_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
