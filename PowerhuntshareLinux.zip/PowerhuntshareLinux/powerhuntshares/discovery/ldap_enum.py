"""Active Directory enumeration over LDAP.

Replaces the original module's Get-LdapQuery / Get-DomainSubnet, which relied on
System.DirectoryServices. Here everything goes through ldap3, so the tool runs
from any Linux host with network access to a domain controller -- domain joined
or not.
"""

from __future__ import annotations

import socket
from typing import List, Optional, Tuple

from ..models import Computer, Subnet
from ..smbx.auth import Credentials
from ..util import status, substatus, verbose, warn


def _server_and_connection(
    dc: str,
    creds: Credentials,
    use_ssl: bool = False,
    timeout: int = 10,
):
    """Build an authenticated ldap3 Connection to ``dc``."""
    from ldap3 import ALL, Connection, NTLM, SASL, KERBEROS, Server

    port = 636 if use_ssl else 389
    server = Server(dc, port=port, use_ssl=use_ssl, get_info=ALL, connect_timeout=timeout)

    if creds.use_kerberos:
        conn = Connection(
            server,
            authentication=SASL,
            sasl_mechanism=KERBEROS,
            auto_bind=False,
            receive_timeout=timeout,
        )
    elif creds.username:
        # ldap3's NTLM mechanism accepts a pass-the-hash password in the
        # "LMHASH:NTHASH" form, which is how hash auth is wired up here.
        password = creds.password
        if creds.nthash:
            password = f"{creds.lmhash}:{creds.nthash}"
        user = f"{creds.domain}\\{creds.username}" if creds.domain else creds.username
        conn = Connection(
            server,
            user=user,
            password=password,
            authentication=NTLM,
            auto_bind=False,
            receive_timeout=timeout,
        )
    else:
        conn = Connection(server, auto_bind=False, receive_timeout=timeout)

    if not conn.bind():
        raise RuntimeError(f"LDAP bind to {dc} failed: {conn.result}")
    return server, conn


def discover_dc(domain: str) -> Optional[str]:
    """Find a domain controller via the standard SRV record."""
    try:
        import dns.resolver  # type: ignore

        answers = dns.resolver.resolve(f"_ldap._tcp.dc._msdcs.{domain}", "SRV")
        hosts = sorted(answers, key=lambda r: (r.priority, -r.weight))
        if hosts:
            return str(hosts[0].target).rstrip(".")
    except Exception as exc:  # noqa: BLE001
        verbose(f"SRV lookup for {domain} failed: {exc}")

    # dnspython is optional; fall back to resolving the domain name itself,
    # which in most AD environments round-robins across the DCs.
    try:
        socket.gethostbyname(domain)
        return domain
    except OSError:
        return None


def _base_dn(server) -> str:
    try:
        contexts = server.info.naming_contexts
        for ctx in contexts:
            if ctx.lower().startswith("dc="):
                return ctx
    except Exception:  # noqa: BLE001
        pass
    return ""


def _config_dn(server) -> str:
    try:
        other = server.info.other
        value = other.get("configurationNamingContext")
        if value:
            return value[0] if isinstance(value, list) else str(value)
    except Exception:  # noqa: BLE001
        pass
    base = _base_dn(server)
    return f"CN=Configuration,{base}" if base else ""


def dn_to_domain(dn: str) -> str:
    """Turn ``DC=corp,DC=example,DC=com`` into ``corp.example.com``."""
    parts = [
        piece.split("=", 1)[1]
        for piece in dn.split(",")
        if piece.strip().lower().startswith("dc=")
    ]
    return ".".join(parts)


def enumerate_domain(
    dc: str,
    creds: Credentials,
    use_ssl: bool = False,
    ldap_filter: str = "(objectCategory=computer)",
    timeout: int = 10,
) -> Tuple[str, str, List[Computer], List[Subnet]]:
    """Enumerate computers and site subnets from Active Directory.

    Returns ``(domain_fqdn, domain_netbios, computers, subnets)``.
    """
    from ldap3 import SUBTREE

    server, conn = _server_and_connection(dc, creds, use_ssl=use_ssl, timeout=timeout)
    try:
        base = _base_dn(server)
        if not base:
            raise RuntimeError(f"could not determine the base DN from {dc}")

        domain_fqdn = dn_to_domain(base)
        domain_netbios = _netbios_name(conn, server, base) or domain_fqdn.split(".")[0].upper()
        status(f"Successful connection to domain controller: {dc}")
        substatus(f"Domain: {domain_fqdn} (NetBIOS {domain_netbios})")

        status(f"Performing LDAP query for computers associated with the {domain_fqdn} domain")
        computers = _query_computers(conn, base, ldap_filter)
        substatus(f"{len(computers)} computers found")

        subnets = _query_subnets(conn, _config_dn(server))
        substatus(f"{len(subnets)} subnets found")

        return domain_fqdn, domain_netbios, computers, subnets
    finally:
        try:
            conn.unbind()
        except Exception:  # noqa: BLE001
            pass


def _netbios_name(conn, server, base: str) -> str:
    from ldap3 import SUBTREE

    config = _config_dn(server)
    if not config:
        return ""
    try:
        conn.search(
            search_base=f"CN=Partitions,{config}",
            search_filter=f"(&(objectClass=crossRef)(nCName={base}))",
            search_scope=SUBTREE,
            attributes=["nETBIOSName"],
        )
        for entry in conn.entries:
            value = entry.entry_attributes_as_dict.get("nETBIOSName") or []
            if value:
                return str(value[0])
    except Exception as exc:  # noqa: BLE001
        verbose(f"NetBIOS name lookup failed: {exc}")
    return ""


def _query_computers(conn, base: str, ldap_filter: str) -> List[Computer]:
    from ldap3 import SUBTREE

    attributes = [
        "dNSHostName",
        "name",
        "operatingSystem",
        "operatingSystemServicePack",
        "userAccountControl",
    ]

    computers: List[Computer] = []
    seen = set()

    for data in _paged_attributes(conn, base, ldap_filter, attributes):
        host = _first(data.get("dNSHostName"))
        if not host:
            # Fall back to the sAM name minus the trailing $ when the DNS name
            # attribute was never populated.
            name = _first(data.get("name"))
            if not name:
                continue
            host = name.rstrip("$")
        key = host.lower()
        if key in seen:
            continue
        seen.add(key)

        computers.append(
            Computer(
                ComputerName=host,
                OperatingSystem=_first(data.get("operatingSystem")),
                ServicePack=_first(data.get("operatingSystemServicePack")),
            )
        )
    return computers


def _paged_attributes(conn, base: str, ldap_filter: str, attributes: List[str]):
    """Yield the attribute dict of every entry matching a search.

    Domain controllers cap a single response at 1000 entries by default, so
    paging is mandatory in any real environment. ldap3's ``paged_search``
    extension drives the cookie loop itself; a plain ``search`` is used as a
    fallback for servers that reject the paging control, which caps results at
    whatever the server returns in one page.
    """
    from ldap3 import SUBTREE

    try:
        results = conn.extend.standard.paged_search(
            search_base=base,
            search_filter=ldap_filter,
            search_scope=SUBTREE,
            attributes=attributes,
            paged_size=1000,
            generator=True,
        )
        for entry in results:
            # A paged search also emits referrals, which carry no attributes.
            if entry.get("type") != "searchResEntry":
                continue
            data = entry.get("attributes")
            if data:
                yield dict(data)
        return
    except Exception as exc:  # noqa: BLE001
        verbose(f"paged search failed, retrying without paging: {exc}")

    conn.search(
        search_base=base,
        search_filter=ldap_filter,
        search_scope=SUBTREE,
        attributes=attributes,
    )
    for entry in conn.entries:
        yield entry.entry_attributes_as_dict


def _query_subnets(conn, config_dn: str) -> List[Subnet]:
    from ldap3 import SUBTREE

    if not config_dn:
        return []

    out: List[Subnet] = []
    try:
        conn.search(
            search_base=f"CN=Subnets,CN=Sites,{config_dn}",
            search_filter="(objectCategory=subnet)",
            search_scope=SUBTREE,
            attributes=["cn", "siteObject", "description", "whenCreated", "whenChanged"],
        )
        for entry in conn.entries:
            data = entry.entry_attributes_as_dict
            site_dn = _first(data.get("siteObject"))
            site = site_dn.split(",")[0].replace("CN=", "") if site_dn else ""
            out.append(
                Subnet(
                    Subnet=_first(data.get("cn")),
                    Site=site,
                    Description=_first(data.get("description")),
                    Created=str(_first(data.get("whenCreated"))),
                    Changed=str(_first(data.get("whenChanged"))),
                )
            )
    except Exception as exc:  # noqa: BLE001
        warn(f"subnet enumeration failed: {exc}")
    return out


def _first(value) -> str:
    if not value:
        return ""
    if isinstance(value, list):
        return str(value[0]) if value else ""
    return str(value)
