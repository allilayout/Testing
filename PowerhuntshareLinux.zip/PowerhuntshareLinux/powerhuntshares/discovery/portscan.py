"""Host liveness and TCP 445 reachability checks.

The original module used ICMP via Invoke-Ping. Raw ICMP needs CAP_NET_RAW on
Linux, so the default here is a TCP connect probe against a small set of common
Windows ports, with real ICMP available through ``--icmp`` when the tool is run
with the necessary privileges.
"""

from __future__ import annotations

import ipaddress
import socket
import subprocess
from typing import List, Optional, Sequence

from ..models import Computer
from ..util import run_parallel, verbose

# Ports probed for liveness when ICMP is unavailable.
LIVENESS_PORTS = (445, 139, 135, 3389, 22)


def tcp_open(host: str, port: int, timeout: float = 3.0) -> bool:
    """True when a TCP connection to ``host:port`` completes."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def icmp_alive(host: str, timeout: float = 2.0) -> bool:
    """Send a single ICMP echo using the system ping binary."""
    try:
        result = subprocess.run(
            ["ping", "-c", "1", "-W", str(int(max(1, timeout))), host],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout + 2,
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def check_alive(
    computers: Sequence[Computer],
    threads: int = 20,
    timeout: float = 3.0,
    use_icmp: bool = False,
) -> List[Computer]:
    """Return the subset of ``computers`` that responded to a liveness probe."""

    def probe(computer: Computer) -> Optional[Computer]:
        host = computer.ComputerName
        if use_icmp:
            alive = icmp_alive(host, timeout=timeout)
        else:
            alive = any(tcp_open(host, port, timeout=timeout) for port in LIVENESS_PORTS)
        if alive:
            computer.Pingable = True
            return computer
        return None

    return run_parallel(
        list(computers),
        probe,
        threads=threads,
        timeout=int(timeout * len(LIVENESS_PORTS) + 10),
        label="liveness",
    )


def check_445(
    computers: Sequence[Computer],
    threads: int = 20,
    timeout: float = 3.0,
) -> List[Computer]:
    """Return the subset of ``computers`` with TCP 445 reachable."""

    def probe(computer: Computer) -> Optional[Computer]:
        if tcp_open(computer.ComputerName, 445, timeout=timeout):
            computer.Port445Open = True
            if not computer.IpAddress:
                try:
                    computer.IpAddress = socket.gethostbyname(computer.ComputerName)
                except OSError:
                    pass
            return computer
        return None

    return run_parallel(
        list(computers),
        probe,
        threads=threads,
        timeout=int(timeout + 10),
        label="tcp/445",
    )


def expand_targets(entries: Sequence[str]) -> List[str]:
    """Expand a mixed list of hostnames, IPs and CIDR ranges into hosts.

    Lets ``--target 10.0.0.0/24`` work the same way a host list file does.
    """
    out: List[str] = []
    seen = set()
    for raw in entries:
        entry = raw.strip()
        if not entry or entry.startswith("#"):
            continue
        hosts: List[str]
        if "/" in entry:
            try:
                network = ipaddress.ip_network(entry, strict=False)
                if network.num_addresses > 65536:
                    verbose(f"skipping oversized range {entry}")
                    continue
                hosts = [str(ip) for ip in network.hosts()]
            except ValueError:
                hosts = [entry]
        else:
            hosts = [entry]
        for host in hosts:
            key = host.lower()
            if key not in seen:
                seen.add(key)
                out.append(host)
    return out
