"""CSV export.

File names match the original module's output so existing parsing scripts and
NOVA/Nessus import workflows keep working against a Linux scan.
"""

from __future__ import annotations

import csv
import os
from dataclasses import fields
from typing import Any, List, Sequence

from ..models import ScanResults
from ..util import substatus, warn


def write_rows(path: str, rows: Sequence[Any]) -> bool:
    """Write a sequence of dataclass records to ``path``; skip when empty."""
    if not rows:
        return False

    header = [f.name for f in fields(rows[0])]
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=header, quoting=csv.QUOTE_ALL)
            writer.writeheader()
            for row in rows:
                writer.writerow(row.to_row())
        return True
    except OSError as exc:
        warn(f"could not write {path}: {exc}")
        return False


def write_pairs(path: str, header: Sequence[str], rows: Sequence[Sequence[Any]]) -> bool:
    """Write a plain list-of-tuples table, used for the summary counts."""
    if not rows:
        return False
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, quoting=csv.QUOTE_ALL)
            writer.writerow(header)
            writer.writerows(rows)
        return True
    except OSError as exc:
        warn(f"could not write {path}: {exc}")
        return False


def export_all(results: ScanResults, out_dir: str) -> List[str]:
    """Write every CSV artifact and return the paths that were created."""
    domain = results.target_domain
    written: List[str] = []

    def emit(suffix: str, rows: Sequence[Any]) -> None:
        path = os.path.join(out_dir, f"{domain}-{suffix}")
        if write_rows(path, rows):
            written.append(path)

    emit("Domain-Computers.csv", results.computers)
    emit("Domain-Subnets.csv", results.subnets)
    emit("Domain-Computers-Pingable.csv", results.computers_pingable)
    emit("Domain-Computers-Open445.csv", results.computers_445)
    emit("Shares-Inventory-All.csv", results.shares)
    emit("Shares-Inventory-All-ACL.csv", results.acls)
    emit("Shares-Inventory-Excessive-Privileges.csv", results.excessive)
    emit("Interesting-Files-All.csv", results.interesting_files)
    emit("Extracted-Secrets.csv", results.secrets)
    emit("Shares-File-Listing.csv", results.files)

    # Derived slices that mirror the original module's separate exports.
    readable = [a for a in results.excessive if a.HasRead]
    writable = [a for a in results.excessive if a.HasWrite]
    high_risk = [a for a in results.excessive if a.HasHR]
    non_default = [a for a in results.excessive if not a.IsDefault]

    emit("Shares-Inventory-Excessive-Privileges-Read.csv", readable)
    emit("Shares-Inventory-Excessive-Privileges-Write.csv", writable)
    emit("Shares-Inventory-Excessive-Privileges-HighRisk.csv", high_risk)
    emit("Shares-Inventory-Excessive-Privileges-NonDefault.csv", non_default)

    stats = results.stats

    for suffix, key, header in (
        ("Shares-Inventory-Common-Names.csv", "common_names", ("Count", "Name")),
        ("Shares-Inventory-Common-Owners.csv", "common_owners", ("Count", "Name")),
        ("Shares-Inventory-Common-FileGroups.csv", "common_groups", ("Count", "Name")),
    ):
        rows = stats.get(key) or []
        path = os.path.join(out_dir, f"{domain}-{suffix}")
        if write_pairs(path, header, [(count, name) for name, count in rows]):
            written.append(path)

    substatus(f"{len(written)} CSV files written to {out_dir}")
    return written
