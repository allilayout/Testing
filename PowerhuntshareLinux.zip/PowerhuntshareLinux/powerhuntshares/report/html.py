"""Self-contained HTML report generator.

The output is a single file with no external requests: all CSS, JavaScript and
data are inlined, so the report can be handed to a client or opened from an
air-gapped review machine. Tables are rendered client side from an embedded
JSON payload, which keeps the file usable with tens of thousands of rows.
"""

from __future__ import annotations

import html
import json
import os
from typing import Any, Dict, List, Sequence

from ..models import ScanResults
from ..util import substatus, warn

RISK_COLORS = {
    "Critical": "#b3202b",
    "High": "#e8562a",
    "Medium": "#e8a33d",
    "Low": "#4a8db7",
}

CATEGORY_COLORS = {
    "Secret": "#b3202b",
    "Sensitive": "#e8562a",
    "SystemImage": "#8a63b3",
    "Database": "#2f7d95",
    "Backup": "#3d8a63",
    "Script": "#c4923d",
    "Binaries": "#6b7280",
}

_CSS = """
:root{
  --bg:#f4f6f8; --panel:#ffffff; --ink:#1d2733; --muted:#5b6b7c;
  --line:#dde3ea; --accent:#25647d; --accent-soft:#e8f0f4;
}
@media (prefers-color-scheme: dark){
  :root{
    --bg:#12171d; --panel:#1a212a; --ink:#e6ecf2; --muted:#98a7b6;
    --line:#2b3542; --accent:#5fa8c4; --accent-soft:#1f2c36;
  }
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
  font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
header{background:var(--panel);border-bottom:1px solid var(--line);padding:22px 28px}
header h1{margin:0 0 4px;font-size:20px;letter-spacing:-.01em}
header .sub{color:var(--muted);font-size:13px}
main{padding:24px 28px 60px;max-width:1500px;margin:0 auto}
section{margin-bottom:34px}
h2{font-size:15px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);
  margin:0 0 14px;font-weight:600}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(168px,1fr));gap:12px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:14px 16px}
.card .n{font-size:26px;font-weight:650;letter-spacing:-.02em}
.card .l{color:var(--muted);font-size:12px;margin-top:2px}
.card .p{color:var(--muted);font-size:11px;margin-top:6px}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:16px 18px}
.panel h3{margin:0 0 12px;font-size:13px;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line);
  vertical-align:top;word-break:break-word}
th{background:var(--accent-soft);cursor:pointer;user-select:none;white-space:nowrap;
  position:sticky;top:0;font-weight:600;font-size:12px}
th:after{content:'';margin-left:5px;opacity:.4}
th.asc:after{content:'\\25B2'}
th.desc:after{content:'\\25BC'}
tbody tr:hover{background:var(--accent-soft)}
.tablewrap{overflow-x:auto;max-height:640px;overflow-y:auto;border:1px solid var(--line);
  border-radius:8px;background:var(--panel)}
.controls{display:flex;gap:10px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
input[type=search],select{background:var(--panel);color:var(--ink);border:1px solid var(--line);
  border-radius:6px;padding:6px 10px;font-size:13px;min-width:220px}
button{background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:6px;
  padding:6px 11px;font-size:13px;cursor:pointer}
button:hover{background:var(--accent-soft)}
button.on{background:var(--accent);color:#fff;border-color:var(--accent)}
.count{color:var(--muted);font-size:12px;margin-left:auto}
.pill{display:inline-block;padding:1px 8px;border-radius:10px;font-size:11px;
  font-weight:600;color:#fff;white-space:nowrap}
.bar{height:9px;border-radius:5px;background:var(--line);overflow:hidden;min-width:60px}
.bar > i{display:block;height:100%;border-radius:5px}
.barrow{display:grid;grid-template-columns:1fr 56px;gap:10px;align-items:center;
  margin-bottom:7px;font-size:12px}
.barrow .lab{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.barrow .val{text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}
.legend{display:flex;flex-wrap:wrap;gap:12px;margin-top:12px;font-size:12px}
.legend span{display:flex;align-items:center;gap:6px}
.legend i{width:10px;height:10px;border-radius:2px;display:inline-block}
.pager{display:flex;gap:6px;align-items:center;margin-top:10px;flex-wrap:wrap}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px}
.secret{color:#b3202b;font-weight:600}
.empty{padding:24px;text-align:center;color:var(--muted)}
footer{color:var(--muted);font-size:12px;padding:20px 28px;border-top:1px solid var(--line)}
details summary{cursor:pointer;color:var(--accent);font-size:12px}
"""

_JS = r"""
const F = (window.PHS_DATA || {});

function esc(s){
  return String(s==null?'':s).replace(/[&<>"']/g, c => (
    {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]
  ));
}

const RISK = {Critical:'#b3202b',High:'#e8562a',Medium:'#e8a33d',Low:'#4a8db7'};
const CAT = {Secret:'#b3202b',Sensitive:'#e8562a',SystemImage:'#8a63b3',
             Database:'#2f7d95',Backup:'#3d8a63',Script:'#c4923d',Binaries:'#6b7280'};

/* A sortable, searchable, paginated table bound to one dataset. */
class Grid {
  constructor(root, rows, columns, opts){
    this.root = root;
    this.all = rows || [];
    this.columns = columns;
    this.opts = opts || {};
    this.page = 0;
    this.size = this.opts.pageSize || 50;
    this.sortKey = this.opts.sortKey || null;
    this.sortDir = this.opts.sortDir || 'desc';
    this.query = '';
    this.facet = '';
    this.build();
  }

  build(){
    const facetValues = this.opts.facet
      ? [...new Set(this.all.map(r => r[this.opts.facet]).filter(Boolean))].sort()
      : [];

    this.root.innerHTML = `
      <div class="controls">
        <input type="search" placeholder="Search ${esc(this.opts.label||'')}...">
        ${this.opts.facet ? `<select><option value="">All ${esc(this.opts.facetLabel||this.opts.facet)}</option>
          ${facetValues.map(v=>`<option>${esc(v)}</option>`).join('')}</select>` : ''}
        <button class="csv">Export CSV</button>
        <span class="count"></span>
      </div>
      <div class="tablewrap"><table>
        <thead><tr>${this.columns.map(c=>`<th data-k="${esc(c.key)}">${esc(c.label)}</th>`).join('')}</tr></thead>
        <tbody></tbody>
      </table></div>
      <div class="pager"></div>`;

    const search = this.root.querySelector('input');
    search.addEventListener('input', e => {
      this.query = e.target.value.toLowerCase(); this.page = 0; this.render();
    });

    const select = this.root.querySelector('select');
    if (select) select.addEventListener('change', e => {
      this.facet = e.target.value; this.page = 0; this.render();
    });

    this.root.querySelector('.csv').addEventListener('click', () => this.exportCsv());

    this.root.querySelectorAll('th').forEach(th => {
      th.addEventListener('click', () => {
        const key = th.dataset.k;
        if (this.sortKey === key){
          this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
        } else {
          this.sortKey = key; this.sortDir = 'desc';
        }
        this.page = 0; this.render();
      });
    });
    this.render();
  }

  filtered(){
    let rows = this.all;
    if (this.facet && this.opts.facet)
      rows = rows.filter(r => r[this.opts.facet] === this.facet);
    if (this.query){
      const q = this.query;
      rows = rows.filter(r => this.columns.some(c =>
        String(r[c.key]==null?'':r[c.key]).toLowerCase().includes(q)));
    }
    if (this.sortKey){
      const k = this.sortKey, dir = this.sortDir === 'asc' ? 1 : -1;
      rows = rows.slice().sort((a,b) => {
        const x = a[k], y = b[k];
        const nx = typeof x === 'number', ny = typeof y === 'number';
        if (nx && ny) return (x-y)*dir;
        return String(x==null?'':x).localeCompare(String(y==null?'':y), undefined,
          {numeric:true, sensitivity:'base'}) * dir;
      });
    }
    return rows;
  }

  render(){
    const rows = this.filtered();
    const start = this.page * this.size;
    const slice = rows.slice(start, start + this.size);
    const tbody = this.root.querySelector('tbody');

    tbody.innerHTML = slice.length ? slice.map(r =>
      `<tr>${this.columns.map(c => `<td>${c.fmt ? c.fmt(r[c.key], r) : esc(r[c.key])}</td>`).join('')}</tr>`
    ).join('') : `<tr><td colspan="${this.columns.length}" class="empty">No matching rows</td></tr>`;

    this.root.querySelector('.count').textContent =
      `${rows.length.toLocaleString()} of ${this.all.length.toLocaleString()} rows`;

    this.root.querySelectorAll('th').forEach(th => {
      th.className = th.dataset.k === this.sortKey ? this.sortDir : '';
    });

    const pages = Math.max(1, Math.ceil(rows.length / this.size));
    const pager = this.root.querySelector('.pager');
    if (pages <= 1){ pager.innerHTML = ''; return; }

    const nums = [];
    for (let i = 0; i < pages; i++){
      if (i < 2 || i > pages-3 || Math.abs(i - this.page) <= 2) nums.push(i);
      else if (nums[nums.length-1] !== '...') nums.push('...');
    }
    pager.innerHTML =
      `<button data-p="${Math.max(0,this.page-1)}">Prev</button>` +
      nums.map(n => n === '...' ? '<span>...</span>'
        : `<button data-p="${n}" class="${n===this.page?'on':''}">${n+1}</button>`).join('') +
      `<button data-p="${Math.min(pages-1,this.page+1)}">Next</button>`;

    pager.querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
      this.page = +b.dataset.p; this.render();
      this.root.querySelector('.tablewrap').scrollTop = 0;
    }));
  }

  exportCsv(){
    const rows = this.filtered();
    const q = v => `"${String(v==null?'':v).replace(/"/g,'""')}"`;
    const csv = [this.columns.map(c => q(c.label)).join(',')]
      .concat(rows.map(r => this.columns.map(c => q(r[c.key])).join(',')))
      .join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8'}));
    const a = document.createElement('a');
    a.href = url;
    a.download = (this.opts.label || 'export').replace(/\s+/g,'-').toLowerCase() + '.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
}

function pill(value){
  const c = RISK[value] || '#6b7280';
  return `<span class="pill" style="background:${c}">${esc(value)}</span>`;
}

function catPill(value){
  const c = CAT[value] || '#6b7280';
  return `<span class="pill" style="background:${c}">${esc(value)}</span>`;
}

function yesNo(v){ return v ? '<b>Yes</b>' : '<span style="opacity:.4">No</span>'; }

/* Horizontal bar list used for the "top N" panels. */
function bars(el, entries, color){
  if (!entries || !entries.length){ el.innerHTML = '<div class="empty">No data</div>'; return; }
  const max = Math.max(...entries.map(e => e[1]));
  el.innerHTML = entries.map(([label,count]) => `
    <div class="barrow">
      <div>
        <div class="lab" title="${esc(label)}">${esc(label)}</div>
        <div class="bar"><i style="width:${(count/max*100).toFixed(1)}%;background:${color}"></i></div>
      </div>
      <div class="val">${count.toLocaleString()}</div>
    </div>`).join('');
}

/* Inline SVG donut; avoids pulling in a charting library. */
function donut(el, entries, colors){
  const total = entries.reduce((s,e) => s + e[1], 0);
  if (!total){ el.innerHTML = '<div class="empty">No data</div>'; return; }

  const R = 62, C = 2 * Math.PI * R;
  let offset = 0;
  const arcs = entries.filter(e => e[1] > 0).map(([label,count]) => {
    const frac = count / total;
    const seg = `<circle r="${R}" cx="90" cy="90" fill="none"
      stroke="${colors[label] || '#6b7280'}" stroke-width="24"
      stroke-dasharray="${(frac*C).toFixed(2)} ${C.toFixed(2)}"
      stroke-dashoffset="${(-offset*C).toFixed(2)}"
      transform="rotate(-90 90 90)"><title>${esc(label)}: ${count}</title></circle>`;
    offset += frac;
    return seg;
  }).join('');

  el.innerHTML = `
    <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
      <svg width="180" height="180" viewBox="0 0 180 180">${arcs}
        <text x="90" y="86" text-anchor="middle" font-size="26" font-weight="650"
          fill="currentColor">${total.toLocaleString()}</text>
        <text x="90" y="106" text-anchor="middle" font-size="11"
          fill="currentColor" opacity=".6">total</text>
      </svg>
      <div class="legend" style="flex-direction:column;gap:7px">
        ${entries.map(([l,c]) => `<span><i style="background:${colors[l]||'#6b7280'}"></i>
          ${esc(l)} &mdash; <b>${c.toLocaleString()}</b></span>`).join('')}
      </div>
    </div>`;
}

document.addEventListener('DOMContentLoaded', () => {
  donut(document.getElementById('risk-donut'), F.riskCounts || [], RISK);
  donut(document.getElementById('cat-donut'), F.categoryCounts || [], CAT);
  bars(document.getElementById('top-names'), F.commonNames || [], '#25647d');
  bars(document.getElementById('top-owners'), F.commonOwners || [], '#3d8a63');
  bars(document.getElementById('top-identities'), F.commonIdentities || [], '#8a63b3');
  bars(document.getElementById('timeline-mod'), F.timelineModified || [], '#c4923d');

  new Grid(document.getElementById('grid-excessive'), F.excessive, [
    {key:'RiskLevel', label:'Risk', fmt:pill},
    {key:'RiskScore', label:'Score'},
    {key:'ComputerName', label:'Computer'},
    {key:'ShareName', label:'Share'},
    {key:'SharePath', label:'Path'},
    {key:'IdentityReference', label:'Identity'},
    {key:'FileSystemRights', label:'Rights'},
    {key:'AccessControlType', label:'Type'},
    {key:'HasRead', label:'Read', fmt:yesNo},
    {key:'HasWrite', label:'Write', fmt:yesNo},
    {key:'SecretFileCount', label:'Secrets'},
    {key:'FileCount', label:'Files'},
    {key:'ShareOwner', label:'Owner'},
    {key:'LastModifiedDate', label:'Modified'},
  ], {label:'Excessive Privileges', sortKey:'RiskScore', facet:'RiskLevel', facetLabel:'risk levels'});

  new Grid(document.getElementById('grid-interesting'), F.interesting, [
    {key:'Category', label:'Category', fmt:catPill},
    {key:'FileName', label:'File'},
    {key:'ComputerName', label:'Computer'},
    {key:'ShareName', label:'Share'},
    {key:'UncPath', label:'Path'},
    {key:'FileSize', label:'Size'},
    {key:'LastModified', label:'Modified'},
    {key:'Description', label:'Notes'},
  ], {label:'Interesting Files', sortKey:'Category', sortDir:'asc',
      facet:'Category', facetLabel:'categories'});

  new Grid(document.getElementById('grid-secrets'), F.secrets, [
    {key:'Name', label:'Type'},
    {key:'ComputerName', label:'Computer'},
    {key:'UncPath', label:'Source File'},
    {key:'Section', label:'Section'},
    {key:'UserName', label:'Username'},
    {key:'Password', label:'Secret', fmt:v => `<span class="secret mono">${esc(v)}</span>`},
    {key:'Server', label:'Server'},
    {key:'Notes', label:'Notes'},
  ], {label:'Extracted Secrets', sortKey:'ComputerName', sortDir:'asc', facet:'Parser'});

  new Grid(document.getElementById('grid-shares'), F.shares, [
    {key:'ComputerName', label:'Computer'},
    {key:'ShareName', label:'Share'},
    {key:'SharePath', label:'Path'},
    {key:'ShareType', label:'Type'},
    {key:'ShareAccess', label:'Reachable'},
    {key:'ShareDesc', label:'Description'},
  ], {label:'All Shares', sortKey:'ComputerName', sortDir:'asc', facet:'ShareAccess'});

  new Grid(document.getElementById('grid-computers'), F.computers, [
    {key:'ComputerName', label:'Computer'},
    {key:'IpAddress', label:'IP'},
    {key:'OperatingSystem', label:'Operating System'},
    {key:'Port445Open', label:'445 Open', fmt:yesNo},
    {key:'Pingable', label:'Alive', fmt:yesNo},
  ], {label:'Computers', sortKey:'ComputerName', sortDir:'asc'});
});
"""


def _card(number: Any, label: str, sub: str = "") -> str:
    number_text = f"{number:,}" if isinstance(number, int) else html.escape(str(number))
    return (
        f'<div class="card"><div class="n">{number_text}</div>'
        f'<div class="l">{html.escape(label)}</div>'
        f'{f"<div class=p>{html.escape(sub)}</div>" if sub else ""}</div>'
    )


def _rows(items: Sequence[Any]) -> List[Dict[str, Any]]:
    return [item.to_row() for item in items]


def _script_safe_json(payload: Any) -> str:
    """Serialise ``payload`` so it is safe to inline inside a <script> block.

    Scanned data is attacker-controlled: a share, file or account named
    ``</script><img onerror=...>`` would otherwise close the script element and
    execute in the analyst's browser when the report is opened. Escaping the
    HTML-significant characters as JSON unicode escapes keeps the value
    byte-identical after parsing while making early termination impossible.
    U+2028 and U+2029 are escaped because they are literal line terminators in
    JavaScript source but legal inside a JSON string.
    """
    text = json.dumps(payload, default=str)
    # Each replacement emits the literal 6-character sequence \uXXXX,
    # which a JSON parser turns back into the original character.
    for char, escape in (
        ("<", "\\u003c"),
        (">", "\\u003e"),
        ("&", "\\u0026"),
        ("\u2028", "\\u2028"),
        ("\u2029", "\\u2029"),
    ):
        text = text.replace(char, escape)
    return text


def build(results: ScanResults, out_path: str, max_rows: int = 25000) -> bool:
    """Render the report to ``out_path``.

    ``max_rows`` caps each embedded table so a very large scan still produces a
    file a browser can open; the full data always remains in the CSV exports.
    """
    stats = results.stats

    def cap(items: Sequence[Any]) -> List[Dict[str, Any]]:
        if len(items) > max_rows:
            warn(
                f"HTML report truncated to {max_rows:,} of {len(items):,} rows; "
                "see the CSV exports for the complete data"
            )
        return _rows(items[:max_rows])

    risk_counts = [
        [level, stats.get("risk_counts", {}).get(level, 0)]
        for level in ("Critical", "High", "Medium", "Low")
    ]
    category_counts = [
        [name, count] for name, count in (stats.get("category_counts") or {}).items()
    ]

    payload = {
        "excessive": cap(results.excessive),
        "interesting": cap(results.interesting_files),
        "secrets": cap(results.secrets),
        "shares": cap(results.shares),
        "computers": cap(results.computers),
        "riskCounts": risk_counts,
        "categoryCounts": category_counts,
        "commonNames": stats.get("common_names", [])[:20],
        "commonOwners": stats.get("common_owners", [])[:20],
        "commonIdentities": stats.get("common_identities", [])[:20],
        "timelineModified": stats.get("timeline_modified", [])[:20],
    }

    computer_count = len(results.computers)
    share_count = len(results.shares)
    acl_count = len(results.acls)

    cards = "".join([
        _card(computer_count, "Domain computers"),
        _card(len(results.computers_445), "TCP 445 reachable",
              stats.get("pct_445", "")),
        _card(share_count, "SMB shares found"),
        _card(acl_count, "Share ACL entries"),
        _card(stats.get("excessive_share_count", 0), "Shares with excessive privileges",
              stats.get("pct_excessive_shares", "")),
        _card(stats.get("read_share_count", 0), "Shares allowing READ",
              stats.get("pct_read_shares", "")),
        _card(stats.get("write_share_count", 0), "Shares allowing WRITE",
              stats.get("pct_write_shares", "")),
        _card(stats.get("high_risk_share_count", 0), "High risk shares",
              stats.get("pct_high_risk_shares", "")),
        _card(len(results.interesting_files), "Interesting files"),
        _card(len(results.secrets), "Secrets extracted"),
    ])

    doc = f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PowerHuntShares Report - {html.escape(results.target_domain)}</title>
<style>{_CSS}</style>
</head><body>
<header>
  <h1>SMB Share Exposure Report</h1>
  <div class="sub">
    Domain <b>{html.escape(results.target_domain)}</b> &middot;
    scan started {html.escape(results.start_time)} &middot;
    finished {html.escape(results.end_time)} &middot;
    run time {html.escape(results.run_time)}
  </div>
</header>
<main>

<section>
  <h2>Summary</h2>
  <div class="cards">{cards}</div>
</section>

<section>
  <h2>Risk Distribution</h2>
  <div class="grid2">
    <div class="panel"><h3>Excessive privilege ACEs by risk level</h3>
      <div id="risk-donut"></div></div>
    <div class="panel"><h3>Interesting files by category</h3>
      <div id="cat-donut"></div></div>
  </div>
</section>

<section>
  <h2>Common Patterns</h2>
  <div class="grid2">
    <div class="panel"><h3>Most common share names</h3><div id="top-names"></div></div>
    <div class="panel"><h3>Most common share owners</h3><div id="top-owners"></div></div>
    <div class="panel"><h3>Most common granted identities</h3><div id="top-identities"></div></div>
    <div class="panel"><h3>Shares by last modified year</h3><div id="timeline-mod"></div></div>
  </div>
</section>

<section>
  <h2>Excessive Privileges</h2>
  <p style="color:var(--muted);font-size:13px;margin:-6px 0 12px">
    ACL entries granting Everyone, Authenticated Users, BUILTIN\\Users, or Domain Users
    access to a reachable share. Scored using the upstream PowerHuntShares risk model.
  </p>
  <div id="grid-excessive"></div>
</section>

<section>
  <h2>Interesting Files</h2>
  <div id="grid-interesting"></div>
</section>

<section>
  <h2>Extracted Secrets</h2>
  <p style="color:var(--muted);font-size:13px;margin:-6px 0 12px">
    Credentials recovered by parsing config files found on readable shares.
    Treat every value here as live until proven otherwise.
  </p>
  <div id="grid-secrets"></div>
</section>

<section>
  <h2>All Shares</h2>
  <div id="grid-shares"></div>
</section>

<section>
  <h2>Computers</h2>
  <div id="grid-computers"></div>
</section>

</main>
<footer>
  Generated by PowerHuntShares-Linux &middot;
  a Python port of <a href="https://github.com/NetSPI/PowerHuntShares">NetSPI/PowerHuntShares</a>
  by Scott Sutherland &middot; 3-clause BSD.
</footer>
<script>window.PHS_DATA = {_script_safe_json(payload)};</script>
<script>{_JS}</script>
</body></html>"""

    try:
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as handle:
            handle.write(doc)
    except OSError as exc:
        warn(f"could not write HTML report: {exc}")
        return False

    size = os.path.getsize(out_path)
    substatus(f"HTML report written to {out_path} ({size / 1024:.0f} KB)")
    return True
