"""Report generation: CSV exports and the HTML summary."""
