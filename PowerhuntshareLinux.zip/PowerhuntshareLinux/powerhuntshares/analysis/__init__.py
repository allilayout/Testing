"""Analysis: excessive privilege detection, risk scoring, file triage."""
