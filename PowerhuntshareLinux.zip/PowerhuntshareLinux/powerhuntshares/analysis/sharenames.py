"""Static share-name knowledge base.

Maps a share name to the application that most likely created it, so an
analyst can triage an inventory without logging into each host. This table is
authored for this port rather than copied from upstream, and is intentionally
conservative: an entry only claims an application when the share name is a
strong signal on its own.
"""

from __future__ import annotations

from typing import Dict, Tuple

# name -> (application, description, expected local path)
SHARE_LIBRARY: Dict[str, Tuple[str, str, str]] = {
    # --- Windows defaults ---
    "admin$": ("Windows", "Administrative share mapped to the Windows directory.", "C:\\Windows"),
    "c$": ("Windows", "Administrative share mapped to the root of the C: volume.", "C:\\"),
    "d$": ("Windows", "Administrative share mapped to the root of the D: volume.", "D:\\"),
    "e$": ("Windows", "Administrative share mapped to the root of the E: volume.", "E:\\"),
    "f$": ("Windows", "Administrative share mapped to the root of the F: volume.", "F:\\"),
    "ipc$": ("Windows", "Inter-process communication share used for named pipes.", ""),
    "print$": ("Windows Print Spooler", "Hosts printer driver files.", "C:\\Windows\\System32\\spool\\drivers"),
    "fax$": ("Windows Fax", "Fax service working directory.", ""),
    "prnproc$": ("Windows Print Spooler", "Print processor directory.", ""),

    # --- Active Directory ---
    "sysvol": ("Active Directory", "Domain-wide policy and script store replicated between domain controllers.", "C:\\Windows\\SYSVOL\\sysvol"),
    "netlogon": ("Active Directory", "Logon script share replicated between domain controllers.", "C:\\Windows\\SYSVOL\\sysvol\\<domain>\\scripts"),

    # --- File server conventions ---
    "users": ("File Server", "Per-user home directory root. Frequently contains personal and business data.", ""),
    "home": ("File Server", "Per-user home directory root.", ""),
    "homes": ("Samba", "Samba automatic per-user home share.", ""),
    "profiles": ("File Server", "Roaming user profile store. May contain NTUSER.DAT hives and cached credentials.", ""),
    "redirected": ("File Server", "Folder redirection target for Documents/Desktop.", ""),
    "shared": ("File Server", "General purpose departmental share.", ""),
    "public": ("File Server", "Open access share, often world readable by design.", ""),
    "data": ("File Server", "General purpose data share.", ""),
    "departments": ("File Server", "Departmental file share root.", ""),
    "scans": ("Multifunction Printer", "Scan-to-folder destination. Often writable by an unauthenticated device account.", ""),
    "scan": ("Multifunction Printer", "Scan-to-folder destination.", ""),

    # --- Backup and imaging ---
    "backup": ("Backup", "Backup target. High value: may contain database dumps, VM images, and system state.", ""),
    "backups": ("Backup", "Backup target.", ""),
    "veeam": ("Veeam Backup & Replication", "Veeam backup repository.", ""),
    "veeambackup": ("Veeam Backup & Replication", "Veeam backup repository.", ""),
    "images": ("Imaging", "OS deployment image store.", ""),
    "reminst": ("Windows Deployment Services", "RemoteInstall share for PXE deployment. May contain unattend.xml and bootstrap.ini credentials.", "C:\\RemoteInstall"),
    "remoteinstall": ("Windows Deployment Services", "RemoteInstall share for PXE deployment.", "C:\\RemoteInstall"),
    "deploymentshare$": ("Microsoft Deployment Toolkit", "MDT deployment share. bootstrap.ini and CustomSettings.ini commonly hold domain join credentials.", ""),
    "mdt": ("Microsoft Deployment Toolkit", "MDT deployment share.", ""),

    # --- Software distribution / management ---
    "sms_site": ("SCCM / ConfigMgr", "Configuration Manager site share.", ""),
    "sms_dp$": ("SCCM / ConfigMgr", "Configuration Manager distribution point.", ""),
    "sccmcontentlib$": ("SCCM / ConfigMgr", "Configuration Manager content library.", ""),
    "software": ("Software Distribution", "Application installer repository. Writable access can enable supply-chain style attacks.", ""),
    "apps": ("Software Distribution", "Application repository.", ""),
    "install": ("Software Distribution", "Installer repository.", ""),
    "packages": ("Software Distribution", "Package repository.", ""),

    # --- Web and application servers ---
    "wwwroot": ("IIS", "IIS web root. Write access typically yields remote code execution.", "C:\\inetpub\\wwwroot"),
    "inetpub": ("IIS", "IIS root directory. Write access typically yields remote code execution.", "C:\\inetpub"),
    "webroot": ("Web Server", "Web content root. Write access typically yields remote code execution.", ""),
    "tomcat": ("Apache Tomcat", "Tomcat installation. Check tomcat-users.xml for manager credentials.", ""),
    "jboss": ("JBoss / WildFly", "JBoss installation. Check standalone.xml and jboss-cli.xml.", ""),

    # --- Databases ---
    "mssql": ("Microsoft SQL Server", "SQL Server directory. May contain .mdf/.bak files.", ""),
    "sqlbackup": ("Microsoft SQL Server", "SQL Server backup target. .bak files can be restored offline.", ""),
    "ssms": ("SQL Server Management Studio", "SSMS working directory. May contain saved connection details.", ""),
    "mysql": ("MySQL", "MySQL data or config directory. Check my.cnf for credentials.", ""),
    "oracle": ("Oracle", "Oracle installation. Check tnsnames.ora.", ""),

    # --- Virtualisation ---
    "vms": ("Hypervisor", "Virtual machine storage. VMDK/VHDX files can be mounted offline to extract hashes.", ""),
    "hyper-v": ("Hyper-V", "Hyper-V virtual machine storage.", ""),
    "vmware": ("VMware", "VMware virtual machine storage.", ""),
    "iso": ("Hypervisor", "ISO image library.", ""),

    # --- Development ---
    "source": ("Development", "Source code repository. May contain hardcoded credentials.", ""),
    "src": ("Development", "Source code repository.", ""),
    "dev": ("Development", "Development share.", ""),
    "build": ("Build System", "Build output directory. Write access can poison artifacts.", ""),
    "jenkins": ("Jenkins", "Jenkins home. Check credentials.xml and the secrets directory.", ""),

    # --- Departmental / sensitive by convention ---
    "hr": ("Business", "Human Resources share. Likely contains PII.", ""),
    "finance": ("Business", "Finance share. Likely contains financial records and PII.", ""),
    "accounting": ("Business", "Accounting share. Likely contains financial records.", ""),
    "payroll": ("Business", "Payroll share. Likely contains PII and bank details.", ""),
    "legal": ("Business", "Legal share. Likely contains privileged material.", ""),
    "it": ("IT Department", "IT share. Frequently contains build documentation, scripts, and credentials.", ""),
    "helpdesk": ("IT Department", "Helpdesk share.", ""),
}


def guess(share_name: str) -> Tuple[str, str]:
    """Return ``(application, description)`` for a share name.

    Falls back to ``("Unknown", "Unknown")`` so the caller can render the
    column without special-casing misses, matching upstream behaviour.
    """
    entry = SHARE_LIBRARY.get((share_name or "").strip().lower())
    if not entry:
        return ("Unknown", "Unknown")

    application, description, local_path = entry
    text = f"The {share_name} share may be associated with {application}. {description}"
    if local_path:
        text += f" {local_path} is the expected local path."
    return (application, text.strip())
