"""Interesting-file keyword table.

A direct port of the ``$FileNamePatternsAll`` DataTable from the original
module, including the parser bindings. Patterns are PowerShell ``-like`` globs
and are matched case-insensitively against the file name only.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from typing import Dict, List, Optional

from ..util import warn

CATEGORIES = ("Secret", "Sensitive", "SystemImage", "Database", "Backup", "Script", "Binaries")

# Extensions filtered out of the interesting-file results, matching the
# $ImageFormats exclusion list upstream.
IMAGE_FORMATS = (
    "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp", "*.ico",
    "*.svg", "*.webp", "*.mif", "*.heic", "*.msi",
)


@dataclass(frozen=True)
class Keyword:
    keyword: str
    description: str
    instructions: str
    category: str
    parser: str = ""


def _k(keyword: str, description: str, category: str, parser: str = "") -> Keyword:
    return Keyword(keyword, description, "None.", category, parser)


# --- Sensitive data ---------------------------------------------------------
_SENSITIVE = [
    _k("*credit*", "Credit card number and/or PII.", "Sensitive"),
    _k("*pci*", "", "Sensitive"),
    _k("*social*", "", "Sensitive"),
    _k("*ssn*", "", "Sensitive"),
    _k("human*", "", "Sensitive"),
    _k("finance*", "", "Sensitive"),
    _k("*medical*", "", "Sensitive"),
    _k("Health*", "", "Sensitive"),
    _k("Billing*", "", "Sensitive"),
    _k("*payment*", "", "Sensitive"),
    _k("patient*", "", "Sensitive"),
    _k("HR*", "", "Sensitive"),
    # Additions beyond the upstream table; see README for the full list.
    _k("*payroll*", "Payroll records. Likely contains PII and bank details.", "Sensitive"),
    _k("*salary*", "Compensation data.", "Sensitive"),
    _k("*passport*", "Identity document scans.", "Sensitive"),
    _k("*invoice*", "Financial records.", "Sensitive"),
    _k("*confidential*", "Explicitly marked confidential.", "Sensitive"),
    _k("*nessus*", "This is a vulnerability scanner.", "Sensitive"),
    _k("*nexpose*", "This is a vulnerability scanner.", "Sensitive"),
    _k("*qualys*", "This is a vulnerability scanner.", "Sensitive"),
    _k("*tripwire*", "This is a vulnerability scanner.", "Sensitive"),
]

# --- Secrets / credentials --------------------------------------------------
_SECRET = [
    _k("Bootstrap.ini*", "Used for Windows Deployment services (WDS) PXE installation and may contain credentials.", "Secret", "bootstrap_ini"),
    _k("*.bcd", "", "Secret"),
    _k("*app.config*", "", "Secret", "app_config"),
    _k("context.xml*", "", "Secret", "context_xml"),
    _k("db2cli.ini*", "", "Secret", "dbx_driver_ini"),
    _k("dbxdrivers.ini*", "", "Secret", "dbx_driver_ini"),
    _k("pureftpd.passwd*", "", "Secret", "pureftpd_passwd"),
    _k("ftpd.*", "", "Secret"),
    _k("ftpusers*", "", "Secret"),
    _k("httpd.conf*", "", "Secret"),
    _k("hudson.security.HudsonPrivateSecurityRealm.*", "", "Secret", "jenkins_config"),
    _k("config.xml*", "", "Secret", "jenkins_config"),
    _k("*preInst.bds*", "", "Secret"),
    _k("jboss-cli.xml*", "", "Secret", "jboss_cli"),
    _k("jboss-logmanager.properties*", "", "Secret"),
    _k("jenkins.model.JenkinsLocationConfiguration.*", "", "Secret"),
    _k("machine.config*", "", "Secret", "machine_config"),
    _k("startup*", "", "Secret", "cisco_config"),
    _k("running*", "", "Secret", "cisco_config"),
    _k("my.*", "", "Secret", "my_cnf"),
    _k("mysql.user*", "", "Secret"),
    _k("nginx.conf*", "", "Secret"),
    _k("*ntds.dit*", "The Active Directory database. Contains all domain password hashes.", "Secret"),
    _k("pg_hba.conf*", "", "Secret"),
    _k("php.ini*", "", "Secret", "php_ini"),
    _k("*.pfx*", "Private key.", "Secret", "private_key"),
    _k("policy.xml*", "May be associated with SCCM/ConfigMgr and contain credentials to support PXE that can be recovered, base64 decoded, or decrypted using PXEThief or CMvarDecrypt.", "Secret"),
    _k(".pol*", "May contain credentials to support PXE or other things.", "Secret"),
    _k("putty.reg*", "", "Secret", "putty_reg"),
    _k("postgresql.conf*", "", "Secret"),
    _k("SAM", "", "Secret", "private_key"),
    _k("SAM-*", "", "Secret", "private_key"),
    _k("SAM_*", "", "Secret", "private_key"),
    _k("SYSTEM", "", "Secret"),
    _k("server.xml*", "", "Secret", "server_xml"),
    _k("shadow*", "", "Secret", "shadow"),
    _k("standalone.xml*", "", "Secret", "standalone_xml"),
    _k("tnsnames.ora*", "", "Secret", "tnsnames_ora"),
    _k("tomcat-users.xml*", "", "Secret", "tomcat_users"),
    _k("sitemanager.xml*", "", "Secret", "sitemanager_xml"),
    _k("users.*", "", "Secret"),
    _k("*variable*.dat*", "This file is used for SCCM/ConfigMgr PXE deployments. It may contain passwords that can be recovered, base64 decoded, or decrypted using PXEThief or CMvarDecrypt.", "Secret"),
    _k("*.var*", "Often contains credentials. May be associated with SCCM/MECM.", "Secret"),
    _k("*setting.ini*", "", "Secret", "ini_file"),
    _k("*vcenter*", "", "Secret", "private_key"),
    _k("*vault*", "", "Secret", "private_key"),
    _k("*DefaultAppPool*", "", "Secret"),
    _k("*WinSCP.ini*", "", "Secret", "winscp_ini"),
    _k("*.kdbx", "KeePass database.", "Secret"),
    _k("wp-config.php*", "", "Secret", "wp_config"),
    _k("*.config", "", "Secret", "web_config"),
    _k("*.dtsx*", "", "Secret", "ssis_dtsx"),
    _k("*.rdp*", "", "Secret", "rdp_file"),
    _k("*.aws*", "", "Secret", "private_key"),
    _k("*vnc.ini*", "", "Secret", "vnc_ini"),
    _k("*DataSources.xml*", "Group policy file that may contain passwords.", "Secret", "gpp"),
    _k("*ScheduledTasks.xml*", "Group policy file that may contain passwords.", "Secret", "gpp"),
    _k("*Groups.xml*", "Group policy file that may contain passwords.", "Secret", "gpp"),
    _k("*Drives.xml*", "Group policy file that may contain passwords.", "Secret", "gpp"),
    _k("*Services.xml*", "Group policy file that may contain passwords.", "Secret", "gpp"),
    _k("*Printers.xml*", "Group policy file that may contain passwords.", "Secret", "gpp"),
    _k("*unattend*", "", "Secret", "unattend"),
    _k("*sysprep*", "", "Secret", "sysprep"),
    _k("*.key", "", "Secret", "private_key"),
    _k("*.private", "", "Secret", "private_key"),
    _k("*.pem", "", "Secret", "private_key"),
    _k("*.p12", "", "Secret", "private_key"),
    _k("*.pfx", "", "Secret", "private_key"),
    _k("*.crt", "", "Secret", "private_key"),
    _k("*.ppk", "", "Secret", "private_key"),
    _k("*.der", "", "Secret", "private_key"),
    _k("id_rsa*", "", "Secret", "private_key"),
    _k("id_dsa*", "", "Secret", "private_key"),
    _k("id_e*", "", "Secret", "private_key"),
    _k("*sssd.conf*", "", "Secret", "sssd_conf"),
    _k("*smb.conf*", "", "Secret", "smb_conf"),
    _k("*krb5.conf*", "", "Secret", "krb5_conf"),
    _k("*krb5cc*", "Kerberos credential cache.", "Secret"),
    _k("*htpasswd*", "", "Secret", "htpasswd"),
    _k("profiles.txt", "", "Secret"),
    _k("*pgpass*", "", "Secret", "pgpass"),
    _k("vas.conf", "May include auth configs.", "Secret"),
    _k("grub.cfg", "", "Secret", "grub_config"),
    _k("grub.conf", "", "Secret", "grub_config"),
    _k("*.fetchmailrc", "", "Secret", "fetchmailrc"),
    _k("*.keytab", "May store authentication tokens.", "Secret"),
    _k("*mysql_history*", "", "Secret"),
    _k("*psql_history*", "", "Secret"),
    _k("*.git-credentials*", "", "Secret", "git_credentials"),
    _k("*azure.config.ini*", "", "Secret"),
    _k("*azure.profile.json*", "", "Secret"),
    _k("*.azure", "", "Secret"),
    _k("*dbeaver-data-sources.xml", "", "Secret"),
    _k("*.s3cfg", "", "Secret"),
    _k("*.netrc", "", "Secret", "netrc"),
    _k("*jmx-console-users.properties", "", "Secret"),
    _k("*dbvis.xml", "", "Secret", "dbvis_xml"),
    _k("*remmina.pref", "", "Secret", "remmina_pref"),
    _k("*.remmina", "", "Secret", "remmina"),
    _k("*credentials.xml", "Used for Jenkins.", "Secret"),
    _k("*lastpass*", "", "Secret"),
    _k("*thycotic*", "", "Secret"),
    _k("*cyberark*", "", "Secret"),
]

# --- System and VM images ---------------------------------------------------
_SYSTEM_IMAGE = [
    _k("*.img*", "", "SystemImage"),
    _k("*.iso*", "This is a system image. It may contain passwords in Variables.dat, unattend.xml, and policy.xml files.", "SystemImage"),
    _k("*.wmi*", "This is a system image. It may contain passwords in Variables.dat, unattend.xml, and policy.xml files.", "SystemImage"),
    _k("*.wim*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vmx*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vmdk*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.nvram*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vmsd*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vmsn*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vmss*", "This is a virtual memory file that could be used to recover data or system images.", "SystemImage"),
    _k("*.vmem*", "This is a virtual memory file that could be used to recover data or system images.", "SystemImage"),
    _k("*.vhd*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vhdx*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.avhd*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.avhdx*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vsv*", "This is a virtual memory file that could be used to recover data or system images.", "SystemImage"),
    _k("*.vbox*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vbox-prev*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.vdi*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.hdd*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.qcow*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.qcow2*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.pvm*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.pvs*", "This is a virtual machine image file.", "SystemImage"),
    _k("*.sav*", "", "SystemImage"),
    _k("*.dmp*", "This is a memory dump file.", "SystemImage"),
    _k("*.docker*", "This is a docker image file.", "SystemImage"),
]

# --- Databases --------------------------------------------------------------
_DATABASE = [
    _k("*database*", "", "Database"),
    _k("*.sql*", "", "Database"),
    _k("*.sqlite*", "", "Database"),
    _k("*.idf*", "", "Database"),
    _k("*.mdf*", "", "Database"),
    _k("*.msf*", "", "Database"),
    _k("*.ora*", "", "Database"),
    _k("*oracle*", "", "Database"),
    _k("*.tbd", "", "Database"),
    _k("*.vdb", "", "Database"),
    _k("*.db", "", "Database"),
]

# --- Backups ----------------------------------------------------------------
_BACKUP = [
    _k("*.bak*", "", "Backup"),
    _k("*.bkf*", "", "Backup"),
    _k("*backup*", "", "Backup"),
    _k("*.tar*", "", "Backup"),
    _k("*.zip*", "", "Backup"),
    _k("IT*", "May contain IT department files.", "Backup"),
]

# --- Scripts ----------------------------------------------------------------
_SCRIPT = [
    _k(p, "", "Script")
    for p in (
        "*.ps1*", "*.psm1*", "*.psd1*", "*.bat*", "*.sh*", "*.vbs*", "*.cmd*",
        "*.wsh*", "*.wsf*", "*.php*", "*.py", "*.jsp", "*.do*", "*.asmx",
        "*.aspx", "*.cfm", "*.asp", "*.cs", "*.vb", "*.rb", "*.inc",
    )
]

# --- Binaries ---------------------------------------------------------------
_BINARIES = [
    _k("*.dll", "", "Binaries"),
    _k("*.exe", "", "Binaries"),
    _k("*.msi", "", "Binaries"),
    _k("*.jar", "", "Binaries"),
    _k("*.war", "", "Binaries"),
    _k("*Program Files*", "This is an application directory.", "Binaries"),
]

DEFAULT_KEYWORDS: List[Keyword] = (
    _SENSITIVE + _SECRET + _SYSTEM_IMAGE + _DATABASE + _BACKUP + _SCRIPT + _BINARIES
)


def load_keywords(path: Optional[str] = None) -> List[Keyword]:
    """Load keywords from a CSV file, falling back to the built-in table.

    The CSV format matches ``interesting-files-template.csv`` from the original
    project: Keyword, Description, Instructions, Category, and an optional
    Parser column.
    """
    if not path:
        return list(DEFAULT_KEYWORDS)

    out: List[Keyword] = []
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                keyword = (row.get("Keyword") or "").strip()
                if not keyword:
                    continue
                out.append(
                    Keyword(
                        keyword=keyword,
                        description=(row.get("Description") or "").strip(),
                        instructions=(row.get("Instructions") or "None.").strip(),
                        category=(row.get("Category") or "Sensitive").strip(),
                        parser=(row.get("Parser") or row.get("ParserFunction") or "").strip(),
                    )
                )
    except OSError as exc:
        warn(f"could not read keyword file {path}: {exc}; using built-in list")
        return list(DEFAULT_KEYWORDS)

    if not out:
        warn(f"{path} contained no usable keywords; using built-in list")
        return list(DEFAULT_KEYWORDS)
    return out


def by_category(keywords: List[Keyword]) -> Dict[str, List[Keyword]]:
    grouped: Dict[str, List[Keyword]] = {}
    for kw in keywords:
        grouped.setdefault(kw.category, []).append(kw)
    return grouped
