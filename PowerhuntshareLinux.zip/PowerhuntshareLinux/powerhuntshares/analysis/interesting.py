"""Match discovered files against the interesting-file keyword table."""

from __future__ import annotations

from typing import List, Sequence

from ..models import FileEntry, InterestingFile
from ..util import like
from .keywords import IMAGE_FORMATS, Keyword

# Category precedence when one file name matches several keywords: the most
# actionable finding wins so a "backup.sql" is reported as a Database rather
# than a Backup, and anything credential-bearing outranks everything else.
CATEGORY_PRIORITY = {
    "Secret": 0,
    "Sensitive": 1,
    "SystemImage": 2,
    "Database": 3,
    "Backup": 4,
    "Script": 5,
    "Binaries": 6,
}


def is_excluded(file_name: str) -> bool:
    """Filter out image and installer formats, as the original module does."""
    return any(like(file_name, pattern) for pattern in IMAGE_FORMATS)


def match_file(file_name: str, keywords: Sequence[Keyword]) -> List[Keyword]:
    """Return every keyword whose glob matches ``file_name``."""
    return [kw for kw in keywords if like(file_name, kw.keyword)]


def best_match(file_name: str, keywords: Sequence[Keyword]) -> Keyword | None:
    """Return the single highest-priority keyword match, if any."""
    matches = match_file(file_name, keywords)
    if not matches:
        return None
    return min(matches, key=lambda kw: (CATEGORY_PRIORITY.get(kw.category, 99), len(kw.keyword)))


def find_interesting(
    files: Sequence[FileEntry],
    keywords: Sequence[Keyword],
    include_directories: bool = False,
) -> List[InterestingFile]:
    """Scan a file listing and produce one record per interesting file."""
    out: List[InterestingFile] = []

    for entry in files:
        if entry.IsDirectory and not include_directories:
            continue
        name = entry.FileName
        if not name or is_excluded(name):
            continue

        match = best_match(name, keywords)
        if match is None:
            continue

        out.append(
            InterestingFile(
                ComputerName=entry.ComputerName,
                ShareName=entry.ShareName,
                SharePath=entry.SharePath,
                UncPath=entry.FilePath,
                FileName=name,
                Category=match.category,
                Keyword=match.keyword,
                Description=match.description,
                Instructions=match.instructions,
                FileSize=entry.FileSize,
                LastModified=entry.LastModified,
            )
        )
    return out


def parseable(
    interesting: Sequence[InterestingFile],
    keywords: Sequence[Keyword],
    max_size: int = 1024 * 1024,
) -> List[tuple]:
    """Select interesting files that a config parser can extract secrets from.

    Returns ``(InterestingFile, parser_name)`` pairs. Oversized files are
    skipped: every supported config format is small, and downloading a
    multi-gigabyte match would stall the scan.
    """
    out: List[tuple] = []
    for item in interesting:
        if item.FileSize > max_size:
            continue
        for kw in match_file(item.FileName, keywords):
            if kw.parser:
                out.append((item, kw.parser))
                break
    return out
