"""Excessive privilege identification and risk scoring.

The weights, thresholds and level boundaries are ported verbatim from the
original module so that a Linux scan of the same environment produces the same
risk scores as a Windows scan.
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Sequence

from ..models import Computer, InterestingFile, ShareACL, ShareACLFinal
from ..util import any_like

# Identities that make an ACE "excessive": these are groups every authenticated
# principal in the domain lands in.
EXCESSIVE_IDENTITIES = ("Everyone", "BUILTIN\\Users", "Authenticated Users")
EXCESSIVE_IDENTITY_PATTERNS = ("*domain users*", "*domain computers*")

# Shares excluded from the excessive check: broad access on these is by design.
EXCLUDED_SHARE_PATTERNS = ("print$", "prnproc$", "*printer*", "sysvol", "netlogon")

# Share names that grant code execution or web-root write when accessible.
HIGH_RISK_SHARE_PATTERNS = ("c$", "admin$", "*wwwroot*", "*inetpub*", "c", "c_share")

# Administrative shares present on a stock Windows install.
DEFAULT_SHARE_PATTERNS = ("admin$", "c$", "d$", "e$", "f$", "ipc$", "print$")

# --- Risk weights (unchanged from upstream) ---------------------------------
RISK_WEIGHT_RCE = 2
RISK_WEIGHT_HR = 16
RISK_WEIGHT_DATA = 8
RISK_WEIGHT_DATA_VOLUME = 1
RISK_WEIGHT_SECRETS = 2
RISK_WEIGHT_SECRETS_VOLUME = 1
RISK_WEIGHT_WRITE = 5
RISK_WEIGHT_READ = 3
RISK_WEIGHT_EMPTY = -1
RISK_WEIGHT_STALE = -1

VOLUME_THRESHOLD = 10


def is_excessive_identity(identity: str) -> bool:
    """True when an ACE's principal is a broad, everyone-includes-me group."""
    if not identity:
        return False
    normalized = identity.strip()
    if normalized in EXCESSIVE_IDENTITIES:
        return True
    # Match the bare form as well as DOMAIN\Group.
    tail = normalized.split("\\")[-1]
    if tail in ("Everyone", "Users", "Authenticated Users"):
        return True
    return any_like(normalized, EXCESSIVE_IDENTITY_PATTERNS)


def find_excessive(acls: Sequence[ShareACL]) -> List[ShareACL]:
    """Filter ACLs down to the potentially excessive ones.

    An ACE qualifies when it grants a broad group access to a reachable,
    non-excluded share.
    """
    out: List[ShareACL] = []
    for acl in acls:
        if acl.AccessControlType == "Deny":
            continue
        if not is_excessive_identity(acl.IdentityReference):
            # The synthetic effective-access record has no real identity but
            # still represents confirmed access, so keep it.
            if acl.IdentityReference != "(effective access)":
                continue
        if acl.ShareAccess != "Yes":
            continue
        if any_like(acl.ShareName, EXCLUDED_SHARE_PATTERNS):
            continue
        out.append(acl)
    return out


def has_read(rights: str) -> bool:
    return "read" in (rights or "").lower()


def has_write(rights: str) -> bool:
    lowered = (rights or "").lower()
    return any(
        token in lowered
        for token in (
            "genericall", "fullcontrol", "modify", "write",
            "create", "addfile", "appenddata", "delete",
        )
    )


def is_high_risk(share_name: str) -> bool:
    return any_like(share_name, HIGH_RISK_SHARE_PATTERNS)


def is_default(share_name: str) -> bool:
    return any_like(share_name, DEFAULT_SHARE_PATTERNS)


def _parse_date(value: str) -> Optional[datetime]:
    if not value:
        return None
    for fmt in ("%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M", "%m/%d/%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value.strip(), fmt)
        except ValueError:
            continue
    return None


def score(
    acl: ShareACL,
    secret_count: int = 0,
    sensitive_count: int = 0,
    stale_days: int = 365,
) -> Dict[str, int]:
    """Compute the risk flags and score for one ACE.

    Returns the individual boolean flags alongside the total so the report can
    explain *why* a share scored the way it did.
    """
    rights = acl.FileSystemRights or ""
    allowed = acl.AccessControlType != "Deny"

    high_risk = 1 if is_high_risk(acl.ShareName) else 0
    write = 1 if (allowed and has_write(rights)) else 0
    read = 1 if has_read(rights) else 0
    rce = 1 if (high_risk and write) else 0
    empty = 1 if acl.FileCount == 0 else 0

    # "Stale" means the share root has not been modified within the window.
    modified = _parse_date(acl.LastModifiedDate)
    if modified is None:
        stale = 0
    else:
        stale = 1 if modified < (datetime.now() - timedelta(days=stale_days)) else 0

    has_secrets = 1 if secret_count > 0 else 0
    has_data = 1 if sensitive_count > 0 else 0

    total = 0
    if rce:
        total += RISK_WEIGHT_RCE
    if high_risk:
        total += RISK_WEIGHT_HR
    if has_data:
        total += RISK_WEIGHT_DATA
    if sensitive_count > VOLUME_THRESHOLD:
        total += RISK_WEIGHT_DATA_VOLUME
    if has_secrets:
        total += RISK_WEIGHT_SECRETS
    if secret_count > VOLUME_THRESHOLD:
        total += RISK_WEIGHT_SECRETS_VOLUME
    if write:
        total += RISK_WEIGHT_WRITE
    if read:
        total += RISK_WEIGHT_READ
    if empty:
        total += RISK_WEIGHT_EMPTY
    if stale:
        total += RISK_WEIGHT_STALE

    if total < 0:
        total = 1

    return {
        "HasRead": read,
        "HasWrite": write,
        "HasHR": high_risk,
        "HasRCE": rce,
        "HasIF": has_data,
        "HasSecrets": has_secrets,
        "IsEmpty": empty,
        "IsStale": stale,
        "IsDefault": 1 if is_default(acl.ShareName) else 0,
        "RiskScore": total,
    }


def risk_level(value: int) -> str:
    """Map a numeric score onto the four upstream severity bands."""
    if value >= 20:
        return "Critical"
    if value >= 11:
        return "High"
    if value > 4:
        return "Medium"
    return "Low"


def enrich(
    excessive: Sequence[ShareACL],
    interesting_files: Sequence[InterestingFile],
    computers: Sequence[Computer],
    share_guesses: Optional[Dict[str, tuple]] = None,
    stale_days: int = 365,
) -> List[ShareACLFinal]:
    """Turn excessive ACLs into scored, annotated final records."""
    share_guesses = share_guesses or {}

    # Index interesting files by share path so scoring is O(1) per ACE rather
    # than a full scan of the file list.
    secrets_by_share: Dict[str, int] = {}
    sensitive_by_share: Dict[str, int] = {}
    total_by_share: Dict[str, int] = {}
    for item in interesting_files:
        key = item.SharePath.lower()
        total_by_share[key] = total_by_share.get(key, 0) + 1
        if item.Category == "Secret":
            secrets_by_share[key] = secrets_by_share.get(key, 0) + 1
        elif item.Category == "Sensitive":
            sensitive_by_share[key] = sensitive_by_share.get(key, 0) + 1

    os_by_computer = {c.ComputerName.lower(): c.OperatingSystem for c in computers}

    out: List[ShareACLFinal] = []
    for acl in excessive:
        key = acl.SharePath.lower()
        secret_count = secrets_by_share.get(key, 0)
        sensitive_count = sensitive_by_share.get(key, 0)

        flags = score(
            acl,
            secret_count=secret_count,
            sensitive_count=sensitive_count,
            stale_days=stale_days,
        )
        guess_app, guess_desc = share_guesses.get(acl.ShareName.lower(), ("Unknown", "Unknown"))

        final = ShareACLFinal(
            **asdict(acl),
            ComputerOS=os_by_computer.get(acl.ComputerName.lower(), ""),
            ShareDescriptionGuess=guess_desc,
            ShareGuessStatic=guess_app,
            InterestingFileCount=total_by_share.get(key, 0),
            SecretFileCount=secret_count,
            SensitiveFileCount=sensitive_count,
            RiskLevel=risk_level(flags["RiskScore"]),
            **flags,
        )
        out.append(final)

    out.sort(key=lambda r: (-r.RiskScore, r.ComputerName, r.ShareName))
    return out
