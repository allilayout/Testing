"""PowerHuntShares-Linux.

A Python port of NetSPI's PowerHuntShares (Scott Sutherland) that runs natively
on Linux. SMB and LDAP access go through impacket and ldap3 instead of the
Windows-only .NET APIs the original module relied on.
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
