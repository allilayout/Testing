"""Data models for PowerHuntShares-Linux.

Field names deliberately mirror the CSV column names emitted by the original
PowerShell module (NetSPI/PowerHuntShares) so that downstream tooling and
existing analysis workflows keep working unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any, Dict, List


def _row(obj: Any) -> Dict[str, Any]:
    """Flatten a dataclass into an ordered dict suitable for csv.DictWriter."""
    out: Dict[str, Any] = {}
    for f in fields(obj):
        val = getattr(obj, f.name)
        if isinstance(val, bool):
            val = 1 if val else 0
        elif val is None:
            val = ""
        out[f.name] = val
    return out


@dataclass
class Computer:
    """A target host, either from LDAP or from a supplied host list."""

    ComputerName: str
    OperatingSystem: str = ""
    ServicePack: str = ""
    IpAddress: str = ""
    Pingable: bool = False
    Port445Open: bool = False

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class Subnet:
    """An Active Directory site subnet object."""

    Subnet: str = ""
    Site: str = ""
    Description: str = ""
    Created: str = ""
    Changed: str = ""

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class Share:
    """An SMB share as returned by the server's share enumeration."""

    ComputerName: str
    IpAddress: str = ""
    ShareName: str = ""
    ShareDesc: str = ""
    SharePath: str = ""
    ShareType: str = ""
    # "Yes" when we could actually open/list the share root, "No" otherwise.
    # Mirrors the original module's ShareAccess semantics.
    ShareAccess: str = "No"

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class ShareACL:
    """One ACE on a share, joined with the share's metadata.

    This is the central record of the whole tool: every downstream summary,
    risk score and report section is derived from a list of these.
    """

    ComputerName: str = ""
    IpAddress: str = ""
    ShareName: str = ""
    SharePath: str = ""
    ShareDescription: str = ""
    ShareOwner: str = ""
    ShareType: str = ""
    ShareAccess: str = ""
    FileSystemRights: str = ""
    IdentityReference: str = ""
    IdentitySID: str = ""
    AccessControlType: str = ""
    CreationDate: str = ""
    CreationDateYear: str = ""
    LastModifiedDate: str = ""
    LastModifiedDateYear: str = ""
    LastAccessDate: str = ""
    LastAccessDateYear: str = ""
    FileCount: int = 0
    FileList: str = ""
    FileListGroup: str = ""
    AuditSettings: str = ""
    # Source of the ACL: "ntfs" (share root security descriptor via SMB2
    # QUERY_INFO) or "share" (srvsvc NetrShareGetInfo level 502).
    AclSource: str = ""

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class ShareACLFinal(ShareACL):
    """A ShareACL enriched with analysis flags and a risk score."""

    ComputerOS: str = ""
    ShareDescriptionGuess: str = ""
    ShareGuessStatic: str = ""
    HasRead: int = 0
    HasWrite: int = 0
    HasHR: int = 0
    HasRCE: int = 0
    HasIF: int = 0
    HasSecrets: int = 0
    IsEmpty: int = 0
    IsStale: int = 0
    IsDefault: int = 0
    InterestingFileCount: int = 0
    SecretFileCount: int = 0
    SensitiveFileCount: int = 0
    RiskScore: int = 0
    RiskLevel: str = "Low"

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class FileEntry:
    """A single file or directory discovered while walking a share."""

    ComputerName: str = ""
    IpAddress: str = ""
    ShareName: str = ""
    SharePath: str = ""
    FilePath: str = ""
    FileName: str = ""
    IsDirectory: bool = False
    FileSize: int = 0
    LastModified: str = ""
    Depth: int = 0

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class InterestingFile:
    """A file whose name matched one of the interesting-file keywords."""

    ComputerName: str = ""
    ShareName: str = ""
    SharePath: str = ""
    UncPath: str = ""
    FileName: str = ""
    Category: str = ""
    Keyword: str = ""
    Description: str = ""
    Instructions: str = ""
    FileSize: int = 0
    LastModified: str = ""

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class ExtractedSecret:
    """A credential recovered from a config file by one of the parsers."""

    ComputerName: str = ""
    ShareName: str = ""
    UncPath: str = ""
    FileName: str = ""
    Parser: str = ""
    Name: str = ""
    Section: str = ""
    Url: str = ""
    Server: str = ""
    Port: str = ""
    UserName: str = ""
    Password: str = ""
    Notes: str = ""

    def to_row(self) -> Dict[str, Any]:
        return _row(self)


@dataclass
class ScanResults:
    """Everything a scan produced, handed to the reporters as one bundle."""

    target_domain: str = "SmbHunt"
    start_time: str = ""
    end_time: str = ""
    run_time: str = ""
    computers: List[Computer] = field(default_factory=list)
    subnets: List[Subnet] = field(default_factory=list)
    computers_pingable: List[Computer] = field(default_factory=list)
    computers_445: List[Computer] = field(default_factory=list)
    shares: List[Share] = field(default_factory=list)
    acls: List[ShareACL] = field(default_factory=list)
    excessive: List[ShareACLFinal] = field(default_factory=list)
    files: List[FileEntry] = field(default_factory=list)
    interesting_files: List[InterestingFile] = field(default_factory=list)
    secrets: List[ExtractedSecret] = field(default_factory=list)
    # Free-form counters filled in by the analysis stage and consumed by the
    # HTML report.
    stats: Dict[str, Any] = field(default_factory=dict)
