# PowerHuntShares-Linux

A Python port of [NetSPI/PowerHuntShares](https://github.com/NetSPI/PowerHuntShares)
by Scott Sutherland, rewritten to run natively on Linux.

The original is a PowerShell module that depends on Windows-only APIs —
`System.DirectoryServices` for LDAP, `Get-Acl` over UNC paths for NTFS security
descriptors, and `NetShareEnum` via P/Invoke. None of that exists on Linux, so
this is a reimplementation of the logic on top of **impacket** and **ldap3**
rather than a translation of the script.

The analysis is faithful: the excessive-privilege rules, risk weights, severity
bands, and interesting-file keyword table are ported directly, so a Linux scan
of an environment produces the same risk scores as a Windows scan.

---

## What it does

1. Enumerates domain computers and site subnets from Active Directory over LDAP
2. Checks host liveness and TCP 445 reachability
3. Enumerates SMB shares on every reachable host
4. Reads the NTFS security descriptor of each share root and decodes its ACEs
5. Resolves SIDs to names (static table first, then LSAT against the target)
6. Flags ACEs granting broad groups access to reachable shares
7. Walks readable shares for interesting files
8. Downloads and parses config files to extract credentials
9. Scores every finding and writes CSV exports plus a single-file HTML report

---

## Install

```bash
git clone <this-repo> && cd PowerhuntshareLinux
python3 -m pip install -r requirements.txt
```

Then run it straight from the clone:

```bash
python3 powerhuntshares.py --help
```

Or install it as a command:

```bash
python3 -m pip install -e .
powerhuntshares --help
```

**Dependencies.** `impacket` and `ldap3` are required. `pycryptodome` is
strongly recommended — without it, Group Policy Preferences `cpassword` values
(MS14-025) and VNC passwords are reported in their stored form instead of
decrypted. `dnspython` is optional and only enables `_ldap._tcp` SRV
auto-discovery of a domain controller; without it, pass `--dc` explicitly.

---

## Usage

```bash
# Domain scan with a password
python3 powerhuntshares.py -d corp.local -u analyst -p 'Passw0rd!' -o ./results

# Prompt for the password instead of putting it in your shell history
python3 powerhuntshares.py -d corp.local -u analyst -o ./results

# Pass the hash, explicit domain controller
python3 powerhuntshares.py -d corp.local -u analyst \
    -H aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0 \
    --dc 10.0.0.10 -o ./results

# Kerberos using an existing ticket cache
export KRB5CCNAME=/tmp/analyst.ccache
python3 powerhuntshares.py -d corp.local -u analyst -k -o ./results

# Scan a subnet or specific hosts instead of using LDAP discovery
python3 powerhuntshares.py -u analyst -p 'Passw0rd!' \
    --target 10.0.0.0/24 --target 10.1.5.20 -o ./results

# Scan a host list produced by another tool (nxc, nmap, ...).
# --target accepts a file path directly; --target-file also works.
python3 powerhuntshares.py -d corp.local -u analyst --dc 10.0.0.10 \
    --target ./smb_hosts.txt -o ./results

# Fast inventory only: no file walking, no credential parsing
python3 powerhuntshares.py -d corp.local -u analyst -p 'Passw0rd!' \
    -o ./results --no-files
```

### Options that matter most

| Flag | Effect |
|---|---|
| `-t, --threads` | Concurrent workers, default 20. Raise for large estates. |
| `-L, --dir-level` | Nested directory levels to walk, default 3. |
| `--max-files` | Ceiling on files recorded per share, default 50000. |
| `--no-files` | Skip walking, interesting files, and secret extraction. |
| `--no-secrets` | Walk and categorise files but never download them. |
| `--no-ping` | Skip liveness checks and go straight to port 445. |
| `--icmp` | Use real ICMP for liveness instead of TCP probes (may need root). |
| `--share-acls` | Also request share-level ACLs via srvsvc (usually needs admin). |
| `--keywords FILE` | Replace the built-in keyword table with your own CSV. |
| `--timeout` | Per-operation timeout, default 15s. Raise on slow links. |

Run `--help` for the full list.

---

## Output

Each run creates a timestamped directory:

```
results/SmbShareHunt-07292026093011/
├── corp.local-Summary-Report.html          <- start here
└── Results/
    ├── corp.local-Domain-Computers.csv
    ├── corp.local-Domain-Subnets.csv
    ├── corp.local-Shares-Inventory-All.csv
    ├── corp.local-Shares-Inventory-All-ACL.csv
    ├── corp.local-Shares-Inventory-Excessive-Privileges.csv
    ├── corp.local-Shares-Inventory-Excessive-Privileges-{Read,Write,HighRisk,NonDefault}.csv
    ├── corp.local-Shares-Inventory-Common-{Names,Owners,FileGroups}.csv
    ├── corp.local-Interesting-Files-All.csv
    ├── corp.local-Extracted-Secrets.csv
    └── corp.local-Shares-File-Listing.csv
```

CSV file names and column headers match the original module, so existing
parsing and import workflows keep working.

The HTML report is a single self-contained file — no CDN, no external fonts, no
network requests — with sortable, searchable, paginated tables, per-table CSV
export, and light/dark theming. Safe to hand to a client or open on an
air-gapped review machine.

To see what the report looks like without running a scan:

```bash
python3 tools/make_demo_report.py demo/
```

---

## How the analysis works

### What counts as an excessive privilege

An ACE is flagged when **all** of these hold:

- the principal is `Everyone`, `Authenticated Users`, `BUILTIN\Users`,
  `Domain Users`, or `Domain Computers`
- the ACE is `Allow`, not `Deny`
- the share was actually reachable during the scan
- the share is not `print$`, `prnproc$`, `*printer*`, `SYSVOL`, or `NETLOGON`

### Supplying your own target list

`--target` accepts a host, an IP, a CIDR, **or a path to a file** containing one
of those per line. `--target-file` does the same thing explicitly. Blank lines
and `#` comments are ignored.

A target list skips LDAP discovery — but if you also pass `--dc` (or `-d`), the
directory is still queried to enrich results with operating system data and the
real domain name. Targets given as bare IPs are matched to directory objects by
reverse DNS. Enrichment is best effort: if the domain controller is unreachable
the scan continues on the host list alone.

If nothing turns out to be reachable, the tool prints the likely cause —
unresolvable targets, a single-target list that should probably have been a
file, or filtered TCP 445 — rather than aborting silently.

### Risk scoring

Weights and bands are unchanged from upstream:

| Condition | Weight |
|---|---|
| Known high-risk share name (`c$`, `admin$`, `wwwroot`, `inetpub`, …) | +16 |
| Potential sensitive data present | +8 |
| Write access | +5 |
| Read access | +3 |
| Write access to a high-risk share (RCE) | +2 |
| Credential-bearing files present | +2 |
| More than 10 sensitive files | +1 |
| More than 10 credential files | +1 |
| Share is empty | −1 |
| Share is stale | −1 |

`≤4` Low · `5–10` Medium · `11–19` High · `≥20` Critical

---

## Differences from the Windows original

These are consequences of the platform, not choices — each is where a
Windows-only mechanism had no direct Linux equivalent.

**ACL retrieval.** `Get-Acl \\host\share` becomes an SMB2 `QUERY_INFO` of class
`SMB2_0_INFO_SECURITY` against the share root, opened with `READ_CONTROL`. Same
descriptor, different transport. Requires SMB2 or later. When the descriptor
cannot be read, the tool falls back to recording observed effective access
rather than dropping the share, and marks the row `AclSource=probe`. Share-level
ACLs via `NetrShareGetInfo` level 502 are available behind `--share-acls` but
usually need local admin.

**SID resolution.** No `System.Security.Principal` translation. A static table
covers every well-known SID and domain RID the analysis depends on; anything
else goes through LSAT against the target host. If the LSA pipe is unavailable,
unresolved SIDs are reported as SIDs rather than failing.

**Liveness.** Raw ICMP needs `CAP_NET_RAW` on Linux, so the default is a TCP
connect probe across 445/139/135/3389/22. `--icmp` uses the system `ping`.

**Threading.** Runspaces become a `ThreadPoolExecutor`. Per-item exceptions and
timeouts are swallowed exactly as `Invoke-Parallel` did, so one dead host cannot
abort a scan.

**HTML report.** Rewritten from scratch. The upstream report bundles Cytoscape,
ApexCharts and Dagre and ships ~1.8 MB of vendored JavaScript. This one is
dependency-free vanilla JS and CSS, covering the summary cards, risk and
category distributions, common-pattern panels, and all the data tables. The
Cytoscape network graph and ApexSankey diagram are **not** reproduced.

**Share-name library.** Upstream's static share-name-to-application table lives
inside the `.psm1`. The table in `powerhuntshares/analysis/sharenames.py` was
authored for this port rather than copied, and is deliberately conservative.

**Keyword additions.** The keyword table is a direct port with five additions
to the Sensitive category: `*payroll*`, `*salary*`, `*passport*`, `*invoice*`,
`*confidential*`. Everything else matches upstream. Use `--keywords` to supply
your own table and override the built-in list entirely.

**Not ported.** The LLM-assisted share description feature (`-ApiKey` /
`-Endpoint`) and the NOVA/Nessus export format conversion.

---

## Config file parsers

41 parsers, registered by name and dispatched from the keyword table:

.NET (`web.config`, `app.config`, `machine.config`) · Tomcat (`tomcat-users.xml`,
`server.xml`, `context.xml`) · IBM Liberty · JBoss/WildFly (`standalone.xml`,
`jboss-cli.xml`) · Jenkins · `shadow` · `htpasswd` · `.pgpass` · `.netrc` ·
`.fetchmailrc` · `.git-credentials` · `smb.conf` · `sssd.conf` · `krb5.conf` ·
`my.cnf` · `php.ini` · generic INI · `grub.cfg` · `pureftpd.passwd` ·
`WinSCP.ini` · `putty.reg` · `vnc.ini` · `.rdp` · FileZilla `SiteManager.xml` ·
DbVisualizer · Remmina · Group Policy Preferences · `unattend.xml` / `sysprep` ·
Cisco IOS configs · `tnsnames.ora` · SSIS `.dtsx` · `wp-config.php` ·
private keys and registry hives

Two decrypt rather than just extract:

- **Group Policy Preferences `cpassword`** — decrypted with the AES key
  Microsoft published in MS-GPPREF (MS14-025)
- **VNC passwords** — decrypted with the fixed DES key

WinSCP obfuscation is reversed. FileZilla and DbVisualizer base64 values are
decoded. DPAPI blobs (`.rdp`) and Jenkins secrets are reported as-is, since
those need material from the originating host.

---

## Testing

```bash
python3 -m unittest discover -s tests -v
```

108 tests covering the risk model against its documented thresholds, keyword
categorisation, all 41 parsers (including a fuzz pass that asserts none of them
raise on binary garbage), access-mask decoding, security descriptor parsing
against synthesised binary descriptors, SID resolution, CSV schema, and HTML
report generation.

---

## Operational notes

- **Scans are noisy.** Every share touched generates SMB session and file access
  events. Expect to be seen by EDR and file-access auditing.
- **`--no-secrets` still walks directories** but never downloads file contents.
  Use it where data handling rules prohibit pulling file bodies.
- **Extracted credentials land in cleartext** in
  `*-Extracted-Secrets.csv` and in the HTML report. Treat the output directory
  as sensitive material and clean it up when the engagement ends.
- **Only run this against systems you are authorised to test.**

---

## License

3-clause BSD, inherited from the upstream project. Original tool and analysis
methodology by Scott Sutherland (NetSPI).
