#!/usr/bin/env python3
"""Standalone launcher.

Lets the tool run straight from a clone without installing it:

    python3 powerhuntshares.py --help
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from powerhuntshares.cli import main

if __name__ == "__main__":
    sys.exit(main())
