#!/usr/bin/env python3
"""Generate a demo report from synthetic data.

Useful for reviewing report layout and for demonstrating the tool without
running a scan against a live environment. Produces no network traffic.

    python tools/make_demo_report.py demo/
"""

from __future__ import annotations

import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from powerhuntshares.analysis import interesting, risk
from powerhuntshares.analysis.keywords import DEFAULT_KEYWORDS
from powerhuntshares.analysis.sharenames import guess
from powerhuntshares.models import (
    Computer,
    ExtractedSecret,
    FileEntry,
    ScanResults,
    Share,
    ShareACL,
)
from powerhuntshares.report import csvout, html
from powerhuntshares.scanner import ScanConfig, _build_stats
from powerhuntshares.smbx.auth import Credentials

OPERATING_SYSTEMS = [
    "Windows Server 2019", "Windows Server 2022", "Windows Server 2016",
    "Windows 10 Pro", "Windows 11 Pro",
]
SHARE_NAMES = [
    "finance", "hr", "backup", "users", "software", "wwwroot", "c$", "admin$",
    "scans", "IT", "deploymentshare$", "profiles", "veeam", "sqlbackup", "dev", "public",
]
IDENTITIES = [
    "Everyone", "Authenticated Users", "BUILTIN\\Users", "CORP\\Domain Users",
    "BUILTIN\\Administrators", "NT AUTHORITY\\SYSTEM", "CORP\\Domain Admins",
]
RIGHTS = [
    "Read, Synchronize", "ReadAndExecute, Synchronize",
    "Modify, Write, Read", "FullControl", "Read", "GenericAll",
]
FILE_NAMES = [
    "payroll_2026.xlsx", "web.config", "id_rsa", "unattend.xml", "backup_2025.bak",
    "customers.sqlite", "deploy.ps1", "setup.exe", "hr_reviews.docx", "server.vhdx",
    "shadow", "my.cnf", "passwords.txt", "ssn_export.csv", "invoice_q1.pdf",
    "tomcat-users.xml", "Groups.xml", "archive.zip", "db_dump.sql",
    "confidential_merger.pptx", "krb5.conf", "vnc.ini", "logo.png", "banner.jpg",
]
OWNERS = [
    "BUILTIN\\Administrators", "NT AUTHORITY\\SYSTEM",
    "CORP\\svc_backup", "CORP\\jsmith",
]
PASSWORDS = [
    "Sup3rS3cret!", "Summer2026!", "P@ssw0rd123",
    "svc-b4ckup-99", "MyAwesomePassword!", "Local*P4ssword!",
]


def build(seed: int = 7) -> ScanResults:
    random.seed(seed)
    results = ScanResults(target_domain="corp.local")
    results.start_time = "07/29/2026 09:00:00"
    results.end_time = "07/29/2026 10:47:31"
    results.run_time = "1:47:31"

    for index in range(1, 61):
        results.computers.append(
            Computer(
                ComputerName=f"host{index:02d}.corp.local",
                OperatingSystem=random.choice(OPERATING_SYSTEMS),
                IpAddress=f"10.0.{index // 254}.{index % 254}",
                Pingable=index <= 44,
                Port445Open=index <= 38,
            )
        )
    results.computers_pingable = [c for c in results.computers if c.Pingable]
    results.computers_445 = [c for c in results.computers if c.Port445Open]

    for computer in results.computers_445:
        for name in random.sample(SHARE_NAMES, random.randint(2, 6)):
            results.shares.append(
                Share(
                    ComputerName=computer.ComputerName,
                    IpAddress=computer.IpAddress,
                    ShareName=name,
                    SharePath=f"\\\\{computer.ComputerName}\\{name}",
                    ShareType="Disk",
                    ShareAccess="Yes" if random.random() > 0.18 else "No",
                    ShareDesc=random.choice(["", "Department share", "Auto-created", "Deployment"]),
                )
            )
        results.shares.append(
            Share(
                ComputerName=computer.ComputerName,
                ShareName="IPC$",
                SharePath=f"\\\\{computer.ComputerName}\\IPC$",
                ShareType="IPC",
                ShareAccess="No",
            )
        )

    for share in results.shares:
        if share.ShareAccess != "Yes":
            continue
        for identity in random.sample(IDENTITIES, random.randint(1, 4)):
            year = random.choice(["2021", "2023", "2024", "2025", "2026"])
            results.acls.append(
                ShareACL(
                    ComputerName=share.ComputerName,
                    IpAddress=share.IpAddress,
                    ShareName=share.ShareName,
                    SharePath=share.SharePath,
                    ShareDescription=share.ShareDesc,
                    ShareType="Disk",
                    ShareAccess="Yes",
                    ShareOwner=random.choice(OWNERS),
                    FileSystemRights=random.choice(RIGHTS),
                    IdentityReference=identity,
                    IdentitySID="S-1-1-0",
                    AccessControlType="Deny" if random.random() > 0.94 else "Allow",
                    CreationDate=f"03/14/{year} 08:12:00",
                    CreationDateYear=year,
                    LastModifiedDate=f"0{random.randint(1, 9)}/1{random.randint(0, 9)}/{year} 14:03:00",
                    LastModifiedDateYear=year,
                    LastAccessDate=f"07/2{random.randint(0, 8)}/2026 09:00:00",
                    LastAccessDateYear="2026",
                    FileCount=random.randint(0, 240),
                    FileListGroup=random.choice(["g1", "g2", "g3", "g4", "g5"]),
                    AclSource="ntfs",
                )
            )

    seen = set()
    for acl in results.acls:
        key = (acl.ComputerName, acl.ShareName)
        if key in seen:
            continue
        seen.add(key)
        for name in random.sample(FILE_NAMES, random.randint(0, 9)):
            results.files.append(
                FileEntry(
                    ComputerName=acl.ComputerName,
                    ShareName=acl.ShareName,
                    SharePath=acl.SharePath,
                    FilePath=f"{acl.SharePath}\\data\\{name}",
                    FileName=name,
                    FileSize=random.randint(900, 900_000_000),
                    LastModified=f"0{random.randint(1, 9)}/15/2026 10:00:00",
                    Depth=1,
                )
            )

    results.interesting_files = interesting.find_interesting(results.files, DEFAULT_KEYWORDS)

    secrets_source = [f for f in results.interesting_files if f.Category == "Secret"][:34]
    for item in secrets_source:
        results.secrets.append(
            ExtractedSecret(
                ComputerName=item.ComputerName,
                ShareName=item.ShareName,
                UncPath=item.UncPath,
                FileName=item.FileName,
                Parser=random.choice(["web_config", "gpp", "shadow", "my_cnf", "private_key"]),
                Name=random.choice(
                    ["SQL Connection", "Group Policy Preferences", "Local Account", "MySQL"]
                ),
                Section=random.choice(["ConnectionStrings", "Groups", "shadow", "client"]),
                Server=f"sql0{random.randint(1, 4)}",
                Port="1433",
                UserName=random.choice(["sa", "svc_deploy", "root", "appuser", "CORP\\svc_sql"]),
                Password=random.choice(PASSWORDS),
                Notes=random.choice(
                    [
                        "Cleartext credential",
                        "Decrypted with the published MS14-025 AES key",
                        "SHA-512crypt hash - crackable offline",
                    ]
                ),
            )
        )

    excessive = risk.find_excessive(results.acls)
    guesses = {a.ShareName.lower(): guess(a.ShareName) for a in excessive}
    results.excessive = risk.enrich(
        excessive, results.interesting_files, results.computers, share_guesses=guesses
    )
    results.stats = _build_stats(results, ScanConfig(output_dir="", creds=Credentials()))
    return results


def main() -> int:
    out_dir = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "demo")
    os.makedirs(out_dir, exist_ok=True)

    results = build()
    html.build(results, os.path.join(out_dir, "corp.local-Summary-Report.html"))
    csvout.export_all(results, out_dir)

    print(
        f"computers={len(results.computers)} shares={len(results.shares)} "
        f"acls={len(results.acls)} excessive={len(results.excessive)}"
    )
    print(
        f"files={len(results.files)} interesting={len(results.interesting_files)} "
        f"secrets={len(results.secrets)}"
    )
    print("risk levels:", results.stats["risk_counts"])
    print("categories :", results.stats["category_counts"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
