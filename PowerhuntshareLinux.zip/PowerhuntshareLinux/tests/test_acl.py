"""Tests for access mask decoding and security descriptor parsing.

Requires impacket. The whole module is skipped when it is not installed so the
rest of the suite still runs.
"""

from __future__ import annotations

import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from impacket.ldap import ldaptypes

    HAVE_IMPACKET = True
except ImportError:  # pragma: no cover
    HAVE_IMPACKET = False


@unittest.skipUnless(HAVE_IMPACKET, "impacket not installed")
class TestMaskDecoding(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.smbx import acl

        self.acl = acl

    def test_full_control(self):
        self.assertEqual(self.acl.mask_to_rights(0x001F01FF), "FullControl")

    def test_generic_all(self):
        self.assertIn("GenericAll", self.acl.mask_to_rights(0x10000000))

    def test_read_composite(self):
        rights = self.acl.mask_to_rights(0x00020089)
        self.assertEqual(rights, "Read")
        self.assertTrue(self.acl.has_read(rights))
        self.assertFalse(self.acl.has_write(rights))

    def test_write_composite(self):
        rights = self.acl.mask_to_rights(0x00000116)
        self.assertEqual(rights, "Write")
        self.assertTrue(self.acl.has_write(rights))

    def test_modify_composite(self):
        self.assertEqual(self.acl.mask_to_rights(0x000301BF), "Modify")

    def test_read_and_execute(self):
        self.assertEqual(self.acl.mask_to_rights(0x000200A9), "ReadAndExecute")

    def test_individual_bits_appended(self):
        # ReadAndExecute plus Delete
        rights = self.acl.mask_to_rights(0x000200A9 | 0x00010000)
        self.assertIn("ReadAndExecute", rights)
        self.assertIn("Delete", rights)

    def test_zero_mask(self):
        self.assertEqual(self.acl.mask_to_rights(0), "")

    def test_unknown_bits_render_as_hex(self):
        rights = self.acl.mask_to_rights(0x00000800)
        self.assertTrue(rights.startswith("0x") or rights == "")

    def test_read_write_helpers_match_upstream_semantics(self):
        # The upstream module matches on substrings; these are the exact
        # strings its filters were written against.
        self.assertTrue(self.acl.has_read("ReadAndExecute, Synchronize"))
        self.assertTrue(self.acl.has_write("GenericAll"))
        self.assertTrue(self.acl.has_write("CreateFiles, AppendData"))
        self.assertFalse(self.acl.has_write("ListDirectory, ReadAttributes"))


def _make_sid(text: str) -> bytes:
    sid = ldaptypes.LDAP_SID()
    sid.fromCanonical(text)
    return sid.getData()


def _make_ace(sid_text: str, mask: int, ace_type: int = 0x00) -> bytes:
    """Build a minimal ACCESS_ALLOWED_ACE / ACCESS_DENIED_ACE blob."""
    sid = _make_sid(sid_text)
    body = struct.pack("<I", mask) + sid
    size = 4 + len(body)
    return struct.pack("<BBH", ace_type, 0x00, size) + body


def _make_descriptor(aces: list, owner: str = "S-1-5-32-544") -> bytes:
    """Assemble a self-relative security descriptor around ``aces``."""
    ace_blob = b"".join(aces)
    acl_size = 8 + len(ace_blob)
    dacl = struct.pack("<BBHHH", 2, 0, acl_size, len(aces), 0) + ace_blob
    owner_sid = _make_sid(owner)
    group_sid = _make_sid("S-1-5-32-545")

    header_len = 20
    offset_owner = header_len
    offset_group = offset_owner + len(owner_sid)
    offset_dacl = offset_group + len(group_sid)

    header = struct.pack(
        "<BBHIIII",
        1,            # Revision
        0,            # Sbz1
        0x8004,       # Control: SE_DACL_PRESENT | SE_SELF_RELATIVE
        offset_owner,
        offset_group,
        0,            # OffsetSacl - none
        offset_dacl,
    )
    return header + owner_sid + group_sid + dacl


@unittest.skipUnless(HAVE_IMPACKET, "impacket not installed")
class TestDescriptorParsing(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.smbx import acl

        self.acl = acl

    def test_parses_owner_and_allowed_ace(self):
        blob = _make_descriptor([_make_ace("S-1-1-0", 0x001F01FF)])
        info = self.acl.parse_descriptor(blob)

        self.assertIsNotNone(info)
        self.assertEqual(info.owner_sid, "S-1-5-32-544")
        self.assertEqual(len(info.aces), 1)
        self.assertEqual(info.aces[0].sid, "S-1-1-0")
        self.assertEqual(info.aces[0].rights, "FullControl")
        self.assertEqual(info.aces[0].ace_type, "Allow")

    def test_separates_allow_and_deny(self):
        blob = _make_descriptor([
            _make_ace("S-1-1-0", 0x00020089, ace_type=0x00),
            _make_ace("S-1-5-11", 0x001F01FF, ace_type=0x01),
        ])
        info = self.acl.parse_descriptor(blob)
        self.assertEqual(len(info.aces), 2)
        kinds = {a.sid: a.ace_type for a in info.aces}
        self.assertEqual(kinds["S-1-1-0"], "Allow")
        self.assertEqual(kinds["S-1-5-11"], "Deny")

    def test_empty_blob_returns_none(self):
        self.assertIsNone(self.acl.parse_descriptor(b""))

    def test_garbage_blob_returns_none_or_empty(self):
        result = self.acl.parse_descriptor(b"\x01\x00\x04\x80" + b"\xff" * 40)
        if result is not None:
            self.assertIsInstance(result.aces, list)


@unittest.skipUnless(HAVE_IMPACKET, "impacket not installed")
class TestSidResolution(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.smbx import sids

        self.sids = sids

    def test_well_known_sids_resolve_offline(self):
        cases = {
            "S-1-1-0": "Everyone",
            "S-1-5-11": "Authenticated Users",
            "S-1-5-32-545": "BUILTIN\\Users",
            "S-1-5-32-544": "BUILTIN\\Administrators",
            "S-1-5-18": "NT AUTHORITY\\SYSTEM",
        }
        for sid, expected in cases.items():
            self.assertEqual(self.sids.resolve_static(sid), expected)

    def test_domain_rids_resolve_with_netbios_prefix(self):
        domain_sid = "S-1-5-21-1111111111-2222222222-3333333333"
        self.assertEqual(
            self.sids.resolve_static(f"{domain_sid}-513", "CORP"), "CORP\\Domain Users"
        )
        self.assertEqual(
            self.sids.resolve_static(f"{domain_sid}-512", "CORP"), "CORP\\Domain Admins"
        )

    def test_resolved_domain_users_counts_as_excessive(self):
        from powerhuntshares.analysis.risk import is_excessive_identity

        name = self.sids.resolve_static(
            "S-1-5-21-1-2-3-513", "CORP"
        )
        self.assertTrue(is_excessive_identity(name))

    def test_unknown_sid_returns_none(self):
        self.assertIsNone(self.sids.resolve_static("S-1-5-21-1-2-3-9999"))

    def test_resolver_without_connection_falls_back_to_static(self):
        resolver = self.sids.SidResolver(conn=None, domain_netbios="CORP")
        self.assertEqual(resolver.resolve("S-1-1-0"), "Everyone")
        # Unresolvable SIDs come back as the SID itself, never an exception.
        self.assertEqual(resolver.resolve("S-1-5-21-9-9-9-4242"), "S-1-5-21-9-9-9-4242")

    def test_resolve_many_batches(self):
        resolver = self.sids.SidResolver(conn=None, domain_netbios="CORP")
        out = resolver.resolve_many(["S-1-1-0", "S-1-5-11", "S-1-5-32-545"])
        self.assertEqual(out["S-1-1-0"], "Everyone")
        self.assertEqual(out["S-1-5-11"], "Authenticated Users")


@unittest.skipUnless(HAVE_IMPACKET, "impacket not installed")
class TestShareHelpers(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.smbx import files, shares

        self.shares = shares
        self.files = files

    def test_share_type_names(self):
        self.assertEqual(self.shares.share_type_name(0), "Disk")
        self.assertEqual(self.shares.share_type_name(1), "Printer")
        self.assertEqual(self.shares.share_type_name(3), "IPC")
        self.assertIn("Special", self.shares.share_type_name(0x80000000))

    def test_rel_path_from_unc(self):
        self.assertEqual(
            self.files.rel_path_from_unc("\\\\srv01\\finance\\2026\\q1.xlsx", "finance"),
            "2026\\q1.xlsx",
        )
        self.assertEqual(
            self.files.rel_path_from_unc("\\\\srv01\\finance\\notes.txt", "finance"),
            "notes.txt",
        )

    def test_non_walkable_shares_listed(self):
        self.assertIn("ipc$", self.shares.NON_WALKABLE)
        self.assertIn("print$", self.shares.NON_WALKABLE)


class TestTargetExpansion(unittest.TestCase):
    def test_cidr_expands_to_hosts(self):
        from powerhuntshares.discovery.portscan import expand_targets

        hosts = expand_targets(["10.0.0.0/30"])
        self.assertEqual(hosts, ["10.0.0.1", "10.0.0.2"])

    def test_hostnames_pass_through_and_dedupe(self):
        from powerhuntshares.discovery.portscan import expand_targets

        hosts = expand_targets(["srv01", "SRV01", "# comment", "", "srv02"])
        self.assertEqual(hosts, ["srv01", "srv02"])

    def test_oversized_range_skipped(self):
        from powerhuntshares.discovery.portscan import expand_targets

        self.assertEqual(expand_targets(["10.0.0.0/8"]), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
