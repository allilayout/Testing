"""Tests for the config file credential parsers."""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from powerhuntshares.parsers import available, run
from powerhuntshares.parsers.base import (
    is_boolean,
    is_placeholder,
    strip_inline_comment,
)
from powerhuntshares.parsers.configs import decrypt_cpassword


def passwords(findings) -> set:
    return {f.password for f in findings}


def users(findings) -> set:
    return {f.username for f in findings if f.username}


class TestRegistry(unittest.TestCase):
    def test_expected_parsers_registered(self):
        names = set(available())
        for expected in (
            "web_config", "app_config", "machine_config", "tomcat_users",
            "server_xml", "context_xml", "standalone_xml", "jboss_cli",
            "jenkins_config", "shadow", "htpasswd", "pgpass", "netrc",
            "fetchmailrc", "git_credentials", "smb_conf", "sssd_conf",
            "krb5_conf", "my_cnf", "php_ini", "ini_file", "grub_config",
            "pureftpd_passwd", "winscp_ini", "putty_reg", "vnc_ini",
            "rdp_file", "sitemanager_xml", "dbvis_xml", "remmina",
            "remmina_pref", "gpp", "unattend", "sysprep", "cisco_config",
            "tnsnames_ora", "ssis_dtsx", "wp_config", "private_key",
        ):
            self.assertIn(expected, names, f"{expected} parser missing")

    def test_unknown_parser_returns_empty(self):
        self.assertEqual(run("no_such_parser", b"data"), [])

    def test_empty_input_returns_empty(self):
        self.assertEqual(run("shadow", b""), [])

    def test_garbage_never_raises(self):
        garbage = bytes(range(256)) * 8
        for name in available():
            try:
                run(name, garbage)
            except Exception as exc:  # noqa: BLE001
                self.fail(f"{name} raised on garbage input: {exc}")


class TestHelpers(unittest.TestCase):
    def test_inline_comments_stripped(self):
        self.assertEqual(strip_inline_comment("secret123  ; a comment"), "secret123")
        self.assertEqual(strip_inline_comment("value <!-- note -->"), "value")
        self.assertEqual(strip_inline_comment("plain"), "plain")

    def test_hash_inside_password_preserved(self):
        # A '#' with no leading whitespace is part of the password.
        self.assertEqual(strip_inline_comment("P@ss#word"), "P@ss#word")

    def test_weak_real_passwords_are_not_placeholders(self):
        for value in ("password", "changeme", "admin", "Passw0rd"):
            self.assertFalse(is_placeholder(value), value)

    def test_template_markers_are_placeholders(self):
        for value in ("<password>", "%password%", "", "null", "N/A"):
            self.assertTrue(is_placeholder(value), value)

    def test_booleans_and_short_numbers_filtered(self):
        for value in ("yes", "TRUE", "off", "2", "100"):
            self.assertTrue(is_boolean(value), value)
        self.assertFalse(is_boolean("123456"))  # plausible numeric password
        self.assertFalse(is_boolean("hunter2"))


class TestUnixParsers(unittest.TestCase):
    def test_shadow_keeps_only_real_hashes(self):
        data = (
            b"root:$6$salt$hashvalue1234:19000:0:99999:7:::\n"
            b"daemon:*:19000:0:99999:7:::\n"
            b"locked:!!:19000:0:99999:7:::\n"
            b"bob:$y$j9T$salt$yescrypthash:19000:0:99999:7:::\n"
        )
        found = run("shadow", data)
        self.assertEqual(users(found), {"root", "bob"})
        self.assertIn("SHA-512crypt", found[0].notes)
        self.assertIn("yescrypt", found[1].notes)

    def test_htpasswd_identifies_hash_type(self):
        data = b"admin:$apr1$abc$def\nbob:{SHA}aGVsbG8=\ncarol:$2y$10$xyz\n"
        found = run("htpasswd", data)
        self.assertEqual(users(found), {"admin", "bob", "carol"})
        self.assertIn("APR1", found[0].notes)
        self.assertIn("bcrypt", found[2].notes)

    def test_pgpass_fields(self):
        found = run("pgpass", b"dbhost:5432:appdb:appuser:S3cr3t!\n# comment\n")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].server, "dbhost")
        self.assertEqual(found[0].port, "5432")
        self.assertEqual(found[0].username, "appuser")
        self.assertEqual(found[0].password, "S3cr3t!")

    def test_pgpass_password_containing_colons(self):
        found = run("pgpass", b"h:5432:db:user:pa:ss:word\n")
        self.assertEqual(found[0].password, "pa:ss:word")

    def test_netrc_multiple_machines(self):
        data = (
            b"machine git.corp.local login jsmith password gitpass\n"
            b"machine ftp.corp.local login ftpuser password ftppass\n"
        )
        found = run("netrc", data)
        self.assertEqual(passwords(found), {"gitpass", "ftppass"})

    def test_git_credentials_url_decoded(self):
        found = run("git_credentials", b"https://jsmith:gh%40token@github.com\n")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].username, "jsmith")
        self.assertEqual(found[0].password, "gh@token")
        self.assertEqual(found[0].server, "github.com")

    def test_grub_ignores_comments(self):
        data = b"# password admin fake\nset x=1\npassword_pbkdf2 root grub.pbkdf2.sha512.10000.AB\n"
        found = run("grub_config", data)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].username, "root")
        self.assertIn("PBKDF2", found[0].notes)


class TestXmlParsers(unittest.TestCase):
    def test_dotnet_connection_string(self):
        data = b"""<?xml version="1.0"?>
        <configuration><connectionStrings>
          <add name="Main" connectionString="Data Source=sql01,1433;Initial Catalog=app;User ID=sa;Password=Sup3rS3cret;"
               providerName="System.Data.SqlClient" />
        </connectionStrings></configuration>"""
        found = run("web_config", data)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].username, "sa")
        self.assertEqual(found[0].password, "Sup3rS3cret")
        self.assertEqual(found[0].server, "sql01")
        self.assertEqual(found[0].port, "1433")

    def test_dotnet_forms_credentials(self):
        data = b"""<configuration><system.web><authentication mode="Forms"><forms>
          <credentials passwordFormat="Clear">
            <user name="admin" password="letmein"/>
          </credentials></forms></authentication></system.web></configuration>"""
        found = run("web_config", data)
        self.assertIn("letmein", passwords(found))

    def test_tomcat_users(self):
        data = b"""<tomcat-users>
          <user username="tomcat" password="tomcat" roles="manager-gui"/>
          <user username="nopass" roles="reader"/>
        </tomcat-users>"""
        found = run("tomcat_users", data)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].username, "tomcat")

    def test_liberty_server_xml(self):
        data = b"""<server>
          <keyStore id="defaultKeyStore" password="ksPassw0rd"/>
          <basicRegistry><user name="adminuser" password="adminpwd"/></basicRegistry>
        </server>"""
        found = run("server_xml", data)
        self.assertEqual(passwords(found), {"ksPassw0rd", "adminpwd"})

    def test_tomcat_jndi_resource(self):
        data = b"""<Context><Resource name="jdbc/app" username="dbuser"
          password="dbpass" url="jdbc:mysql://db01/app"
          driverClassName="com.mysql.jdbc.Driver"/></Context>"""
        found = run("context_xml", data)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].username, "dbuser")
        self.assertEqual(found[0].url, "jdbc:mysql://db01/app")

    def test_jboss_sibling_elements(self):
        data = b"""<jboss-cli><authentication>
          <username>admin</username><password>mgmtpass</password>
        </authentication></jboss-cli>"""
        found = run("jboss_cli", data)
        self.assertIn("mgmtpass", passwords(found))
        self.assertIn("admin", users(found))

    def test_filezilla_base64(self):
        # "HelloPassword" base64 encoded
        data = b"""<FileZilla3><Servers><Server>
          <Host>ftp.corp.local</Host><Port>21</Port>
          <User>ftpuser</User><Pass>SGVsbG9QYXNzd29yZA==</Pass>
          <Name>Prod FTP</Name></Server></Servers></FileZilla3>"""
        found = run("sitemanager_xml", data)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].password, "HelloPassword")

    def test_malformed_xml_falls_back_gracefully(self):
        found = run("web_config", b"<configuration><unclosed>password=oops")
        self.assertIsInstance(found, list)


class TestGpp(unittest.TestCase):
    KNOWN_CPASSWORD = (
        "j1Uyj3Vx8TY9LtLZil2uAuZkFQA/4latT76ZwgdHdhw"
    )

    def test_cpassword_decrypts(self):
        try:
            import Crypto  # noqa: F401
        except ImportError:
            self.skipTest("pycryptodome not installed")
        self.assertEqual(decrypt_cpassword(self.KNOWN_CPASSWORD), "Local*P4ssword!")

    def test_gpp_xml_extracts_username_and_password(self):
        data = f"""<?xml version="1.0" encoding="utf-8"?>
        <Groups><User name="admin"><Properties action="U" newName=""
          cpassword="{self.KNOWN_CPASSWORD}" userName="corp\\svc_deploy"/></User></Groups>
        """.encode()
        found = run("gpp", data)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].username, "corp\\svc_deploy")

    def test_invalid_cpassword_returns_empty(self):
        self.assertEqual(decrypt_cpassword("!!!not-base64!!!"), "")
        self.assertEqual(decrypt_cpassword(""), "")


class TestWindowsParsers(unittest.TestCase):
    def test_unattend_cleartext(self):
        data = b"""<unattend><UserAccounts><AdministratorPassword>
          <Value>Cl34rT3xt!</Value><PlainText>true</PlainText>
        </AdministratorPassword></UserAccounts></unattend>"""
        found = run("unattend", data)
        self.assertIn("Cl34rT3xt!", passwords(found))
        self.assertIn("Cleartext", found[0].notes)

    def test_unattend_base64_utf16(self):
        import base64

        blob = base64.b64encode("Secret1!AdministratorPassword".encode("utf-16-le")).decode()
        data = f"""<unattend><UserAccounts><AdministratorPassword>
          <Value>{blob}</Value><PlainText>false</PlainText>
        </AdministratorPassword></UserAccounts></unattend>""".encode()
        found = run("unattend", data)
        self.assertIn("Secret1!", passwords(found))

    def test_cisco_password_types(self):
        data = (
            b"hostname edge-rtr-01\n"
            b"enable secret 5 $1$abc$defghijk\n"
            b"username netadmin privilege 15 password 7 070C285F4D06\n"
            b"snmp-server community publicstring RO\n"
        )
        found = run("cisco_config", data)
        self.assertEqual(len(found), 3)
        self.assertTrue(any("MD5crypt" in f.notes for f in found))
        self.assertTrue(any("Vigenere" in f.notes for f in found))
        self.assertTrue(all(f.server == "edge-rtr-01" for f in found))

    def test_wp_config(self):
        data = (
            b"<?php\n"
            b"define('DB_NAME', 'wordpress');\n"
            b"define('DB_USER', 'wpuser');\n"
            b"define('DB_PASSWORD', 'wpP@ss');\n"
            b"define('DB_HOST', 'db01');\n"
            b"define('AUTH_KEY', 'random-salt-value');\n"
        )
        found = run("wp_config", data)
        self.assertIn("wpP@ss", passwords(found))
        self.assertIn("random-salt-value", passwords(found))

    def test_private_key_detection(self):
        unencrypted = b"-----BEGIN RSA PRIVATE KEY-----\nMIIEow...\n-----END RSA PRIVATE KEY-----\n"
        found = run("private_key", unencrypted)
        self.assertEqual(len(found), 1)
        self.assertIn("Unencrypted", found[0].notes)

        encrypted = (
            b"-----BEGIN RSA PRIVATE KEY-----\n"
            b"Proc-Type: 4,ENCRYPTED\nDEK-Info: AES-128-CBC,ABC\n\nMIIE...\n"
        )
        self.assertIn("Passphrase", run("private_key", encrypted)[0].notes)

    def test_registry_hive_detected(self):
        found = run("private_key", b"regf" + b"\x00" * 100)
        self.assertEqual(len(found), 1)
        self.assertIn("hive", found[0].name.lower())

    def test_ssis_connection_strings(self):
        data = (
            b'<DTS:Executable><DTS:Property DTS:Name="ConnectionString">'
            b"Data Source=sql02;Initial Catalog=Stage;User ID=etl;Password=EtlP@ss;"
            b"</DTS:Property></DTS:Executable>"
        )
        found = run("ssis_dtsx", data)
        self.assertIn("EtlP@ss", passwords(found))


class TestIniParsers(unittest.TestCase):
    def test_my_cnf(self):
        data = b"[client]\nuser=appuser\npassword=my-db-pass\nport=3306\n"
        found = run("my_cnf", data)
        self.assertIn("my-db-pass", passwords(found))
        self.assertIn("appuser", users(found))

    def test_boolean_settings_not_reported(self):
        data = b"[global]\nencrypt passwords = yes\nnull passwords = no\n"
        self.assertEqual(run("smb_conf", data), [])

    def test_hostname_valued_keys_not_reported(self):
        data = b"[domain/corp]\nkrb5_kpasswd = kdc.corp.local\n"
        self.assertEqual(run("sssd_conf", data), [])

    def test_real_secret_still_found_alongside_noise(self):
        data = (
            b"[domain/corp]\n"
            b"krb5_kpasswd = kdc.corp.local\n"
            b"offline_credentials_expiration = 2\n"
            b"ldap_default_bind_dn = cn=svc,dc=corp\n"
            b"ldap_default_authtok = B1ndP@ss\n"
        )
        found = run("sssd_conf", data)
        self.assertEqual(passwords(found), {"B1ndP@ss"})
        self.assertIn("cn=svc,dc=corp", users(found))


if __name__ == "__main__":
    unittest.main(verbosity=2)
