"""Tests for keyword matching, excessive privilege detection, and risk scoring.

These verify the ported logic against the thresholds documented in the original
PowerShell module, so a regression in the scoring model is caught immediately.
"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from powerhuntshares.analysis import interesting, risk
from powerhuntshares.analysis.keywords import DEFAULT_KEYWORDS, load_keywords
from powerhuntshares.analysis.sharenames import guess
from powerhuntshares.models import Computer, FileEntry, InterestingFile, ShareACL
from powerhuntshares.util import like, md5_of_filelist, percent_str


def acl(**kwargs) -> ShareACL:
    base = dict(
        ComputerName="srv01.corp.local",
        ShareName="finance",
        SharePath="\\\\srv01.corp.local\\finance",
        IdentityReference="Everyone",
        FileSystemRights="Read, Synchronize",
        AccessControlType="Allow",
        ShareAccess="Yes",
        FileCount=12,
        LastModifiedDate="01/15/2026 09:00:00",
    )
    base.update(kwargs)
    return ShareACL(**base)


class TestExcessiveIdentities(unittest.TestCase):
    def test_broad_groups_are_excessive(self):
        for identity in (
            "Everyone",
            "BUILTIN\\Users",
            "Authenticated Users",
            "CORP\\Domain Users",
            "CORP\\Domain Computers",
        ):
            self.assertTrue(
                risk.is_excessive_identity(identity), f"{identity} should be excessive"
            )

    def test_specific_principals_are_not_excessive(self):
        for identity in (
            "BUILTIN\\Administrators",
            "NT AUTHORITY\\SYSTEM",
            "CORP\\Domain Admins",
            "CORP\\jsmith",
            "CREATOR OWNER",
        ):
            self.assertFalse(
                risk.is_excessive_identity(identity), f"{identity} should not be excessive"
            )

    def test_deny_aces_are_excluded(self):
        rows = risk.find_excessive([acl(AccessControlType="Deny")])
        self.assertEqual(rows, [])

    def test_unreachable_shares_are_excluded(self):
        rows = risk.find_excessive([acl(ShareAccess="No")])
        self.assertEqual(rows, [])

    def test_printer_and_policy_shares_are_excluded(self):
        for name in ("print$", "SYSVOL", "NETLOGON", "prnproc$", "HPprinter"):
            rows = risk.find_excessive([acl(ShareName=name)])
            self.assertEqual(rows, [], f"{name} should be excluded")

    def test_ordinary_share_is_kept(self):
        rows = risk.find_excessive([acl()])
        self.assertEqual(len(rows), 1)


class TestRightsMatching(unittest.TestCase):
    def test_read_detection(self):
        self.assertTrue(risk.has_read("Read, Synchronize"))
        self.assertTrue(risk.has_read("ReadAndExecute"))
        self.assertTrue(risk.has_read("GenericRead"))
        self.assertFalse(risk.has_read("Write, AppendData"))

    def test_write_detection(self):
        for rights in ("GenericAll", "FullControl", "Modify", "Write",
                       "CreateFiles", "AppendData", "Delete"):
            self.assertTrue(risk.has_write(rights), rights)
        self.assertFalse(risk.has_write("Read, Synchronize"))
        self.assertFalse(risk.has_write("ListDirectory, ReadAttributes"))

    def test_high_risk_share_names(self):
        for name in ("C$", "ADMIN$", "wwwroot", "c_share", "inetpub_backup"):
            self.assertTrue(risk.is_high_risk(name), name)
        self.assertFalse(risk.is_high_risk("finance"))
        self.assertFalse(risk.is_high_risk("d$"))


class TestRiskScoring(unittest.TestCase):
    """Weights: RCE 2, HighRisk 16, Data 8, Secrets 2, Write 5, Read 3,
    Empty -1, Stale -1. Bands: <=4 Low, 5-10 Medium, 11-19 High, >=20 Critical."""

    def test_read_only_ordinary_share_is_low(self):
        flags = risk.score(acl())
        self.assertEqual(flags["RiskScore"], 3)  # read only
        self.assertEqual(risk.risk_level(flags["RiskScore"]), "Low")

    def test_read_write_is_medium(self):
        flags = risk.score(acl(FileSystemRights="Modify, Write, Read"))
        self.assertEqual(flags["RiskScore"], 8)  # read 3 + write 5
        self.assertEqual(risk.risk_level(flags["RiskScore"]), "Medium")

    def test_sensitive_data_pushes_to_high(self):
        flags = risk.score(acl(FileSystemRights="Read"), sensitive_count=3)
        self.assertEqual(flags["RiskScore"], 11)  # read 3 + data 8
        self.assertEqual(risk.risk_level(flags["RiskScore"]), "High")

    def test_admin_share_with_write_is_critical(self):
        flags = risk.score(acl(ShareName="c$", FileSystemRights="FullControl, Read"))
        # read 3 + write 5 + high risk 16 + rce 2 = 26
        self.assertEqual(flags["RiskScore"], 26)
        self.assertEqual(flags["HasRCE"], 1)
        self.assertEqual(risk.risk_level(flags["RiskScore"]), "Critical")

    def test_volume_bonuses(self):
        low = risk.score(acl(FileSystemRights="Read"), secret_count=5, sensitive_count=5)
        high = risk.score(acl(FileSystemRights="Read"), secret_count=50, sensitive_count=50)
        # Both get the base data+secret weights; only the larger adds the two
        # volume bonuses.
        self.assertEqual(high["RiskScore"] - low["RiskScore"], 2)

    def test_empty_and_stale_reduce_score(self):
        flags = risk.score(
            acl(FileSystemRights="Read", FileCount=0, LastModifiedDate="01/01/2015 00:00:00")
        )
        self.assertEqual(flags["IsEmpty"], 1)
        self.assertEqual(flags["IsStale"], 1)
        self.assertEqual(flags["RiskScore"], 1)  # 3 - 1 - 1

    def test_score_never_goes_negative(self):
        flags = risk.score(
            acl(FileSystemRights="", FileCount=0, LastModifiedDate="01/01/2010 00:00:00")
        )
        self.assertGreaterEqual(flags["RiskScore"], 0)

    def test_band_boundaries(self):
        self.assertEqual(risk.risk_level(4), "Low")
        self.assertEqual(risk.risk_level(5), "Medium")
        self.assertEqual(risk.risk_level(10), "Medium")
        self.assertEqual(risk.risk_level(11), "High")
        self.assertEqual(risk.risk_level(19), "High")
        self.assertEqual(risk.risk_level(20), "Critical")

    def test_unparseable_date_is_not_stale(self):
        flags = risk.score(acl(LastModifiedDate=""))
        self.assertEqual(flags["IsStale"], 0)


class TestEnrichment(unittest.TestCase):
    def test_enrich_joins_files_computers_and_guesses(self):
        rows = [acl(ShareName="backup", SharePath="\\\\srv01\\backup")]
        files = [
            InterestingFile(SharePath="\\\\srv01\\backup", Category="Secret", FileName="id_rsa"),
            InterestingFile(SharePath="\\\\srv01\\backup", Category="Sensitive", FileName="hr.xlsx"),
        ]
        computers = [Computer(ComputerName="srv01.corp.local", OperatingSystem="Windows Server 2019")]

        final = risk.enrich(rows, files, computers, share_guesses={"backup": guess("backup")})
        self.assertEqual(len(final), 1)
        row = final[0]
        self.assertEqual(row.ComputerOS, "Windows Server 2019")
        self.assertEqual(row.SecretFileCount, 1)
        self.assertEqual(row.SensitiveFileCount, 1)
        self.assertEqual(row.InterestingFileCount, 2)
        self.assertEqual(row.HasSecrets, 1)
        self.assertEqual(row.HasIF, 1)
        self.assertIn("Backup", row.ShareDescriptionGuess)
        self.assertEqual(row.RiskLevel, "High")  # read 3 + data 8 + secrets 2 = 13

    def test_results_sorted_by_descending_score(self):
        rows = [
            acl(ShareName="low", SharePath="\\\\a\\low", FileSystemRights="Read"),
            acl(ShareName="c$", SharePath="\\\\a\\c$", FileSystemRights="FullControl"),
        ]
        final = risk.enrich(rows, [], [])
        self.assertGreater(final[0].RiskScore, final[1].RiskScore)


class TestKeywords(unittest.TestCase):
    def test_default_table_covers_every_category(self):
        categories = {kw.category for kw in DEFAULT_KEYWORDS}
        for expected in ("Secret", "Sensitive", "SystemImage", "Database",
                         "Backup", "Script", "Binaries"):
            self.assertIn(expected, categories)

    def test_known_files_map_to_expected_categories(self):
        cases = [
            ("id_rsa", "Secret"),
            ("web.config", "Secret"),
            ("unattend.xml", "Secret"),
            ("shadow", "Secret"),
            ("hr_records.xlsx", "Sensitive"),
            ("customer_ssn_list.csv", "Sensitive"),
            ("server.vhdx", "SystemImage"),
            ("customers.sqlite", "Database"),
            ("archive.zip", "Backup"),
            ("deploy.ps1", "Script"),
            ("setup.exe", "Binaries"),
        ]
        for name, expected in cases:
            match = interesting.best_match(name, DEFAULT_KEYWORDS)
            self.assertIsNotNone(match, f"{name} should match a keyword")
            self.assertEqual(match.category, expected, f"{name} -> {match.category}")

    def test_secrets_outrank_other_categories(self):
        # backup.config matches both *.config (Secret) and *backup* (Backup).
        match = interesting.best_match("backup.config", DEFAULT_KEYWORDS)
        self.assertEqual(match.category, "Secret")

    def test_images_are_excluded(self):
        for name in ("logo.png", "photo.JPEG", "icon.ico"):
            self.assertTrue(interesting.is_excluded(name), name)
        self.assertFalse(interesting.is_excluded("notes.txt"))

    def test_directories_skipped_by_default(self):
        files = [FileEntry(FileName="backup", IsDirectory=True, ShareName="s")]
        self.assertEqual(interesting.find_interesting(files, DEFAULT_KEYWORDS), [])
        self.assertEqual(len(interesting.find_interesting(files, DEFAULT_KEYWORDS, True)), 1)

    def test_csv_override_loads(self):
        template = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "interesting-files-template.csv",
        )
        if os.path.exists(template):
            loaded = load_keywords(template)
            self.assertGreater(len(loaded), 50)

    def test_missing_csv_falls_back_to_builtin(self):
        loaded = load_keywords("/nonexistent/path/keywords.csv")
        self.assertEqual(len(loaded), len(DEFAULT_KEYWORDS))

    def test_parseable_selection_respects_size_cap(self):
        big = InterestingFile(FileName="web.config", FileSize=10 * 1024 * 1024)
        small = InterestingFile(FileName="web.config", FileSize=2048)
        self.assertEqual(interesting.parseable([big], DEFAULT_KEYWORDS, max_size=1024), [])
        picked = interesting.parseable([small], DEFAULT_KEYWORDS, max_size=1024 * 1024)
        self.assertEqual(len(picked), 1)
        self.assertEqual(picked[0][1], "web_config")


class TestUtil(unittest.TestCase):
    def test_like_is_case_insensitive_glob(self):
        self.assertTrue(like("Backup.ZIP", "*.zip*"))
        self.assertTrue(like("ID_RSA", "id_rsa*"))
        self.assertFalse(like("readme.txt", "*.zip*"))
        self.assertFalse(like(None, "*"))

    def test_file_list_hash_is_order_independent(self):
        self.assertEqual(
            md5_of_filelist("alpha\nbeta\ngamma"),
            md5_of_filelist("GAMMA\nAlpha\n beta "),
        )
        self.assertNotEqual(md5_of_filelist("a\nb"), md5_of_filelist("a\nc"))

    def test_percent_handles_zero_denominator(self):
        self.assertEqual(percent_str(0, 0), "0.00%")
        self.assertEqual(percent_str(1, 4), "25.00%")


if __name__ == "__main__":
    unittest.main(verbosity=2)
