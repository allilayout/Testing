"""Tests for target parsing.

Covers the case where a host list file is passed to --target instead of
--target-file, which previously produced a single bogus hostname and a scan
that aborted with no useful explanation.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import impacket  # noqa: F401

    HAVE_IMPACKET = True
except ImportError:  # pragma: no cover
    HAVE_IMPACKET = False


class Args:
    """Stand-in for the argparse namespace."""

    def __init__(self, target=None, target_file=""):
        self.target = target or []
        self.target_file = target_file


@unittest.skipUnless(HAVE_IMPACKET, "impacket not installed")
class TestTargetParsing(unittest.TestCase):
    def setUp(self):
        from powerhuntshares import cli

        self.cli = cli
        self.dir = tempfile.mkdtemp(prefix="phs-targets-")
        self.list_path = os.path.join(self.dir, "smb_hosts")
        with open(self.list_path, "w", encoding="utf-8") as handle:
            handle.write("10.241.1.6\n10.241.1.7\n# a comment\n\n10.241.2.0/30\n")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_file_passed_to_target_is_loaded(self):
        targets = self.cli._load_targets(Args(target=[self.list_path]))
        self.assertIn("10.241.1.6", targets)
        self.assertIn("10.241.1.7", targets)
        self.assertIn("10.241.2.0/30", targets)

    def test_target_file_still_works(self):
        targets = self.cli._load_targets(Args(target_file=self.list_path))
        self.assertIn("10.241.1.6", targets)

    def test_nonexistent_path_aborts_with_error(self):
        with self.assertRaises(SystemExit) as ctx:
            self.cli._load_targets(Args(target=["~/Documents/nope/hostlist"]))
        self.assertEqual(ctx.exception.code, 2)

    def test_plain_hosts_and_cidrs_pass_through(self):
        targets = self.cli._load_targets(
            Args(target=["10.0.0.1", "srv01.corp.local", "10.0.0.0/30"])
        )
        self.assertEqual(targets, ["10.0.0.1", "srv01.corp.local", "10.0.0.0/30"])

    def test_mixed_file_and_host(self):
        targets = self.cli._load_targets(Args(target=[self.list_path, "srv99.corp.local"]))
        self.assertIn("10.241.1.6", targets)
        self.assertIn("srv99.corp.local", targets)

    def test_path_detection(self):
        cases = {
            "10.0.0.0/24": False,
            "192.168.1.0/255.255.255.0": False,
            "srv01": False,
            "srv01.corp.local": False,
            "10.0.0.1": False,
            "~/hosts.txt": True,
            "./hosts.txt": True,
            "../hosts.txt": True,
            "/tmp/hosts.txt": True,
            "some/relative/path": True,
        }
        for value, expected in cases.items():
            self.assertEqual(
                self.cli._looks_like_path(value), expected, f"{value} misclassified"
            )

    def test_windows_path_detected(self):
        self.assertTrue(self.cli._looks_like_path("C:\\temp\\hosts.txt"))


@unittest.skipUnless(HAVE_IMPACKET, "impacket not installed")
class TestExpansion(unittest.TestCase):
    def test_full_pipeline_from_file_to_hosts(self):
        """A host list file must expand into individual scannable hosts."""
        from powerhuntshares import cli
        from powerhuntshares.discovery.portscan import expand_targets

        directory = tempfile.mkdtemp(prefix="phs-exp-")
        try:
            path = os.path.join(directory, "hosts")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("10.241.1.6\n10.241.2.0/30\n")

            targets = cli._load_targets(Args(target=[path]))
            hosts = expand_targets(targets)

            self.assertIn("10.241.1.6", hosts)
            self.assertIn("10.241.2.1", hosts)
            self.assertIn("10.241.2.2", hosts)
            self.assertEqual(len(hosts), 3)
        finally:
            shutil.rmtree(directory, ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
