"""End-to-end tests for the CSV and HTML output stages."""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from powerhuntshares.analysis import interesting, risk
from powerhuntshares.analysis.keywords import DEFAULT_KEYWORDS
from powerhuntshares.analysis.sharenames import guess
from powerhuntshares.models import (
    Computer,
    ExtractedSecret,
    FileEntry,
    ScanResults,
    Share,
    ShareACL,
)
from powerhuntshares.report import csvout, html


def sample_results() -> ScanResults:
    """Build a small but structurally complete scan result."""
    results = ScanResults(target_domain="corp.local")
    results.start_time = "07/29/2026 09:00:00"
    results.end_time = "07/29/2026 09:14:22"
    results.run_time = "0:14:22"

    results.computers = [
        Computer(ComputerName="fs01.corp.local", OperatingSystem="Windows Server 2019",
                 IpAddress="10.0.0.11", Pingable=True, Port445Open=True),
        Computer(ComputerName="web01.corp.local", OperatingSystem="Windows Server 2022",
                 IpAddress="10.0.0.12", Pingable=True, Port445Open=True),
        Computer(ComputerName="offline.corp.local", OperatingSystem="Windows 10"),
    ]
    results.computers_pingable = results.computers[:2]
    results.computers_445 = results.computers[:2]

    results.shares = [
        Share(ComputerName="fs01.corp.local", ShareName="finance",
              SharePath="\\\\fs01.corp.local\\finance", ShareType="Disk", ShareAccess="Yes"),
        Share(ComputerName="fs01.corp.local", ShareName="IPC$",
              SharePath="\\\\fs01.corp.local\\IPC$", ShareType="IPC", ShareAccess="No"),
        Share(ComputerName="web01.corp.local", ShareName="wwwroot",
              SharePath="\\\\web01.corp.local\\wwwroot", ShareType="Disk", ShareAccess="Yes"),
    ]

    def make_acl(computer, share, identity, rights, files=5):
        return ShareACL(
            ComputerName=computer, ShareName=share,
            SharePath=f"\\\\{computer}\\{share}", IdentityReference=identity,
            IdentitySID="S-1-1-0", FileSystemRights=rights, AccessControlType="Allow",
            ShareAccess="Yes", ShareOwner="BUILTIN\\Administrators", FileCount=files,
            CreationDate="01/02/2024 08:00:00", CreationDateYear="2024",
            LastModifiedDate="06/01/2026 12:00:00", LastModifiedDateYear="2026",
            LastAccessDate="07/01/2026 12:00:00", LastAccessDateYear="2026",
            FileListGroup="abc123", ShareType="Disk", AclSource="ntfs",
        )

    results.acls = [
        make_acl("fs01.corp.local", "finance", "Everyone", "Read, Synchronize"),
        make_acl("fs01.corp.local", "finance", "BUILTIN\\Administrators", "FullControl"),
        make_acl("web01.corp.local", "wwwroot", "Authenticated Users", "Modify, Write, Read"),
    ]

    results.files = [
        FileEntry(ComputerName="fs01.corp.local", ShareName="finance",
                  SharePath="\\\\fs01.corp.local\\finance",
                  FilePath="\\\\fs01.corp.local\\finance\\payroll_2026.xlsx",
                  FileName="payroll_2026.xlsx", FileSize=48210,
                  LastModified="06/01/2026 12:00:00"),
        FileEntry(ComputerName="web01.corp.local", ShareName="wwwroot",
                  SharePath="\\\\web01.corp.local\\wwwroot",
                  FilePath="\\\\web01.corp.local\\wwwroot\\web.config",
                  FileName="web.config", FileSize=3120,
                  LastModified="05/20/2026 09:30:00"),
        FileEntry(ComputerName="web01.corp.local", ShareName="wwwroot",
                  SharePath="\\\\web01.corp.local\\wwwroot",
                  FilePath="\\\\web01.corp.local\\wwwroot\\logo.png",
                  FileName="logo.png", FileSize=8100),
    ]

    results.interesting_files = interesting.find_interesting(results.files, DEFAULT_KEYWORDS)

    results.secrets = [
        ExtractedSecret(
            ComputerName="web01.corp.local", ShareName="wwwroot",
            UncPath="\\\\web01.corp.local\\wwwroot\\web.config", FileName="web.config",
            Parser="web_config", Name="Main", Section="ConnectionStrings",
            Server="sql01", Port="1433", UserName="sa", Password="Sup3rS3cret",
        )
    ]

    excessive = risk.find_excessive(results.acls)
    guesses = {n.ShareName.lower(): guess(n.ShareName) for n in excessive}
    results.excessive = risk.enrich(
        excessive, results.interesting_files, results.computers, share_guesses=guesses
    )
    return results


class TestPipeline(unittest.TestCase):
    def setUp(self):
        self.results = sample_results()
        self.dir = tempfile.mkdtemp(prefix="phs-test-")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_excessive_filters_out_admin_ace(self):
        identities = {row.IdentityReference for row in self.results.excessive}
        self.assertIn("Everyone", identities)
        self.assertIn("Authenticated Users", identities)
        self.assertNotIn("BUILTIN\\Administrators", identities)

    def test_wwwroot_scores_higher_than_finance(self):
        by_share = {row.ShareName: row for row in self.results.excessive}
        self.assertGreater(by_share["wwwroot"].RiskScore, by_share["finance"].RiskScore)
        self.assertEqual(by_share["wwwroot"].HasHR, 1)
        self.assertEqual(by_share["wwwroot"].HasRCE, 1)
        self.assertEqual(by_share["wwwroot"].RiskLevel, "Critical")

    def test_interesting_files_categorised_and_images_excluded(self):
        names = {f.FileName for f in self.results.interesting_files}
        self.assertIn("payroll_2026.xlsx", names)
        self.assertIn("web.config", names)
        self.assertNotIn("logo.png", names)

        categories = {f.FileName: f.Category for f in self.results.interesting_files}
        self.assertEqual(categories["web.config"], "Secret")
        self.assertEqual(categories["payroll_2026.xlsx"], "Sensitive")


class TestCsvExport(unittest.TestCase):
    def setUp(self):
        self.results = sample_results()
        from powerhuntshares.scanner import _build_stats, ScanConfig
        from powerhuntshares.smbx.auth import Credentials

        config = ScanConfig(output_dir="", creds=Credentials())
        self.results.stats = _build_stats(self.results, config)
        self.dir = tempfile.mkdtemp(prefix="phs-csv-")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_expected_files_written(self):
        written = csvout.export_all(self.results, self.dir)
        names = {os.path.basename(p) for p in written}
        for expected in (
            "corp.local-Domain-Computers.csv",
            "corp.local-Shares-Inventory-All.csv",
            "corp.local-Shares-Inventory-All-ACL.csv",
            "corp.local-Shares-Inventory-Excessive-Privileges.csv",
            "corp.local-Interesting-Files-All.csv",
            "corp.local-Extracted-Secrets.csv",
        ):
            self.assertIn(expected, names, f"{expected} not written")

    def test_csv_is_readable_and_has_expected_columns(self):
        csvout.export_all(self.results, self.dir)
        path = os.path.join(self.dir, "corp.local-Shares-Inventory-Excessive-Privileges.csv")
        with open(path, encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))

        self.assertEqual(len(rows), len(self.results.excessive))
        for column in ("ComputerName", "ShareName", "IdentityReference",
                       "FileSystemRights", "RiskScore", "RiskLevel", "HasWrite"):
            self.assertIn(column, rows[0])

    def test_empty_dataset_writes_nothing(self):
        empty = ScanResults(target_domain="empty.local")
        empty.stats = {}
        self.assertEqual(csvout.export_all(empty, self.dir), [])

    def test_derived_slices_are_subsets(self):
        csvout.export_all(self.results, self.dir)
        write_path = os.path.join(
            self.dir, "corp.local-Shares-Inventory-Excessive-Privileges-Write.csv"
        )
        with open(write_path, encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        self.assertTrue(all(row["HasWrite"] == "1" for row in rows))


class TestHtmlReport(unittest.TestCase):
    def setUp(self):
        self.results = sample_results()
        from powerhuntshares.scanner import _build_stats, ScanConfig
        from powerhuntshares.smbx.auth import Credentials

        self.results.stats = _build_stats(self.results, ScanConfig(output_dir="", creds=Credentials()))
        self.dir = tempfile.mkdtemp(prefix="phs-html-")
        self.path = os.path.join(self.dir, "report.html")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_report_is_written(self):
        self.assertTrue(html.build(self.results, self.path))
        self.assertTrue(os.path.exists(self.path))
        self.assertGreater(os.path.getsize(self.path), 5000)

    def test_report_is_self_contained(self):
        html.build(self.results, self.path)
        content = open(self.path, encoding="utf-8").read()

        # No external resource references of any kind.
        for pattern in (
            r'<script[^>]+src=',
            r'<link[^>]+href=[\'"]https?:',
            r'@import\s+url\(',
            r'<img[^>]+src=[\'"]https?:',
        ):
            self.assertIsNone(
                re.search(pattern, content, re.I), f"external reference found: {pattern}"
            )

    def test_embedded_payload_is_valid_json(self):
        html.build(self.results, self.path)
        content = open(self.path, encoding="utf-8").read()
        match = re.search(r"window\.PHS_DATA = (\{.*?\});</script>", content, re.S)
        self.assertIsNotNone(match, "data payload not found")

        payload = json.loads(match.group(1))
        self.assertEqual(len(payload["excessive"]), len(self.results.excessive))
        self.assertEqual(len(payload["secrets"]), 1)
        self.assertIn("riskCounts", payload)
        self.assertIn("categoryCounts", payload)

    def test_domain_and_counts_appear(self):
        html.build(self.results, self.path)
        content = open(self.path, encoding="utf-8").read()
        self.assertIn("corp.local", content)
        self.assertIn("Excessive Privileges", content)
        self.assertIn("Extracted Secrets", content)

    def test_row_cap_is_applied(self):
        html.build(self.results, self.path, max_rows=1)
        content = open(self.path, encoding="utf-8").read()
        payload = json.loads(re.search(r"window\.PHS_DATA = (\{.*?\});</script>", content, re.S).group(1))
        self.assertEqual(len(payload["excessive"]), 1)

    def test_html_injection_in_data_is_neutralised(self):
        self.results.excessive[0].ShareName = "<script>alert(1)</script>"
        html.build(self.results, self.path)
        content = open(self.path, encoding="utf-8").read()
        # The value survives only inside the JSON payload, escaped, never as
        # a live tag in the document body.
        self.assertNotIn("<script>alert(1)</script>", content)


if __name__ == "__main__":
    unittest.main(verbosity=2)
