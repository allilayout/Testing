"""Tests for the LDAP enumeration layer.

The live-directory code path cannot be exercised without a domain controller,
which is exactly how a bad keyword argument reached users: ``generator`` is
valid on ``conn.extend.standard.paged_search`` but not on ``Connection.search``,
and nothing caught the difference until a real scan failed.

These tests close that gap two ways: by checking every keyword we pass against
the real ldap3 signatures, and by driving the parsing logic with fakes that
reject unknown keywords the same way ldap3 does.
"""

from __future__ import annotations

import inspect
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import ldap3  # noqa: F401

    HAVE_LDAP3 = True
except ImportError:  # pragma: no cover
    HAVE_LDAP3 = False

try:
    import impacket  # noqa: F401

    HAVE_IMPACKET = True
except ImportError:  # pragma: no cover
    HAVE_IMPACKET = False

REQUIRES = unittest.skipUnless(
    HAVE_LDAP3 and HAVE_IMPACKET, "ldap3 and impacket required"
)


@unittest.skipUnless(HAVE_LDAP3, "ldap3 not installed")
class TestLdap3Signatures(unittest.TestCase):
    """Guard the keyword arguments we rely on against ldap3 API drift."""

    def test_connection_search_accepts_what_we_pass(self):
        from ldap3 import Connection

        params = set(inspect.signature(Connection.search).parameters)
        for keyword in (
            "search_base", "search_filter", "search_scope",
            "attributes", "paged_size", "paged_cookie",
        ):
            self.assertIn(keyword, params, f"Connection.search lost {keyword}")

    def test_connection_search_has_no_generator_parameter(self):
        """The exact bug: `generator` belongs to paged_search, not search."""
        from ldap3 import Connection

        params = set(inspect.signature(Connection.search).parameters)
        self.assertNotIn("generator", params)

    def test_paged_search_accepts_what_we_pass(self):
        from ldap3.extend import StandardExtendedOperations

        params = set(inspect.signature(StandardExtendedOperations.paged_search).parameters)
        for keyword in (
            "search_base", "search_filter", "search_scope",
            "attributes", "paged_size", "generator",
        ):
            self.assertIn(keyword, params, f"paged_search lost {keyword}")


class StrictSearch:
    """Records calls and rejects keywords the real ldap3 method would reject."""

    def __init__(self, allowed, result=None):
        self.allowed = set(allowed)
        self.result = result if result is not None else []
        self.calls = []

    def __call__(self, **kwargs):
        unexpected = set(kwargs) - self.allowed
        if unexpected:
            raise TypeError(
                f"search() got an unexpected keyword argument {sorted(unexpected)[0]!r}"
            )
        self.calls.append(kwargs)
        return self.result


class FakeEntry:
    def __init__(self, attributes):
        self._attributes = attributes

    @property
    def entry_attributes_as_dict(self):
        return self._attributes


class FakeConnection:
    """Minimal stand-in shaped like ldap3's Connection."""

    SEARCH_KWARGS = {
        "search_base", "search_filter", "search_scope", "attributes",
        "paged_size", "paged_cookie", "paged_criticality", "size_limit",
        "time_limit", "types_only", "controls", "dereference_aliases",
        "get_operational_attributes", "auto_escape",
    }
    PAGED_KWARGS = (SEARCH_KWARGS - {"paged_cookie", "auto_escape"}) | {"generator"}

    def __init__(self, paged_result=None, plain_entries=None, paged_raises=None):
        self.entries = plain_entries or []
        self.search = StrictSearch(self.SEARCH_KWARGS, result=True)
        self._paged_raises = paged_raises
        self._paged_result = paged_result or []

        outer = self

        class Standard:
            def paged_search(self, **kwargs):
                unexpected = set(kwargs) - outer.PAGED_KWARGS
                if unexpected:
                    raise TypeError(
                        "paged_search() got an unexpected keyword argument "
                        f"{sorted(unexpected)[0]!r}"
                    )
                if outer._paged_raises:
                    raise outer._paged_raises
                return iter(outer._paged_result)

        class Extend:
            standard = Standard()

        self.extend = Extend()


def computer_entry(dns_name, os_name="Windows Server 2019", short_name=None):
    return {
        "type": "searchResEntry",
        "dn": f"CN={short_name or dns_name},OU=Servers,DC=corp,DC=local",
        "attributes": {
            "dNSHostName": [dns_name] if dns_name else [],
            "name": [short_name or ""],
            "operatingSystem": [os_name],
            "operatingSystemServicePack": [],
        },
    }


@REQUIRES
class TestComputerQuery(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.discovery import ldap_enum

        self.ldap_enum = ldap_enum
        self.attributes = ["dNSHostName", "name", "operatingSystem"]

    def test_paged_search_is_used_and_parsed(self):
        conn = FakeConnection(paged_result=[
            computer_entry("fs01.corp.local", "Windows Server 2019"),
            computer_entry("web01.corp.local", "Windows Server 2022"),
        ])
        computers = self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")

        self.assertEqual(len(computers), 2)
        self.assertEqual(computers[0].ComputerName, "fs01.corp.local")
        self.assertEqual(computers[1].OperatingSystem, "Windows Server 2022")
        # The plain search must not have been needed.
        self.assertEqual(conn.search.calls, [])

    def test_referrals_are_skipped(self):
        conn = FakeConnection(paged_result=[
            {"type": "searchResRef", "uri": ["ldap://other.corp.local"]},
            computer_entry("fs01.corp.local"),
        ])
        computers = self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")
        self.assertEqual(len(computers), 1)

    def test_duplicates_collapsed(self):
        conn = FakeConnection(paged_result=[
            computer_entry("fs01.corp.local"),
            computer_entry("FS01.CORP.LOCAL"),
        ])
        computers = self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")
        self.assertEqual(len(computers), 1)

    def test_falls_back_to_sam_name_without_dnshostname(self):
        conn = FakeConnection(paged_result=[computer_entry("", short_name="LEGACY01$")])
        computers = self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")
        self.assertEqual(len(computers), 1)
        self.assertEqual(computers[0].ComputerName, "LEGACY01")

    def test_falls_back_to_plain_search_when_paging_refused(self):
        conn = FakeConnection(
            paged_raises=RuntimeError("paging control unavailable"),
            plain_entries=[
                FakeEntry({
                    "dNSHostName": ["fs01.corp.local"],
                    "name": ["FS01$"],
                    "operatingSystem": ["Windows Server 2016"],
                })
            ],
        )
        computers = self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")

        self.assertEqual(len(computers), 1)
        self.assertEqual(computers[0].ComputerName, "fs01.corp.local")
        self.assertEqual(len(conn.search.calls), 1, "fallback search should have run once")

    def test_empty_directory_yields_no_computers(self):
        conn = FakeConnection(paged_result=[])
        self.assertEqual(
            self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)"),
            [],
        )

    def test_no_invalid_keyword_reaches_the_connection(self):
        """A regression guard for the `generator` keyword on plain search.

        FakeConnection raises TypeError for unknown keywords exactly as ldap3
        does, so any reintroduction of the bug fails here rather than in the
        field.
        """
        conn = FakeConnection(paged_result=[computer_entry("fs01.corp.local")])
        self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")

        conn = FakeConnection(
            paged_raises=RuntimeError("no paging"),
            plain_entries=[FakeEntry({"dNSHostName": ["a.corp.local"]})],
        )
        # Would raise TypeError if an unsupported keyword were passed.
        self.ldap_enum._query_computers(conn, "DC=corp,DC=local", "(objectCategory=computer)")
        for call in conn.search.calls:
            self.assertNotIn("generator", call)


@REQUIRES
class TestSubnetQuery(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.discovery import ldap_enum

        self.ldap_enum = ldap_enum

    def test_subnets_parsed(self):
        conn = FakeConnection(plain_entries=[
            FakeEntry({
                "cn": ["10.0.0.0/24"],
                "siteObject": ["CN=HQ,CN=Sites,CN=Configuration,DC=corp,DC=local"],
                "description": ["Head office"],
                "whenCreated": ["20240101000000.0Z"],
                "whenChanged": ["20240201000000.0Z"],
            })
        ])
        subnets = self.ldap_enum._query_subnets(conn, "CN=Configuration,DC=corp,DC=local")

        self.assertEqual(len(subnets), 1)
        self.assertEqual(subnets[0].Subnet, "10.0.0.0/24")
        self.assertEqual(subnets[0].Site, "HQ")

    def test_missing_config_dn_returns_empty(self):
        self.assertEqual(self.ldap_enum._query_subnets(FakeConnection(), ""), [])

    def test_search_failure_is_not_fatal(self):
        conn = FakeConnection()
        conn.search = lambda **kwargs: (_ for _ in ()).throw(RuntimeError("denied"))
        self.assertEqual(
            self.ldap_enum._query_subnets(conn, "CN=Configuration,DC=corp,DC=local"), []
        )


@REQUIRES
class TestHelpers(unittest.TestCase):
    def setUp(self):
        from powerhuntshares.discovery import ldap_enum

        self.ldap_enum = ldap_enum

    def test_dn_to_domain(self):
        self.assertEqual(
            self.ldap_enum.dn_to_domain("DC=ad,DC=cleanaway,DC=com,DC=au"),
            "ad.cleanaway.com.au",
        )
        self.assertEqual(self.ldap_enum.dn_to_domain("DC=corp,DC=local"), "corp.local")
        self.assertEqual(self.ldap_enum.dn_to_domain(""), "")

    def test_first_handles_lists_and_scalars(self):
        self.assertEqual(self.ldap_enum._first(["a", "b"]), "a")
        self.assertEqual(self.ldap_enum._first("plain"), "plain")
        self.assertEqual(self.ldap_enum._first([]), "")
        self.assertEqual(self.ldap_enum._first(None), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
